import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateRecord, installWearableRoutes } from './wearable-records.mjs';

const record = () => ({ eventId: '43a32d5d-13ab-4095-998b-7539301748ae', deviceId: 'watch',
  activities: [{ id: 'a1', label: 'Desayuno', time: '07:15', done: true },
    { id: 'a2', label: 'Dientes', time: '07:30', done: false }],
  emotion: 'Bien', recordedAt: new Date().toISOString(), progressPercent: 100 });

test('calcula progreso en el servidor y admite lista vacía', () => {
  assert.equal(validateRecord(record()).progressPercent, 50);
  assert.equal(validateRecord({ ...record(), activities: [] }).progressPercent, 0);
});
test('rechaza tareas inválidas, IDs repetidos, fechas y emociones inválidas', () => {
  for (const change of [ { eventId: 'invalid' }, { recordedAt: 'invalid' },
    { recordedAt: new Date(Date.now() + 600000).toISOString() }, { emotion: {} },
    { activities: [{ ...record().activities[0], done: 'true' }] },
    { activities: [record().activities[0], record().activities[0]] },
    { activities: [{ ...record().activities[0], time: '25:00' }] } ]) {
    assert.throws(() => validateRecord({ ...record(), ...change }));
  }
});
test('rutas autenticadas, escritura por cuenta y reintentos idempotentes', async () => {
  const routes = {};
  const auth = () => {};
  const app = { post: (path, middleware, handler) => { assert.equal(middleware, auth); routes.post = handler; },
    get: (path, middleware, handler) => { assert.equal(middleware, auth); routes.get = handler; } };
  let inserted = false;
  const pool = { query: async (sql, values) => {
    assert.equal(values[0], 'account-1');
    if (sql.includes('INSERT')) {
      assert.match(sql, /ON CONFLICT\(user_id,event_id\) DO NOTHING/);
      const rowCount = inserted ? 0 : 1;
      inserted = true;
      assert.equal(values[5], 50);
      return { rowCount };
    }
    assert.match(sql, /WHERE p.user_id=\$1/);
    assert.equal(values[1], 200);
    return { rows: [] };
  } };
  installWearableRoutes(app, pool, auth);
  const res = { code: 200, status(code) { this.code = code; return this; }, json(data) { this.data = data; } };
  await routes.post({ body: record(), auth: { sub: 'account-1' } }, res);
  assert.equal(res.code, 201);
  await routes.post({ body: record(), auth: { sub: 'account-1' } }, res);
  assert.equal(res.code, 200);
  await routes.get({ query: { limit: '999' }, auth: { sub: 'account-1' } }, res);
  assert.deepEqual(res.data, []);
});
