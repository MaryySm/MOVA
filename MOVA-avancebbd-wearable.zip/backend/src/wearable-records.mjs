import { readFileSync } from 'node:fs';

export const wearableSchema = readFileSync(new URL('../db/wearable.sql', import.meta.url), 'utf8').replace(/^\uFEFF/, '');

export function validateRecord(body) {
  if (!body || typeof body !== 'object') throw new Error('Registro requerido.');
  const { eventId, deviceId, activities, emotion = null, recordedAt } = body;
  if (typeof eventId !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(eventId))
    throw new Error('eventId debe ser UUID.');
  if (typeof deviceId !== 'string' || !deviceId.trim() || deviceId.length > 160)
    throw new Error('deviceId requerido (máximo 160 caracteres).');
  if (!Array.isArray(activities) || activities.length > 100)
    throw new Error('activities debe ser una lista de hasta 100 tareas.');
  const ids = new Set();
  const cleanActivities = activities.map((activity) => {
    if (!activity || typeof activity.id !== 'string' || !activity.id.trim() || activity.id.length > 160 ||
        ids.has(activity.id) || typeof activity.label !== 'string' || !activity.label.trim() ||
        activity.label.length > 200 || typeof activity.done !== 'boolean' ||
        typeof activity.time !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(activity.time))
      throw new Error('Cada tarea necesita id único, label, time (HH:mm) y done booleano.');
    ids.add(activity.id);
    return { id: activity.id, label: activity.label.trim(), time: activity.time, done: activity.done };
  });
  if (emotion !== null && (typeof emotion !== 'string' || !emotion.trim() || emotion.length > 80))
    throw new Error('emotion debe ser texto de hasta 80 caracteres o null.');
  const timestamp = typeof recordedAt === 'string' ? Date.parse(recordedAt) : NaN;
  if (!Number.isFinite(timestamp) || timestamp > Date.now() + 300_000)
    throw new Error('recordedAt debe ser una fecha válida y no futura.');
  return { eventId, deviceId: deviceId.trim(), activities: cleanActivities,
    emotion: emotion === null ? null : emotion.trim(), recordedAt: new Date(timestamp).toISOString(),
    progressPercent: cleanActivities.length ? Math.round(cleanActivities.filter((a) => a.done).length / cleanActivities.length * 100) : 0 };
}

export function installWearableRoutes(app, pool, requireAuth) {
  app.post('/api/wearable/records', requireAuth, async (req, res) => {
    let record;
    try { record = validateRecord(req.body); }
    catch (error) { return res.status(400).json({ error: error.message }); }
    try {
      const result = await pool.query(`
        WITH previous AS (
          SELECT emotion,progress_percent FROM mova_interno.registros WHERE user_id=$1
          ORDER BY recorded_at DESC,id DESC LIMIT 1
        ), saved_record AS (
          INSERT INTO mova_interno.registros(user_id,event_id,device_id,activities,emotion,progress_percent,recorded_at)
          VALUES($1,$2,$3,mova_interno.nombres_tareas($4::jsonb),mova_interno.nombre_emocion($5::text),$6,$7)
          ON CONFLICT(user_id,event_id) DO NOTHING RETURNING id,activities,emotion,progress_percent
        ), saved_tasks AS (
          INSERT INTO tareas(tarea)
          SELECT DISTINCT a->>'label' FROM saved_record r
          CROSS JOIN LATERAL jsonb_array_elements(r.activities) a
          WHERE (a->>'done')::boolean
          ON CONFLICT(tarea) DO NOTHING
        ), saved_emotion AS (
          INSERT INTO emociones(emocion)
          SELECT emotion FROM saved_record WHERE emotion IS NOT NULL
          AND emotion IS DISTINCT FROM (SELECT emotion FROM previous)
        ), saved_progress AS (
          INSERT INTO progreso(porcentaje)
          SELECT progress_percent FROM saved_record
          WHERE progress_percent IS DISTINCT FROM (SELECT progress_percent FROM previous)
        ) SELECT id FROM saved_record`,
      [req.auth.sub, record.eventId, record.deviceId, JSON.stringify(record.activities), record.emotion, record.progressPercent, record.recordedAt]);
      res.status(result.rowCount ? 201 : 200).json({ eventId: record.eventId, saved: true });
    } catch (error) {
      console.error('No se pudo guardar el registro wearable:', error);
      res.status(503).json({ error: 'No se pudo guardar el registro.' });
    }
  });
  app.get('/api/wearable/records', requireAuth, async (req, res) => {
    const limit = Math.min(Math.max(parseInt(req.query.limit ?? '50', 10) || 50, 1), 200);
    try {
      const result = await pool.query(`SELECT p.id, p.event_id AS "eventId", p.device_id AS "deviceId",
        p.activities, p.emotion, p.progress_percent AS "progressPercent", p.recorded_at AS "recordedAt",
        p.received_at AS "receivedAt" FROM mova_interno.registros p
        WHERE p.user_id=$1 ORDER BY p.id DESC LIMIT $2`, [req.auth.sub, limit]);
      res.json(result.rows);
    } catch { res.status(503).json({ error: 'No se pudieron consultar los registros.' }); }
  });
}
