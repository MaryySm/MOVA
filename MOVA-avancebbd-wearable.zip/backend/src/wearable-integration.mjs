import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import express from 'express';
import pg from 'pg';
import { wearableSchema, installWearableRoutes } from './wearable-records.mjs';

// Las pruebas no agregan datos a MOVA: usan una base temporal aislada.
const admin = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const database = `mova_test_${crypto.randomBytes(8).toString('hex')}`;
const url = new URL(process.env.DATABASE_URL);
url.pathname = `/${database}`;
let pool, server, created = false;
try {
  await admin.query(`CREATE DATABASE ${database}`);
  created = true;
  pool = new pg.Pool({ connectionString: url.toString() });
  const userA = crypto.randomUUID(), userB = crypto.randomUUID();
  await pool.query('CREATE TABLE users(id UUID PRIMARY KEY)');
  await pool.query('INSERT INTO users VALUES($1),($2)', [userA, userB]);
  const record = { eventId: crypto.randomUUID(), deviceId: 'integration-test',
    activities: [{ id: 'a1', label: 'Levantarme', time: '06:30', done: true },
      { id: 'a2', label: 'Bañarme', time: '06:45', done: false }],
    emotion: '¡Genial!', recordedAt: new Date().toISOString(), progressPercent: 99 };
  await pool.query(`CREATE TABLE progreso(id BIGSERIAL PRIMARY KEY,user_id UUID,event_id UUID,
    device_id TEXT,progress_percent SMALLINT,total_tasks SMALLINT,completed_tasks SMALLINT,
    recorded_at TIMESTAMPTZ,received_at TIMESTAMPTZ,UNIQUE(user_id,event_id));
    CREATE TABLE tareas(user_id UUID,event_id UUID,activity_id TEXT,label TEXT,
      scheduled_time TIME,completed BOOLEAN,position SMALLINT);
    CREATE TABLE emociones(user_id UUID,event_id UUID,emotion TEXT)`);
  await pool.query('INSERT INTO progreso(user_id,event_id,device_id,progress_percent,total_tasks,completed_tasks,recorded_at,received_at) VALUES($1,$2,$3,50,2,1,$4,NOW())', [userA, record.eventId, record.deviceId, record.recordedAt]);
  for (const [i, task] of record.activities.entries()) await pool.query('INSERT INTO tareas VALUES($1,$2,$3,$4,$5,$6,$7)', [userA, record.eventId, task.id, task.label, task.time, task.done, i]);
  await pool.query('INSERT INTO emociones VALUES($1,$2,$3)', [userA, record.eventId, record.emotion]);
  await pool.query(wearableSchema);
  await pool.query(wearableSchema);
  const columns = await pool.query(`SELECT table_name,column_name FROM information_schema.columns WHERE table_schema='public' AND table_name IN ('tareas','emociones','progreso') ORDER BY table_name,ordinal_position`);
  assert.deepEqual(columns.rows, [{ table_name: 'emociones', column_name: 'emocion' }, { table_name: 'progreso', column_name: 'porcentaje' }, { table_name: 'tareas', column_name: 'tarea' }]);
  assert.deepEqual((await pool.query('SELECT * FROM tareas ORDER BY tarea')).rows, [{ tarea: 'Levantarse' }]);
  assert.deepEqual((await pool.query('SELECT * FROM emociones')).rows, [{ emocion: 'Feliz' }]);
  assert.deepEqual((await pool.query('SELECT * FROM progreso')).rows, [{ porcentaje: 50 }]);
  const app = express();
  app.use(express.json());
  installWearableRoutes(app, pool, (req, res, next) => {
    const user = { 'Bearer test-a': userA, 'Bearer test-b': userB }[req.get('authorization')];
    if (!user) return res.status(401).json({ error: 'Sesión requerida' });
    req.auth = { sub: user }; next();
  });
  server = await new Promise((resolve) => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  async function request(body, token = 'test-a', limit = '') {
    const r = await fetch(`http://127.0.0.1:${server.address().port}/api/wearable/records${limit}`, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    return { status: r.status, data: await r.json() };
  }
  const count = async (table) => (await pool.query(`SELECT COUNT(*)::int AS n FROM ${table}`)).rows[0].n;
  assert.equal((await request(record, null)).status, 401);
  assert.equal((await request(record)).status, 200);
  const same = { ...record, eventId: crypto.randomUUID(), recordedAt: new Date().toISOString() };
  assert.equal((await request(same)).status, 201);
  assert.equal((await request(same)).status, 200);
  assert.deepEqual([await count('tareas'), await count('emociones'), await count('progreso')], [1,1,1]);
  const latest = (await request(undefined, 'test-a', '?limit=1')).data[0];
  assert.equal(latest.emotion, 'Feliz'); assert.equal(latest.progressPercent, 50);
  assert.equal(latest.activities[0].label, 'Levantarse'); assert.equal(latest.activities[0].done, true);
  assert.deepEqual((await request(undefined, 'test-b')).data, []);
  const sad = { ...same, eventId: crypto.randomUUID(), emotion: 'Triste', recordedAt: new Date().toISOString() };
  assert.equal((await request(sad)).status, 201);
  assert.deepEqual([await count('tareas'), await count('emociones'), await count('progreso')], [1,2,1]);
  const done = { ...sad, eventId: crypto.randomUUID(), activities: record.activities.map((a) => ({ ...a, done: true })), recordedAt: new Date().toISOString() };
  assert.equal((await request(done)).status, 201);
  assert.deepEqual([await count('tareas'), await count('emociones'), await count('progreso')], [2,2,2]);
  assert.deepEqual((await pool.query('SELECT porcentaje FROM progreso ORDER BY porcentaje')).rows, [{ porcentaje: 50 }, { porcentaje: 100 }]);
  const empty = { ...done, eventId: crypto.randomUUID(), activities: [], emotion: null, recordedAt: new Date().toISOString() };
  assert.equal((await request(empty)).status, 201);
  assert.equal((await request(undefined, 'test-a', '?limit=1')).data[0].progressPercent, 0);
  assert.equal((await request({ ...record, emotion: {} })).status, 400);
  // Una tarea pendiente no aparece; al marcarla se guarda solo su nombre.
  const pending = { ...record, eventId: crypto.randomUUID(), emotion: null,
    activities: [{ id: 'reading', label: 'Leer un cuento', time: '18:00', done: false }],
    recordedAt: new Date().toISOString() };
  assert.equal((await request(pending, 'test-b')).status, 201);
  assert.equal((await pool.query('SELECT tarea FROM tareas WHERE tarea=$1', ['Leer un cuento'])).rowCount, 0);
  const marked = { ...pending, eventId: crypto.randomUUID(),
    activities: [{ ...pending.activities[0], done: true }], recordedAt: new Date().toISOString() };
  assert.equal((await request(marked, 'test-b')).status, 201);
  assert.equal((await request(marked, 'test-b')).status, 200);
  assert.deepEqual((await pool.query('SELECT tarea FROM tareas WHERE tarea=$1', ['Leer un cuento'])).rows,
    [{ tarea: 'Leer un cuento' }]);
  console.log('Pruebas correctas: una columna por tabla, nombres claros, migración, aislamiento por cuenta y cambios sin duplicados.');
} finally {
  if (server) await new Promise((resolve) => server.close(resolve));
  if (pool) await pool.end();
  if (created) await admin.query(`DROP DATABASE ${database}`);
  await admin.end();
}
