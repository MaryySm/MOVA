import { validateRecord } from './wearable-records.mjs';

export function validateAction(body) {
  if (!body || typeof body !== 'object' || typeof body.actionId !== 'string' ||
      !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(body.actionId))
    throw new Error('Identificador de cambio inválido.');
  if (!['add_task','set_done','remove_task','set_emotion'].includes(body.type)) throw new Error('Cambio inválido.');
  if (body.type !== 'set_emotion' && (typeof body.taskId !== 'string' || !body.taskId.trim() || body.taskId.length > 160)) throw new Error('Tarea requerida.');
  if (body.type === 'add_task' && (typeof body.label !== 'string' || !body.label.trim() || body.label.length > 200 || typeof body.time !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(body.time))) throw new Error('Escribe el nombre y una hora válida.');
  if (body.type === 'set_done' && typeof body.done !== 'boolean') throw new Error('Estado inválido.');
  if (body.type === 'set_emotion' && body.emotion !== null && (typeof body.emotion !== 'string' || !body.emotion.trim() || body.emotion.length > 80)) throw new Error('Emoción inválida.');
  return body;
}
export function applyAction(state, action) {
  let activities = state.activities.map((a) => ({ ...a }));
  let emotion = state.emotion;
  if (action.type === 'add_task' && !activities.some((a) => a.id === action.taskId)) {
    if (activities.length >= 100) throw new Error('Puedes guardar hasta 100 actividades.');
    activities.push({ id: action.taskId, label: action.label.trim(), time: action.time, done: false });
  }
  if (action.type === 'remove_task') activities = activities.filter((a) => a.id !== action.taskId);
  if (action.type === 'set_done') activities = activities.map((a) => a.id === action.taskId ? { ...a, done: action.done } : a);
  if (action.type === 'set_emotion') emotion = action.emotion;
  return { activities, emotion };
}
export function installActivityRoutes(app, pool, requireAuth) {
  const handle = async (req, res, legacy = false) => {
    let action;
    try { action = legacy ? { ...validateRecord(req.body), actionId: req.body.eventId } : validateAction(req.body); }
    catch (error) { return res.status(400).json({ error: error.message }); }
    let client;
    try {
      client = await pool.connect();
      await client.query('BEGIN');
      const user = await client.query('SELECT id FROM users WHERE id=$1 FOR UPDATE', [req.auth.sub]);
      if (!user.rowCount) { await client.query('ROLLBACK'); return res.status(401).json({ error: 'La cuenta ya no está disponible.' }); }
      const duplicate = await client.query('SELECT id FROM mova_interno.registros WHERE user_id=$1 AND event_id=$2', [req.auth.sub, action.actionId]);
      if (duplicate.rowCount) { await client.query('COMMIT'); return res.json({ saved: true, actionId: action.actionId }); }
      const previous = (await client.query('SELECT activities,emotion,progress_percent FROM mova_interno.registros WHERE user_id=$1 ORDER BY id DESC LIMIT 1', [req.auth.sub])).rows[0];
      let state;
      try {
        state = legacy ? {
          activities: previous ? previous.activities.map((a) => {
            const incoming = action.activities.find((task) => task.id === a.id);
            return incoming ? { ...a, done: incoming.done } : a;
          }) : action.activities,
          emotion: action.emotion ?? previous?.emotion ?? null,
        } : applyAction(previous ?? { activities: [], emotion: null }, action);
        state = validateRecord({ ...state, eventId: action.actionId, deviceId: 'mova-connected', recordedAt: new Date().toISOString() });
      } catch (error) { await client.query('ROLLBACK'); return res.status(400).json({ error: error.message }); }
      const normalized = (await client.query('SELECT mova_interno.nombres_tareas($1::jsonb) AS activities,mova_interno.nombre_emocion($2::text) AS emotion', [JSON.stringify(state.activities), state.emotion])).rows[0];
      await client.query(`INSERT INTO mova_interno.registros(user_id,event_id,device_id,activities,emotion,progress_percent,recorded_at)
        VALUES($1,$2,$3,$4,$5,$6,$7)`, [req.auth.sub, action.actionId, state.deviceId, JSON.stringify(normalized.activities), normalized.emotion, state.progressPercent, state.recordedAt]);
      // Solo las completadas pasan a la tabla visible tareas.
      await client.query(`INSERT INTO tareas(tarea) SELECT DISTINCT a->>'label'
        FROM jsonb_array_elements($1::jsonb) a WHERE (a->>'done')::boolean ON CONFLICT(tarea) DO NOTHING`, [JSON.stringify(normalized.activities)]);
      if (normalized.emotion !== null && normalized.emotion !== previous?.emotion) await client.query('INSERT INTO emociones(emocion) VALUES($1)', [normalized.emotion]);
      if (state.progressPercent !== previous?.progress_percent) await client.query('INSERT INTO progreso(porcentaje) VALUES($1)', [state.progressPercent]);
      await client.query('COMMIT');
      res.status(201).json({ saved: true, actionId: action.actionId });
    } catch (error) {
      if (client) await client.query('ROLLBACK').catch(() => {});
      console.error('No se pudo guardar el cambio:', error);
      res.status(503).json({ error: 'No se pudo guardar. Se reintentará al recuperar la conexión.' });
    } finally { client?.release(); }
  };
  app.post('/api/activities/actions', requireAuth, (req, res) => handle(req, res));
  app.post('/api/sync/legacy', requireAuth, (req, res) => handle(req, res, true));
}
