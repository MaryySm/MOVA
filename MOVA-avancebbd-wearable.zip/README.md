# MOVA

Proyecto con app móvil Flutter en `app`, prototipos web locales en `wearable` y API Node.js/PostgreSQL en `backend`.

## API y base de datos local

Requiere Docker Desktop con Docker Compose. En PowerShell:

```powershell
cd C:\mova\backend
Copy-Item .env.example .env
```

Edita `.env` y configura `POSTGRES_USER`, `POSTGRES_PASSWORD` y `AUTH_TOKEN_SECRET`. El secreto de autenticación debe tener al menos 32 caracteres. Si la contraseña contiene caracteres reservados de una URL, debes codificarlos al construir `DATABASE_URL`. Luego ejecuta:

```powershell
docker compose up --build -d
docker compose ps
```

La API queda disponible en `http://localhost:3000`; `GET /health` indica cuándo PostgreSQL está conectado. Los datos se guardan en el volumen Docker `mova_pgdata`. Las tablas se crean o actualizan de forma idempotente al iniciar la API.

## App Flutter y autenticación

Requiere Flutter. En una terminal, desde `app`:

```powershell
flutter pub get
flutter run --dart-define=MOVA_API_URL=http://10.0.2.2:3000
```

`10.0.2.2` conecta el emulador Android con la API del computador. En un teléfono físico, reemplázalo por la IP local del computador. Para una compilación publicada, define `MOVA_API_URL` como la URL HTTPS de la API.

Para ver la app en Chrome en este computador, inicia Flutter con `flutter run -d chrome --dart-define=MOVA_API_URL=http://localhost:3000`. El Compose local permite CORS solo para orígenes localhost; en producción configura `CORS_ORIGINS` con los orígenes exactos y deja `ALLOW_LOCAL_CORS=0`.

El registro crea en PostgreSQL la cuenta del adulto y los datos del usuario, incluyendo una contraseña almacenada con hash y sal. El correo se normaliza a minúsculas y debe ser único. El inicio de sesión valida la contraseña contra ese hash y entrega una sesión firmada. Las rutas de sincronización requieren esa sesión y separan los registros por cuenta.

## Publicación

La autenticación y persistencia están conectadas localmente, pero el proyecto aún no está desplegado en Internet. Para publicarlo hacen falta un proveedor de hosting con PostgreSQL, un dominio, HTTPS y secretos configurados en ese proveedor. No subas `.env` ni uses credenciales de desarrollo en producción. Cuando esos datos estén disponibles, se puede configurar el despliegue y compilar la app contra su URL HTTPS.

## Prototipos web locales

Desde `wearable`, inicia en terminales separadas:

```powershell
npm.cmd run dev:app
npm.cmd run dev:wearable
```

La app de teléfono abre en `http://localhost:8443` y el simulador independiente MOVA Kids en `http://localhost:8444`.

## Wearable conectado a la base compartida

El simulador MOVA Kids se conecta directamente a la API, sin pasar por el teléfono.
La API guarda los registros en la misma base PostgreSQL que utiliza la app.
Inicia sesión en el simulador con la misma cuenta registrada en Flutter.
Las credenciales de PostgreSQL y el secreto de autenticación se configuran exclusivamente
en `backend/.env` (archivo excluido de Git).

Desde `wearable`, ejecuta `npm.cmd install` y `npm.cmd run dev:wearable`.
Abre `http://localhost:8444`. Si la API está en otro equipo, configura
`VITE_MOVA_API_URL` en un archivo `.env.local` antes de iniciar Vite.
Para Flutter web usa `--dart-define=MOVA_API_URL=http://localhost:3000`;
para el emulador Android, `http://10.0.2.2:3000`.

También puedes iniciar la API, PostgreSQL y el simulador con Docker desde `backend`:
`docker compose --profile wearable up --build -d`.
El simulador queda en `http://localhost:8444` y usa una instalación de dependencias
independiente dentro de Docker.

Las tres tablas visibles tienen una sola columna cada una:

| Tabla | Columna | Ejemplos |
| --- | --- | --- |
| `tareas` | `tarea` | `Levantarse`, `Bañarse`, `Dormir` |
| `emociones` | `emocion` | `Feliz`, `Triste`, `Enojado` |
| `progreso` | `porcentaje` | `0`, `43`, `100` |

Las tareas se guardan únicamente al marcarlas como completadas, una sola vez por
nombre. Las tareas pendientes no aparecen en esta tabla. La tabla conserva el
historial de tareas realizadas, incluso si después se desmarca una actividad.
Las emociones se agregan cuando
cambia la emoción elegida; los porcentajes se agregan cuando cambia el progreso.
El porcentaje es un número entre 0 y 100: `43` significa 43%.
Para consultarlas en pgAdmin:

```sql
SELECT tarea FROM tareas ORDER BY tarea;
SELECT emocion FROM emociones;
SELECT porcentaje FROM progreso;
```

La información técnica de sincronización y restauración se conserva aparte,
en `mova_interno.registros`. Así la API sigue separando las cuentas y evita
duplicados, sin mostrar IDs, horarios o cantidades en las tres tablas simples.
Los nombres anteriores se normalizan: `Levantarme` pasa a `Levantarse`,
`¡Genial!` pasa a `Feliz` y `Bien` pasa a `Contento`.
La migración `backend/db/wearable.sql` conserva los registros anteriores y
transforma las tablas dentro de una transacción.
El historial se conserva; al ingresar se recupera el estado más reciente.
Si se pierde la conexión después de iniciar sesión, los cambios quedan en una cola
local por cuenta y se reintentan automáticamente. No borres el almacenamiento del
navegador mientras existan cambios pendientes. Una sesión vencida requiere volver a ingresar.

`POST /api/wearable/records` guarda un registro y
`GET /api/wearable/records?limit=50` devuelve el historial de la cuenta autenticada.
Ambos requieren `Authorization: Bearer <token>`.
La pantalla Inicio de Flutter muestra las tareas, emoción y progreso del wearable
y actualiza la consulta cada 10 segundos.

Para verificar el backend: `node --test src/wearable-records.test.mjs`.
La prueba real `src/wearable-integration.mjs` se ejecuta dentro del contenedor API;
crea una base temporal aislada, comprueba migración, persistencia, columnas simples
y separación por usuario, y elimina esa base al terminar. No agrega datos de prueba
a las tablas de MOVA. Requiere permiso de crear bases de datos en el entorno local.

La implementación corresponde al simulador web del repositorio. Un reloj físico
con Wi-Fi o Internet debe usar los mismos endpoints; este repositorio no contiene
firmware del dispositivo.

## Bluetooth

Define `MOVA_BLE_SERVICE_UUID` y `MOVA_BLE_DATA_UUID` según el fabricante para habilitar la recepción de datos BLE. También configura `MOVA_API_URL` en la compilación Flutter.
