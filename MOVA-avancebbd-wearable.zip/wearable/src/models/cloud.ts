export type WearableSession = { token: string; user: { id: string; name: string; adultName?: string; email?: string; age?: string; phone?: string } }
export type ActivityAction = {
  actionId: string
  createdAt: string
  type: "add_task" | "set_done" | "remove_task" | "set_emotion"
  taskId?: string
  label?: string
  time?: string
  done?: boolean
  emotion?: string | null
}
export type WearableRecord = {
  eventId: string
  deviceId: string
  activities: { id: string; label: string; time: string; done: boolean }[]
  emotion: string | null
  recordedAt: string
  progressPercent?: number
}
