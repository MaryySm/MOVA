import { useEffect, useState } from "react"
import type { Dispatch, SetStateAction } from "react"
import type { KAct } from "../models/wearable"
import type { WearableRecord, WearableSession } from "../models/cloud"
import { wearableRequest, WearableApiError } from "./wearableApi"
import { KIDS_ACTIVITIES } from "../models/wearable"

// La cola se guarda por cuenta antes de enviarse; los UUID evitan duplicados al reintentar.
export function useWearablePersistence(session: WearableSession | undefined,
  acts: KAct[], mood: string | null, setActs: Dispatch<SetStateAction<KAct[]>>,
  setMood: Dispatch<SetStateAction<string | null>>) {
  const [status, setStatus] = useState("Inicia sesión para guardar en la base de datos")
  const [ready, setReady] = useState(false)
  const [storageFailed, setStorageFailed] = useState(false)
  const key = session ? `mova-wearable-${session.user.id}` : null

  useEffect(() => {
    if (!session || !key) return
    let stopped = false
    let sending = false
    let initialized = false
    let queue: WearableRecord[] = []
    const restore = (record: WearableRecord) => {
      if (stopped) return
      setActs(record.activities.map((a) => ({ ...a,
        icon: KIDS_ACTIVITIES.find((item) => item.id === a.id)?.icon || "✓",
        color: KIDS_ACTIVITIES.find((item) => item.id === a.id)?.color || "#A78BFA" })))
      setMood(record.emotion)
    }
    const persistQueue = () => localStorage.setItem(`${key}-queue`, JSON.stringify(queue))
    const flush = async () => {
      if (sending || stopped || !initialized) return
      sending = true
      try {
        // Lee también los nuevos registros creados desde el otro efecto.
        queue = JSON.parse(localStorage.getItem(`${key}-queue`) || "[]")
        if (!queue.length) return
        while (queue.length && !stopped) {
          const record = queue[0]
          await wearableRequest("/api/wearable/records", session.token, record)
          queue = JSON.parse(localStorage.getItem(`${key}-queue`) || "[]")
          queue = queue.filter((item) => item.eventId !== record.eventId)
          persistQueue()
        }
        if (!stopped) setStatus("Guardado en la base de datos")
      } catch (error) {
        if (!stopped) setStatus(error instanceof WearableApiError && error.status === 401
          ? "Sesión vencida. Sal e inicia sesión nuevamente."
          : "Pendiente de envío. Se reintentará automáticamente.")
      } finally { sending = false }
    }
    const initialize = async () => {
      try {
        queue = JSON.parse(localStorage.getItem(`${key}-queue`) || "[]")
        const cached = localStorage.getItem(`${key}-latest`)
        if (queue.length) restore(queue[queue.length - 1])
        else if (cached) restore(JSON.parse(cached))
        if (!queue.length) {
          try {
            const records = await wearableRequest<WearableRecord[]>("/api/wearable/records?limit=1", session.token)
            if (!stopped) setStatus(records.length ? "Guardado en la base de datos" : "Conectado. Preparando el primer registro…")
            if (records[0] && !stopped) {
              localStorage.setItem(`${key}-latest`, JSON.stringify(records[0]))
              restore(records[0])
            }
          } catch { if (!stopped) setStatus("Sin conexión. Los cambios quedarán pendientes.") }
        }
        if (!stopped) { initialized = true; setReady(true); void flush() }
      } catch {
        if (!stopped) { setStorageFailed(true); setStatus("No se puede guardar localmente. Habilita el almacenamiento del navegador.") }
      }
    }
    void initialize()
    const interval = setInterval(() => void flush(), 10000)
    const onSync = () => void flush()
    window.addEventListener("online", onSync)
    window.addEventListener("mova-wearable-sync", onSync)
    return () => {
      stopped = true
      clearInterval(interval)
      window.removeEventListener("online", onSync)
      window.removeEventListener("mova-wearable-sync", onSync)
    }
  }, [session, key, setActs, setMood])

  useEffect(() => {
    if (!ready || !key || storageFailed) return
    try {
      const record: WearableRecord = {
        eventId: crypto.randomUUID(), deviceId: "mova-kids-simulator",
        activities: acts.map(({ id, label, time, done }) => ({ id, label, time, done })),
        emotion: mood, recordedAt: new Date().toISOString(),
      }
      const previous = localStorage.getItem(`${key}-latest`)
      if (previous) {
        const cached: WearableRecord = JSON.parse(previous)
        if (JSON.stringify(cached.activities) === JSON.stringify(record.activities) && cached.emotion === mood) return
      }
      const queue: WearableRecord[] = JSON.parse(localStorage.getItem(`${key}-queue`) || "[]")
      localStorage.setItem(`${key}-queue`, JSON.stringify([...queue, record]))
      localStorage.setItem(`${key}-latest`, JSON.stringify(record))
      setStatus("Guardando…")
      window.dispatchEvent(new Event("mova-wearable-sync"))
    } catch { setStatus("No se pudo guardar el cambio localmente. Revisa el almacenamiento del navegador.") }
  }, [acts, mood, ready, key, storageFailed])

  return { status, ready: !session || ready }
}
