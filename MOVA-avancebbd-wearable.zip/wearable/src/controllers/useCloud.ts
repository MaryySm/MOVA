import { createContext, useContext, useEffect, useRef, useState } from "react"
import type { ActivityAction, WearableRecord, WearableSession } from "../models/cloud"
import { DEFAULT_USER_PROFILE } from "../models/profile"
import { saveProfiles, setActiveProfileId } from "./profileController"
import { loginWearable, wearableRequest, WearableApiError } from "./wearableApi"

const SESSION_KEY = "mova-shared-session"
type State = { activities: WearableRecord["activities"]; emotion: string | null; progressPercent: number }
const empty: State = { activities: [], emotion: null, progressPercent: 0 }
function readSession(): WearableSession | undefined {
  try { const s = JSON.parse(localStorage.getItem(SESSION_KEY) || "null"); return s?.token && s?.user?.id ? s : undefined }
  catch { return undefined }
}
function apply(state: State, action: ActivityAction): State {
  let activities = state.activities, emotion = state.emotion
  if (action.type === "add_task" && !activities.some((a) => a.id === action.taskId)) activities = [...activities, { id: action.taskId!, label: action.label!, time: action.time!, done: false }]
  if (action.type === "remove_task") activities = activities.filter((a) => a.id !== action.taskId)
  if (action.type === "set_done") activities = activities.map((a) => a.id === action.taskId ? { ...a, done: action.done! } : a)
  if (action.type === "set_emotion") emotion = action.emotion ?? null
  return { activities, emotion, progressPercent: activities.length ? Math.round(activities.filter((a) => a.done).length / activities.length * 100) : 0 }
}

export function useCloudController() {
  const [session, setSession] = useState<WearableSession | undefined>(readSession)
  const [state, setState] = useState<State>(empty)
  const [ready, setReady] = useState(false)
  const [status, setStatus] = useState("Inicia sesión en la app")
  const [error, setError] = useState("")
  const syncRef = useRef<() => void>(() => {})
  const saveSession = (value?: WearableSession) => {
    if (value) localStorage.setItem(SESSION_KEY, JSON.stringify(value))
    else localStorage.removeItem(SESSION_KEY)
    setState(empty); setReady(false); setSession(value)
    if (value) {
      saveProfiles([{ ...DEFAULT_USER_PROFILE, ...value.user, adultName: value.user.adultName || "", age: value.user.age || "", email: value.user.email || "", phone: (value.user.phone || "").replace(/^\+569/, "") }])
      setActiveProfileId(value.user.id)
    }
  }
  const login = async (email: string, password: string) => saveSession(await loginWearable(email, password))
  const register = async (body: unknown) => saveSession(await wearableRequest<WearableSession>("/api/auth/register", undefined, body))
  useEffect(() => {
    const listen = (e: StorageEvent) => { if (e.key === SESSION_KEY) { setReady(false); setState(empty); setSession(readSession()) } }
    window.addEventListener("storage", listen)
    return () => window.removeEventListener("storage", listen)
  }, [])
  useEffect(() => {
    if (!session) { setStatus("Inicia sesión en la app"); return }
    let stopped = false, working = false
    const cacheKey = `mova-current-${session.user.id}`, prefix = `mova-action-${session.user.id}-`
    const entries = () => Object.keys(localStorage).filter((key) => key.startsWith(prefix))
      .map((key) => ({ key, action: JSON.parse(localStorage.getItem(key)!) as ActivityAction }))
      .sort((a, b) => a.action.createdAt.localeCompare(b.action.createdAt))
    try {
      const cached = localStorage.getItem(cacheKey)
      if (cached) {
        const restored = entries().reduce((s, e) => apply(s, e.action), JSON.parse(cached) as State)
        setState(restored); setReady(true)
      }
    } catch { /* Puede recuperarse desde la API. */ }
    const sync = async () => {
      if (working || stopped) return
      working = true
      try {
        const legacyKey = `mova-wearable-${session.user.id}-queue`
        const legacy: WearableRecord[] = JSON.parse(localStorage.getItem(legacyKey) || "[]")
        while (legacy.length && !stopped) {
          await wearableRequest("/api/sync/legacy", session.token, legacy[0])
          legacy.shift(); localStorage.setItem(legacyKey, JSON.stringify(legacy))
        }
        for (const entry of entries()) {
          if (stopped) return
          try { await wearableRequest("/api/activities/actions", session.token, entry.action); localStorage.removeItem(entry.key) }
          catch (cause) {
            if (cause instanceof WearableApiError && cause.status === 400) { localStorage.removeItem(entry.key); if (!stopped) setError(cause.message) }
            else throw cause
          }
        }
        if (stopped) return
        const records = await wearableRequest<WearableRecord[]>("/api/wearable/records?limit=1", session.token)
        if (stopped) return
        if (!entries().length) {
          const r = records[0]
          const next: State = r ? { activities: r.activities, emotion: r.emotion, progressPercent: r.progressPercent ?? 0 } : empty
          localStorage.setItem(cacheKey, JSON.stringify(next)); setState(next); setStatus("App y wearable sincronizados")
        } else setStatus("Guardando cambios…")
        setReady(true)
      } catch (cause) {
        if (!stopped) {
          if (cause instanceof WearableApiError && cause.status === 401) { saveSession(undefined); setError("La sesión venció. Vuelve a iniciar sesión.") }
          else setStatus("Sin conexión. Los cambios quedan pendientes de envío.")
        }
      } finally { working = false }
    }
    syncRef.current = () => void sync()
    void sync()
    const interval = setInterval(() => void sync(), 2000)
    const listen = (e: StorageEvent) => {
      if (e.key?.startsWith(prefix)) {
        if (e.newValue) { try { const action = JSON.parse(e.newValue); setState((s) => apply(s, action)) } catch {} }
        void sync()
      }
    }
    const online = () => void sync()
    window.addEventListener("storage", listen); window.addEventListener("online", online)
    return () => { stopped = true; clearInterval(interval); syncRef.current = () => {}; window.removeEventListener("storage", listen); window.removeEventListener("online", online) }
  }, [session?.token, session?.user.id])
  const send = (change: Omit<ActivityAction, "actionId" | "createdAt">) => {
    if (!session || !ready) return
    const action: ActivityAction = { ...change, actionId: crypto.randomUUID(), createdAt: new Date().toISOString() }
    try {
      localStorage.setItem(`mova-action-${session.user.id}-${action.actionId}`, JSON.stringify(action))
      setState((s) => apply(s, action)); setError(""); setStatus("Guardando cambios…"); syncRef.current()
    } catch { setError("No se pudo guardar el cambio. Habilita el almacenamiento del navegador.") }
  }
  return { session, state, ready, status, error, login, register, logout: () => saveSession(undefined),
    addTask: (label: string, time: string) => send({ type: "add_task", taskId: crypto.randomUUID(), label: label.replace(/^[^\p{L}\p{N}]+/u, "").trim(), time }),
    removeTask: (taskId: string) => send({ type: "remove_task", taskId }),
    setDone: (taskId: string, done: boolean) => send({ type: "set_done", taskId, done }),
    setEmotion: (emotion: string | null) => send({ type: "set_emotion", emotion }),
  }
}
export const CloudContext = createContext<ReturnType<typeof useCloudController> | null>(null)
export function useCloud() { const value = useContext(CloudContext); if (!value) throw new Error("Falta el proveedor de sesión MOVA"); return value }
