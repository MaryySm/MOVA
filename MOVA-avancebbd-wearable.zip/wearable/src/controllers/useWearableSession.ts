import { useState } from "react"
import { WearableApiError } from "./wearableApi"
import { useCloud } from "./useCloud"

export function useWearableSession() {
  const { session, login: loginAccount, logout } = useCloud()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState("")
  const login = async () => {
    setBusy(true)
    setError("")
    try {
      await loginAccount(email, password)
      setPassword("")
    } catch (cause) {
      setError(cause instanceof WearableApiError ? cause.message : "No se pudo conectar con MOVA. Revisa que la API esté encendida.")
    } finally { setBusy(false) }
  }
  return { session, email, password, setEmail, setPassword, showPassword, setShowPassword, busy, error, login,
    logout }
}
