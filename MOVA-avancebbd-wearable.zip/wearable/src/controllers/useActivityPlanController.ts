import { useState } from "react"
import { useCloud } from "./useCloud"
export function useActivityPlanController() {
  const cloud = useCloud()
  const [label, setLabel] = useState("")
  const [time, setTime] = useState("08:00")
  const add = () => { if (label.trim() && cloud.ready) { cloud.addTask(label, time); setLabel("") } }
  return { label, setLabel, time, setTime, add, activities: cloud.state.activities,
    ready: cloud.ready, remove: cloud.removeTask, setDone: cloud.setDone }
}
