import { useEffect, useState } from "react"
import { useCloud } from "./useCloud"
import type { Screen } from "../models/navigation"
import { SCREENS_WITH_NAV } from "../models/navigation"
// Aquí conservo la pantalla actual y determino cuándo mostrar la navegación inferior.
export function usePhoneAppController() {
  const [screen, setScreen] = useState<Screen>("splash")
  const { session } = useCloud()
  useEffect(() => { setScreen(session ? "home" : "login") }, [session?.user.id])
  const go = (next: Screen) => setScreen(next)
  const visibleScreen = !session && screen !== "signup" && screen !== "splash" ? "login" : screen
  const showNav = !!session && SCREENS_WITH_NAV.includes(visibleScreen)
  return { screen: visibleScreen, go, showNav }
}
