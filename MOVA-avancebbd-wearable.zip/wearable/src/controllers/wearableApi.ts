import type { WearableSession } from "../models/cloud"

const base = (import.meta.env.VITE_MOVA_API_URL || "http://localhost:3000").replace(/\/$/, "")

export class WearableApiError extends Error {
  constructor(message: string, public status: number) { super(message) }
}

export async function wearableRequest<T>(path: string, token?: string, body?: unknown): Promise<T> {
  const response = await fetch(`${base}${path}`, {
    method: body === undefined ? "GET" : "POST",
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
    signal: AbortSignal.timeout(15000),
  })
  const data = await response.json()
  if (!response.ok) throw new WearableApiError(data.error || "No se pudo conectar con MOVA.", response.status)
  return data as T
}

export function loginWearable(email: string, password: string) {
  return wearableRequest<WearableSession>("/api/auth/login", undefined, { email, password })
}
