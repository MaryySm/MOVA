import { useEffect, useState } from "react"
import type { FormEvent } from "react"
import type { Screen } from "../models/navigation"
import type { SignupData } from "../models/profile"
import { useCloud } from "./useCloud"
import { WearableApiError } from "./wearableApi"

type SignupField = keyof SignupData

// Aquí controlo la transición automática desde la presentación al inicio de sesión.
export function useSplashController(go: (screen: Screen) => void) {
  const [opacity, setOpacity] = useState(0)

  useEffect(() => {
    const t1 = setTimeout(() => setOpacity(1), 100)
    const t2 = setTimeout(() => go("login"), 2600)
    return () => {
      clearTimeout(t1)
      clearTimeout(t2)
    }
  }, [go])

  return { opacity }
}
export function useLoginController() {
  const cloud = useCloud()
  // Mantengo los campos de acceso mientras la persona escribe.
  const [email, setEmail] = useState("")

  const [pass, setPass] = useState("")
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState("")
  const submit = async () => {
    setBusy(true); setError("")
    try { await cloud.login(email.trim(), pass); setPass("") }
    catch (cause) { setError(cause instanceof WearableApiError ? cause.message : "No se pudo conectar con MOVA.") }
    finally { setBusy(false) }
  }
  return { email, setEmail, pass, setPass, submit, busy, error }
}
export function useSignupController(go: (screen: Screen) => void) {
  // Aquí reúno, valido y envío el formulario al almacenamiento del prototipo.
  const [form, setForm] = useState<SignupData>({
    adultName: "",
    userName: "",
    age: "",
    phone: "",
    email: "",
    diagnosis: "",
    password: "",
  })
  const cloud = useCloud()
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState("")

  const [submitted, setSubmitted] = useState(false)

  const requiredFields: SignupField[] = [
    "adultName",
    "userName",
    "age",
    "phone",
    "email",
  ]

  const isValid =
    requiredFields.every((field) => form[field].trim()) &&
    form.phone.length === 8 && form.password.length >= 8

  const update = (field: keyof SignupData, value: string) =>
    setForm((current) => ({ ...current, [field]: value }))

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    setSubmitted(true)
    if (!isValid) return
    setBusy(true); setError("")
    try {
      await cloud.register({ adultName: form.adultName, name: form.userName, age: form.age,
        phone: `+569${form.phone}`, email: form.email, diagnosis: form.diagnosis, password: form.password })
      go("profile")
    } catch (cause) { setError(cause instanceof WearableApiError ? cause.message : "No se pudo crear la cuenta.") }
    finally { setBusy(false) }
  }

  return {
    form,
    submitted,
    isValid,
    update,
    submit,
    busy,
    error,
  }
}
