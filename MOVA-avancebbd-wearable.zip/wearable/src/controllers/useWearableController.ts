import { useEffect, useRef, useState } from "react"
import type { WPage } from "../models/wearable"
import { KIDS_ACTIVITIES } from "../models/wearable"
import type { WearableSession } from "../models/cloud"
import { useCloud } from "./useCloud"
// Aquí manejo el estado y las interacciones del simulador de reloj independiente.
export function useWearableController(onSOS: () => void, sosAck: boolean, session?: WearableSession) {
  const [page, setPage] = useState<WPage>("home")

  const cloud = useCloud()
  const acts = cloud.state.activities.map((a) => ({ ...a,
    icon: KIDS_ACTIVITIES.find((item) => item.id === a.id || item.label === a.label)?.icon || "✓",
    color: KIDS_ACTIVITIES.find((item) => item.id === a.id || item.label === a.label)?.color || "#A78BFA" }))
  const mood = cloud.state.emotion
  const syncStatus = cloud.status
  const ready = cloud.ready

  const [sosActive, setSosActive] = useState(false)

  const [holding, setHolding] = useState(false)

  const [holdPct, setHoldPct] = useState(0)

  const holdRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const [, setTick] = useState(0)

  useEffect(() => {
    const iv = setInterval(() => setTick((p) => p + 1), 1000)
    return () => clearInterval(iv)
  }, [])

  useEffect(() => {
    if (sosAck)
      setTimeout(() => {
        setSosActive(false)
        setPage("home")
      }, 2000)
  }, [sosAck])

  const now = new Date()

  const hh = now.toLocaleTimeString("es", {
    hour: "2-digit",
    minute: "2-digit",
  })

  const dd = now.toLocaleDateString("es", {
    weekday: "long",
    day: "numeric",
    month: "long",
  })

  const pendingCount = acts.filter((a) => !a.done).length

  const completedCount = acts.length - pendingCount

  const activityPct = acts.length ? Math.round((completedCount / acts.length) * 100) : 0

  const progressGreen = `hsl(${105 + activityPct * 0.35} 58% ${
    activityPct < 45 ? 48 : 40
  }%)`

  const toggleAct = (id: string) =>
    ready && cloud.setDone(id, !acts.find((a) => a.id === id)?.done)

  const chooseMood = (label: string) => {
    if (!ready) return
    cloud.setEmotion(label)
    setTimeout(() => setPage("home"), 600)
  }

  const startHold = () => {
    if (sosActive) return
    setHolding(true)
    let pct = 0
    holdRef.current = setInterval(() => {
      pct += 4
      setHoldPct(pct)
      if (pct >= 100) {
        clearInterval(holdRef.current!)
        setHolding(false)
        setHoldPct(0)
        setSosActive(true)
        setPage("sos")
        onSOS()
      }
    }, 100)
  }

  const cancelHold = () => {
    if (holdRef.current) clearInterval(holdRef.current)
    setHolding(false)
    setHoldPct(0)
  }

  useEffect(
    () => () => {
      if (holdRef.current) clearInterval(holdRef.current)
    },
    [],
  )

  return {
    syncStatus,
    page,
    setPage,
    acts,
    mood,
    sosActive,
    holding,
    holdPct,
    hh,
    dd,
    pendingCount,
    activityPct,
    progressGreen,
    toggleAct,
    chooseMood,
    startHold,
    cancelHold,
  }
}
