import type { ReactNode } from "react"
import { CloudContext, useCloudController } from "../../controllers/useCloud"
export default function CloudProvider({ children }: { children: ReactNode }) {
  const value = useCloudController()
  return <CloudContext.Provider value={value}>{children}</CloudContext.Provider>
}
