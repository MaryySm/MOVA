import { cssVar, cssVars } from "../styleVars";
import { TEXT_MED } from "../theme"
import "./WearableOnly.styles.css";
import { WearableDevice } from "./WearableDevice"
import { useWearableSession } from "../../controllers/useWearableSession"

// Aquí presento el simulador MOVA Kids separado visualmente de la app móvil.
export function WearableOnly({ embedded = false }: { embedded?: boolean }) {
  const { session, email, password, setEmail, setPassword, showPassword, setShowPassword, busy, error, login, logout } = useWearableSession()
  return (
    <main
      data-mova-style="wearable-only-s0"
      className={embedded ? "wearable-embedded" : undefined}
    >
      <div data-mova-style="wearable-only-s1">
        <div
          data-mova-style="wearable-only-s2"
        />
        <span
          data-mova-style="wearable-only-s3" style={cssVars({ "--mova-wearable-only-s3-color": cssVar((TEXT_MED), true) })}
        >
          MOVA KIDS
        </span>
      </div>
      <div
        data-mova-style="wearable-only-s4"
      />
      {session ? <>
        <p className="wearable-account">Cuenta de {session.user.name} · <button onClick={logout}>Salir</button></p>
        <WearableDevice key={session.user.id} session={session} onSOS={() => {}} sosAck={false} />
      </> : embedded ? <p className="wearable-awaiting">Inicia sesión en la app.<br />El wearable se conectará automáticamente.</p> : <form className="wearable-login" onSubmit={(event) => { event.preventDefault(); void login() }}>
        <h1>Conectar MOVA Kids</h1>
        <p>Usa la misma cuenta de tu app para guardar tareas, emociones y progreso.</p>
        <label>Correo<input type="email" name="email" autoComplete="username" autoCapitalize="none" spellCheck={false} required value={email} onChange={(event) => setEmail(event.target.value)} /></label>
        <label>Contraseña<input type={showPassword ? "text" : "password"} name="password" autoComplete="current-password" required value={password} onChange={(event) => setPassword(event.target.value)} /></label>
        <button type="button" aria-pressed={showPassword} onClick={() => setShowPassword(!showPassword)}>{showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}</button>
        <button disabled={busy} type="submit">{busy ? "Conectando…" : "Conectar a mi cuenta"}</button>
        {error && <p role="alert">{error}</p>}
      </form>}
      <div
        data-mova-style="wearable-only-s5"
      />
    </main>
  )
}
