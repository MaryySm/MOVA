import type { Screen } from "../../models/navigation"
import { useActivityPlanController } from "../../controllers/useActivityPlanController"
import "./ActivityPlanScreen.styles.css"
export default function ActivityPlanScreen({ go }: { go: (screen: Screen) => void }) {
  const { label, setLabel, time, setTime, add, activities, ready, remove, setDone } = useActivityPlanController()
  return <section className="activity-plan">
    <button className="activity-back" onClick={() => go("home")}>← Volver a Inicio</button>
    <h1>Actividades del wearable</h1>
    <p>Agrega una actividad y aparecerá automáticamente en MOVA Kids.</p>
    <form onSubmit={(event) => { event.preventDefault(); add() }}>
      <label>Actividad<input required maxLength={200} placeholder="Ej. Leer un cuento" value={label} onChange={(event) => setLabel(event.target.value)} /></label>
      <label>Hora<input type="time" required value={time} onChange={(event) => setTime(event.target.value)} /></label>
      <button disabled={!ready || !label.trim()} type="submit">Agregar actividad</button>
    </form>
    <h2>Mi rutina</h2>
    {!activities.length && <p>Aún no hay actividades. Agrega la primera para comenzar.</p>}
    <ul>{activities.map((task) => <li key={task.id}>
      <label><input type="checkbox" checked={task.done} disabled={!ready} onChange={(event) => setDone(task.id, event.target.checked)} />
        <span>{task.label}<small>{task.time}</small></span></label>
      <button disabled={!ready} aria-label={`Quitar ${task.label}`} onClick={() => remove(task.id)}>Quitar</button>
    </li>)}</ul>
  </section>
}
