export type ChildProfile = {
  id: string; name: string; age: string; photo: string;
  notifications: { vibration: boolean; sound: boolean; lights: boolean; intensity: number }
}
export type PlannedActivity = {
  id: string; label: string; date: string; time: string; duration: number; done: boolean;
  updatedAt?: string; pending?: boolean
}
export type EmotionValue = { label: string; intensity: number }
export type EmotionalReport = {
  id: string; emotions: EmotionValue[]; note: string; tags: string[]; recordedAt: string; receivedAt: string
}
export type DailyEmotion = { date: string; intensity: number; count: number }
export type DeviceData = {
  id: string; profile_id: string; nombre: string; tipo: 'simulator' | 'hardware'; last_seen: string | null;
  bateria: number | null; bateria_at: string | null; pasos: number | null; pasos_fecha: string | null;
  pasos_at: string | null; lat: number | null; lng: number | null; location_at: string | null
}
export type SosAlert = {
  id: string; profile_id: string; device_id: string; recorded_at: string; received_at: string; acknowledged_at: string | null
}
export type PanelData = {
  activities: PlannedActivity[]; emotion: string | null; progressPercent: number; date: string; serverTime?: string;
  emotionalReport: { emotions: EmotionValue[]; recordedAt: string } | null;
  device: DeviceData | null; alerts: SosAlert[]
}
export type ActivityChange = {
  type: 'add_task' | 'edit_task' | 'set_done' | 'remove_task'; taskId: string;
  label?: string; date?: string; time?: string; duration?: number; done?: boolean
}
export type PendingOperation = {
  eventId: string; profileId: string; kind: 'activities' | 'emotions' | 'sos'; createdAt: string;
  body: Record<string, unknown>; change?: ActivityChange
}
export const DEFAULT_NOTIFICATIONS = { vibration: true, sound: true, lights: true, intensity: 6 }
export const EMOTION_OPTIONS = [
  { label: 'Feliz', emoji: '😄' }, { label: 'Contento', emoji: '🙂' }, { label: 'Neutral', emoji: '😐' },
  { label: 'Cansado', emoji: '😴' }, { label: 'Triste', emoji: '😢' }, { label: 'Enojado', emoji: '😠' },
]
export const localDay = (date = new Date()) => date.toLocaleDateString('en-CA', { timeZone: 'America/Santiago' })
export const dayDate = (day: string) => new Date(`${day}T12:00:00`)
export const dateLabel = (day: string) => dayDate(day).toLocaleDateString('es-CL', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })
export const timestampLabel = (date?: string | null) => date ? new Date(date).toLocaleString('es-CL', {timeZone: 'America/Santiago'}) : 'Sin datos'
export const freshness = (date?: string | null) => !date ? 'Sin datos' : Date.now() - Date.parse(date) <= 300000 ? 'Reciente' : 'Dato antiguo'
