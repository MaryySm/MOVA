export type Screen = "splash" | "login" | "signup" | "profile" | "weekly" | "home" | "routines" | "calendar" | "emotions" | "device" | "settings"
export const SCREENS_WITH_NAV: Screen[] = [
  "home",
  "routines",
  "calendar",
  "emotions",
  "settings",
]
