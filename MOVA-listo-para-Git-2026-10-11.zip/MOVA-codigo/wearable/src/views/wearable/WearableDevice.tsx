import type { WearableSession } from '../../models/cloud'
import { EMOTION_OPTIONS } from '../../models/requirements'
import { useWearableController } from '../../controllers/useWearableController'
import '../Requirements.styles.css'
export function WearableDevice(_props:{onSOS?:()=>void;sosAck?:boolean;session?:WearableSession}) {
  const c=useWearableController(),cloud=c.cloud
  return <div><p role="status" className="wearable-sync-status">{cloud.status}</p>
    <div className="mova-watch" aria-label={`Simulador MOVA Kids de ${cloud.profile?.name||'usuario'}`}>
      <small>{cloud.profile?.name} · Batería: {cloud.state.device?.bateria==null?'sin datos':`${cloud.state.device.bateria}%`}</small>
      {c.page!=='home'&&<button aria-label="Volver al inicio sin guardar una selección incompleta" onClick={c.back}>← Volver</button>}
      {c.page==='home'&&<><div className="watch-clock">{c.hh}</div><small>{c.dd} · Hora del simulador</small>
        <div className="watch-emotions"><button onClick={()=>c.setPage('activities')}>Actividades ({cloud.state.activities.filter(a=>!a.done).length})</button>
          <button onClick={()=>c.setPage('emotions')}>{cloud.state.emotion||'Estado'}</button></div>
        <small>Progreso confirmado: {cloud.state.progressPercent}%</small><progress max={100} value={cloud.state.progressPercent}/>
        <button className="watch-sos" disabled={!cloud.ready||!cloud.state.device} aria-label="Mantener pulsado durante 2,5 segundos para solicitar ayuda"
          onPointerDown={c.startHold} onPointerUp={c.cancelHold} onPointerLeave={c.cancelHold} onPointerCancel={c.cancelHold} onBlur={c.cancelHold}
          onKeyDown={e=>{if((e.key===' '||e.key==='Enter')&&!e.repeat){e.preventDefault();c.startHold()}}}
          onKeyUp={e=>{if(e.key===' '||e.key==='Enter')c.cancelHold()}}>{c.holdPct?`SOS ${Math.round(c.holdPct)}%`:'SOS · mantener pulsado'}</button>
        {!cloud.state.device&&<small>El adulto debe vincular este simulador desde Ajustes.</small>}</>}
      {c.page==='activities'&&<><h2>Mis actividades</h2><div className="watch-scroll">
        {!cloud.state.activities.length&&<p>No hay actividades para hoy.</p>}
        {cloud.state.activities.map(a=><button key={a.id} className="watch-task" disabled={!cloud.ready||a.pending}
          aria-label={`${a.label}, ${a.time}, ${a.pending?'pendiente de sincronización':a.done?'completada':'por hacer'}`}
          onClick={()=>cloud.setDone(a.id,!a.done)}><span>{a.done?'☑':'☐'} {a.label}<small>{a.time} · {a.pending?'Pendiente':a.done?'Completada':'Por hacer'}</small></span></button>)}
      </div></>}
      {c.page==='emotions'&&<><h2>¿Cómo te sientes?</h2><div className="watch-scroll watch-emotions">
        {EMOTION_OPTIONS.map(e=><button key={e.label} onClick={()=>c.chooseMood(e.label)}><span aria-hidden="true">{e.emoji}</span> {e.label}</button>)}
      </div></>}
      {c.page==='intensity'&&<><h2>{c.draftEmotion}: {c.intensity}%</h2><small>¿Cuánto sientes esta emoción?</small>
        <input type="range" min={0} max={100} value={c.intensity} disabled={!!c.emotionId} aria-label={`Intensidad de ${c.draftEmotion}`} onChange={e=>c.setIntensity(Number(e.target.value))}/>
        <div className="watch-emotions"><button disabled={!!c.emotionId} aria-label="Disminuir intensidad 5 puntos" onClick={()=>c.setIntensity(Math.max(0,c.intensity-5))}>−5</button>
          <button disabled={!!c.emotionId} aria-label="Aumentar intensidad 5 puntos" onClick={()=>c.setIntensity(Math.min(100,c.intensity+5))}>+5</button></div>
        <button disabled={!cloud.ready||!!c.emotionId} onClick={c.saveMood}>Guardar emoción</button>
        {c.emotionId&&<small role="status">{c.emotionPending?'Pendiente de envío':cloud.error?'No se pudo confirmar':'Registro recibido en la base de datos'}</small>}</>}
      {c.page==='sos'&&<><h2>Solicitud de ayuda</h2><p role="status">{c.sosStatus}</p><small>Recibido en el servidor no significa que el adulto ya lo haya visto.</small>
        <button onClick={cloud.refresh}>Reintentar conexión</button></>}
    </div>{cloud.error&&<p role="alert">{cloud.error}</p>}
  </div>
}
