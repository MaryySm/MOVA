import { cssVar, cssVars } from "./styleVars";
import { usePhoneAppController } from "../controllers/usePhoneAppController"
import "./PhoneApp.styles.css";
import { BottomNav } from "./shared/Navigation"
import { THEME } from "./theme"
import { LoginScreen, SignupScreen, SplashScreen } from "./screens/EntryScreens"
import { HomeScreen } from "./screens/HomeScreen"
import { RoutinesScreen } from "./screens/RoutinesScreen"
import { CalendarScreen } from "./screens/CalendarScreen"
import { EmotionsScreen } from "./screens/EmotionsScreen"
import { DeviceScreen } from "./screens/DeviceScreen"
import { SettingsScreen } from "./screens/SettingsScreen"
import ActivityPlanScreen from "./screens/ActivityPlanScreen"
import { WeeklyPlanScreen } from './screens/WeeklyPlanScreen'
import './Requirements.styles.css'
import { WearableOnly } from "./wearable/WearableOnly"
import { useCloud } from "../controllers/useCloud"

// Aquí compongo la experiencia móvil y conecto cada pantalla con la navegación.
export default function PhoneApp() {
  const { screen, go, showNav } = usePhoneAppController()
  const cloud = useCloud()

  return (
    <div
      data-mova-style="phone-app-s0"
    >
      <div
        data-mova-style="phone-app-s1"
      >
        <span
          data-mova-style="phone-app-s2"
        >
          📱 TELÉFONO PRINCIPAL
        </span>
        {cloud.session && <div className="cloud-toolbar">
          <button onClick={() => go("profile")}>+ Agregar actividad</button>
          <button onClick={cloud.logout}>Salir</button>
          <p role="status">{cloud.status}</p>
          <button onClick={cloud.refresh}>Reintentar / actualizar</button>
          {cloud.error && <p role="alert" className="cloud-error">{cloud.error}</p>}
        </div>}

        <div
          data-mova-style="phone-app-s3" style={cssVars({ "--mova-phone-app-s3-background": cssVar((THEME[screen === 'weekly' ? 'profile' : screen].bg), true) })}
        >
          <div
            data-mova-style="phone-app-s4" style={cssVars({ "--mova-phone-app-s4-background": cssVar((THEME[screen === 'weekly' ? 'profile' : screen].bg), true) })}
          />

          {screen === "splash" && <SplashScreen go={go} />}
          {screen === "login" && <LoginScreen go={go} />}
          {screen === "signup" && <SignupScreen go={go} />}
          {screen === "profile" && <ActivityPlanScreen go={go} />}
          {screen === 'weekly' && <WeeklyPlanScreen go={go}/>}
          {screen === "home" && <HomeScreen go={go} />}
          {screen === "routines" && <RoutinesScreen go={go} />}
          {screen === "calendar" && <CalendarScreen go={go} />}
          {screen === "emotions" && <EmotionsScreen />}
          {screen === "device" && <DeviceScreen go={go} />}
          {screen === "settings" && <SettingsScreen />}
          {showNav && <BottomNav screen={screen} go={go} />}
        </div>
      </div>
      <WearableOnly embedded />
    </div>
  )
}
