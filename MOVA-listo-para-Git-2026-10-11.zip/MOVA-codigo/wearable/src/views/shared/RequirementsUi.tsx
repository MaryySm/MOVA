import type { PlannedActivity } from '../../models/requirements'
import { dateLabel } from '../../models/requirements'
import { useCloud } from '../../controllers/useCloud'
import { useActivityEditor } from '../../controllers/useRequirements'

export function ProfileSelector() {
  const cloud=useCloud()
  return <label className="mova-field">Perfil del usuario
    <select value={cloud.activeProfileId} onChange={e=>cloud.selectProfile(e.target.value)} disabled={!cloud.profiles.length}>
      {cloud.profiles.map(p=><option key={p.id} value={p.id}>{p.name} · {p.age} años</option>)}
    </select>
  </label>
}
export function ActivityEditor({date,activity,onClose}:{date:string;activity?:PlannedActivity;onClose:()=>void}) {
  const c=useActivityEditor(date,activity)
  return <section className="mova-card" aria-label={activity?'Editar actividad':'Nueva actividad'}>
    <h3>{activity?'Editar actividad':'Nueva actividad'}</h3>
    <form onSubmit={e=>{e.preventDefault();c.submit()}}>
      <label className="mova-field">Nombre (obligatorio)<input required maxLength={200} value={c.label} onChange={e=>c.setLabel(e.target.value)} disabled={!!c.savedId}/></label>
      <label className="mova-field">Fecha<input type="date" required value={c.date} onChange={e=>c.setDate(e.target.value)} disabled={!!c.savedId}/></label>
      <div className="mova-row">
        <label className="mova-field">Hora<input type="time" required value={c.time} onChange={e=>c.setTime(e.target.value)} disabled={!!c.savedId}/></label>
        <label className="mova-field">Duración (minutos)<input type="number" min={1} max={1440} required value={c.duration} onChange={e=>c.setDuration(Number(e.target.value))} disabled={!!c.savedId}/></label>
      </div>
      <div className="mova-row"><button type="submit" disabled={!c.ready||!!c.savedId}>Guardar actividad</button>
        <button type="button" className="mova-secondary" onClick={onClose}>{c.saved?'Cerrar':'Cancelar'}</button></div>
      {c.savedId&&<p role="status">{c.pending?'Pendiente de envío. Se guardará al recuperar la conexión.':c.saved?'Actividad guardada en la base de datos.':'No se pudo confirmar el guardado. Revisa el aviso de la app.'}</p>}
    </form>
  </section>
}
export function ActivityList({activities,onEdit}:{activities:PlannedActivity[];onEdit?:(activity:PlannedActivity)=>void}) {
  const cloud=useCloud()
  return <ul className="mova-activities">{activities.map(a=><li key={a.id} className="mova-card">
    <label className="mova-task"><input type="checkbox" checked={a.done} disabled={!cloud.ready||a.pending}
      onChange={e=>cloud.setDone(a.id,e.target.checked)}/>
      <span><strong>{a.label}</strong><small>{a.time} · {a.duration} min · {a.pending?'Pendiente de sincronización':a.done?'Completada':'Por hacer'}</small></span></label>
    <div className="mova-row">
      {onEdit&&<button className="mova-secondary" onClick={()=>onEdit(a)} disabled={a.pending}>Ver detalle / editar</button>}
      <button className="mova-secondary" disabled={!cloud.ready||a.pending} onClick={()=>{
        if(window.confirm(`¿Quitar “${a.label}” de ${dateLabel(a.date)}? Se conservará el registro histórico.`))cloud.removeTask(a.id)
      }}>Quitar de este día</button>
    </div>
  </li>)}</ul>
}
