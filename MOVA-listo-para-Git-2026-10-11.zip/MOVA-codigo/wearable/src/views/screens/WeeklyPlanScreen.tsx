import { useState } from 'react'
import type { Screen } from '../../models/navigation'
import type { PlannedActivity } from '../../models/requirements'
import { dateLabel, dayDate } from '../../models/requirements'
import { useCloud } from '../../controllers/useCloud'
import { useWeeklyPlan } from '../../controllers/useRequirements'
import { ActivityEditor, ActivityList, ProfileSelector } from '../shared/RequirementsUi'
export function WeeklyPlanScreen({go}:{go:(screen:Screen)=>void}) {
  const cloud=useCloud(),c=useWeeklyPlan()
  const [editing,setEditing]=useState<PlannedActivity>()
  return <section className="mova-screen"><h1>Planificación Semanal</h1><ProfileSelector/>
    <p>{dateLabel(c.days[0])} a {dateLabel(c.days[6])}</p>
    <div className="mova-week">{c.days.map(day=><button key={day} aria-pressed={cloud.planningDate===day} onClick={()=>cloud.setPlanningDate(day)}
      aria-label={`${dateLabel(day)}: ${c.events.filter(a=>a.date===day).length} actividades`}>
      {dayDate(day).toLocaleDateString('es-CL',{weekday:'short'})}<br/>{dayDate(day).getDate()}<small>{c.events.filter(a=>a.date===day).length} act.</small></button>)}</div>
    <h2>{dateLabel(cloud.planningDate)}</h2>
    {c.error&&<p role="alert">{c.error}</p>}
    {editing&&<ActivityEditor key={`${cloud.activeProfileId}-${editing.id}`} date={editing.date} activity={editing} onClose={()=>setEditing(undefined)}/>}
    <ActivityList activities={c.events.filter(a=>a.date===cloud.planningDate)} onEdit={setEditing}/>
    <button disabled={!c.ready} onClick={()=>go('profile')}>+ Agregar actividad</button>
    <p role="status">{cloud.pending.length?'Hay cambios pendientes de envío.':'La lista muestra las actividades guardadas en la base de datos.'}</p>
    <button className="mova-secondary" disabled={cloud.pending.length>0||!c.ready} onClick={()=>go('routines')}>Guardar y continuar a Rutinas</button>
    <button className="mova-secondary" onClick={c.reload}>Reintentar / actualizar</button>
  </section>
}
