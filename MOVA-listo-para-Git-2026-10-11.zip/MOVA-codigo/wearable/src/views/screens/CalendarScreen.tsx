import { useState } from 'react'
import type { Screen } from '../../models/navigation'
import type { PlannedActivity } from '../../models/requirements'
import { dateLabel, localDay } from '../../models/requirements'
import { useCloud } from '../../controllers/useCloud'
import { useAgenda } from '../../controllers/useRequirements'
import { ActivityEditor, ActivityList, ProfileSelector } from '../shared/RequirementsUi'
export function CalendarScreen({go}:{go:(screen:Screen)=>void}) {
  const cloud=useCloud(),c=useAgenda()
  const [editing,setEditing]=useState<PlannedActivity>()
  return <section className="mova-screen"><h1>Agenda</h1><ProfileSelector/>
    <div className="mova-row"><button aria-label="Mes anterior" onClick={()=>c.changeMonth(-1)}>‹</button>
      <h2>{c.month.toLocaleDateString('es-CL',{month:'long',year:'numeric'})}</h2><button aria-label="Mes siguiente" onClick={()=>c.changeMonth(1)}>›</button></div>
    <p><small>El contador indica cuántas actividades hay en cada fecha.</small></p>
    <div className="mova-calendar" aria-label="Calendario mensual">
      {['L','M','X','J','V','S','D'].map((d,i)=><strong key={i} aria-hidden="true">{d}</strong>)}
      {c.weeks.flat().map((day,i)=>day==null?<span key={i}/>:<button key={i} aria-pressed={c.dateFor(day)===c.selected}
        aria-label={`${dateLabel(c.dateFor(day))}, ${c.events.filter(a=>a.date===c.dateFor(day)).length} actividades${c.dateFor(day)===localDay()?', hoy':''}`}
        onClick={()=>c.selectDay(day)}>{day}<small>{c.events.filter(a=>a.date===c.dateFor(day)).length} act.</small></button>)}
    </div>
    <h2>{dateLabel(c.selected)}</h2>
    {c.error&&<p role="alert">{c.error}</p>}
    {c.ready&&!c.scheduled.length&&<p>No hay actividades para esta fecha. Puedes planificar una.</p>}
    {!c.ready&&<p role="status">Consultando actividades…</p>}
    {editing&&<ActivityEditor key={`${cloud.activeProfileId}-${editing.id}`} date={editing.date} activity={editing} onClose={()=>setEditing(undefined)}/>}
    <ActivityList activities={c.scheduled} onEdit={setEditing}/>
    <button onClick={()=>go('profile')}>+ Agregar actividad para esta fecha</button>
    <button className="mova-secondary" onClick={c.reload}>Actualizar agenda</button>
  </section>
}
