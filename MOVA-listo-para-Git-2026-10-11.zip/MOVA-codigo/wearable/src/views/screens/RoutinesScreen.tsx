import { useState } from 'react'
import type { Screen } from '../../models/navigation'
import type { PlannedActivity } from '../../models/requirements'
import { localDay } from '../../models/requirements'
import { useCloud } from '../../controllers/useCloud'
import { ActivityEditor, ActivityList, ProfileSelector } from '../shared/RequirementsUi'
export function RoutinesScreen({go}:{go:(screen:Screen)=>void}) {
  const cloud=useCloud()
  const [editing,setEditing]=useState<PlannedActivity>()
  return <section className="mova-screen"><h1>Mis Rutinas</h1><ProfileSelector/>
    <button onClick={()=>{cloud.setPlanningDate(localDay());go('weekly')}}>+ Planificar la semana</button>
    <section className="mova-card"><h2>Progreso confirmado de hoy</h2><p>{cloud.confirmedActivities.filter(a=>a.done).length} completadas · {cloud.confirmedActivities.length} actividades confirmadas</p>
      <p>{cloud.state.progressPercent}%</p><progress value={cloud.state.progressPercent} max={100} aria-label="Progreso confirmado de hoy"/></section>
    {editing&&<ActivityEditor key={`${cloud.activeProfileId}-${editing.id}`} date={editing.date} activity={editing} onClose={()=>setEditing(undefined)}/>}
    {['Mañana','Tarde','Noche'].map((slot,i)=>{
      const tasks=cloud.state.activities.filter(a=>{const h=Number(a.time.slice(0,2));return i===0?h<12:i===1?h>=12&&h<19:h>=19})
      const saved=cloud.confirmedActivities.filter(a=>{const h=Number(a.time.slice(0,2));return i===0?h<12:i===1?h>=12&&h<19:h>=19})
      return <details className="mova-card" key={slot} open={i===0}><summary>{slot} · {i===0?'00:00–11:59':i===1?'12:00–18:59':'19:00–23:59'} · {saved.filter(a=>a.done).length}/{saved.length} confirmadas</summary>
        <ActivityList activities={tasks} onEdit={setEditing}/>
        {!tasks.length&&<p>No hay tareas en este bloque.</p>}
        <button onClick={()=>{cloud.setPlanningDate(localDay());cloud.setPlanningTime(slot==='Mañana'?'08:00':slot==='Tarde'?'15:00':'20:00');go('profile')}}>+ Añadir tarea a {slot}</button>
      </details>
    })}
  </section>
}
