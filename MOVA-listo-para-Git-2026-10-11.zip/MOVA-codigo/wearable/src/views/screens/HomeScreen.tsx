import { useState } from 'react'
import type { Screen } from '../../models/navigation'
import { useCloud } from '../../controllers/useCloud'
import { useDeviceActions } from '../../controllers/useDeviceActions'
import { dateLabel, localDay, timestampLabel, freshness } from '../../models/requirements'
import type { PlannedActivity } from '../../models/requirements'
import { ActivityEditor, ActivityList, ProfileSelector } from '../shared/RequirementsUi'
export function HomeScreen({go}:{go:(screen:Screen)=>void}) {
  const cloud=useCloud(),deviceActions=useDeviceActions()
  const [notifications,setNotifications]=useState(false)
  const [editing,setEditing]=useState<PlannedActivity>()
  const pendingAlerts=cloud.state.alerts.filter(a=>!a.acknowledged_at)
  const device=cloud.state.device
  return <section className="mova-screen">
    <small>{dateLabel(localDay())}</small><h1>¡Hola, {cloud.profile?.name||'usuario'}!</h1>
    <ProfileSelector/><small>Adulto responsable: {cloud.session?.user.adultName}</small>
    <div className="mova-row"><button onClick={()=>setNotifications(!notifications)} aria-expanded={notifications}>Notificaciones ({pendingAlerts.length} pendientes)</button>
      <button className="mova-secondary" onClick={()=>go('settings')}>Opciones del perfil</button></div>
    {notifications&&<section className="mova-card"><h2>Solicitudes de ayuda</h2>
      {!cloud.state.alerts.length&&<p>No hay alertas recibidas para este perfil.</p>}
      {cloud.state.alerts.map(a=><article key={a.id}><strong>SOS de {cloud.profile?.name}</strong><small>Recibido en el servidor: {timestampLabel(a.received_at)}</small>
        <p>{a.acknowledged_at?`Visto por el adulto: ${timestampLabel(a.acknowledged_at)}`:'Pendiente de confirmación del adulto'}</p>
        {!a.acknowledged_at&&<button disabled={deviceActions.busy} onClick={()=>deviceActions.acknowledge(a.id)}>Confirmar que vi la solicitud</button>}</article>)}
      {deviceActions.message&&<p role="status">{deviceActions.message}</p>}</section>}
    <section className="mova-card"><h2>Último autorreporte emocional</h2>
      {cloud.state.emotionalReport?<><p>{cloud.state.emotionalReport.emotions.map(e=>`${e.label}: ${e.intensity}%`).join(' · ')}</p>
        <small>{timestampLabel(cloud.state.emotionalReport.recordedAt)} · {freshness(cloud.state.emotionalReport.recordedAt)}</small></>:<p>Sin registros emocionales con intensidad.</p>}
      <button className="mova-secondary" onClick={()=>go('emotions')}>Ver más / registrar emociones</button></section>
    <section className="mova-card"><h2>Ubicación disponible</h2>
      {device?.lat!=null&&device.lng!=null?<><p>Latitud {device.lat} · Longitud {device.lng}</p><small>{timestampLabel(device.location_at)} · {freshness(device.location_at)}</small></>:<p>No hay una ubicación reportada por el dispositivo de este perfil.</p>}
      <button className="mova-secondary" onClick={()=>go('device')}>Ver mapa y dispositivo</button></section>
    <section className="mova-card"><h2>Progreso confirmado de hoy</h2><p>{cloud.state.progressPercent}% completado</p>
      <progress value={cloud.state.progressPercent} max={100} aria-label="Progreso confirmado de las actividades de hoy"/>
      {cloud.pending.length>0&&<small>Los cambios pendientes aún no se incluyen en el progreso confirmado.</small>}</section>
    {editing&&<ActivityEditor key={`${cloud.activeProfileId}-${editing.id}`} activity={editing} date={editing.date} onClose={()=>setEditing(undefined)}/>}
    {['Mañana','Tarde','Noche'].map((slot,i)=>{
      const tasks=cloud.state.activities.filter(a=>{const h=Number(a.time.slice(0,2));return i===0?h<12:i===1?h>=12&&h<19:h>=19})
      return <section key={slot}><h2>{slot}</h2>{tasks.length?<ActivityList activities={tasks} onEdit={setEditing}/>:<p>Sin actividades para este bloque.</p>}</section>
    })}
    <button onClick={()=>{cloud.setPlanningDate(localDay());go('profile')}}>Agregar actividad para hoy</button>
  </section>
}
