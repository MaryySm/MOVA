import { useState } from 'react'
import { useCloud } from '../../controllers/useCloud'
import { useProfileEditor } from '../../controllers/useRequirements'
import { useDeviceActions } from '../../controllers/useDeviceActions'
import { timestampLabel, freshness } from '../../models/requirements'
import { ProfileSelector } from '../shared/RequirementsUi'
import packageInfo from '../../../package.json'
export function SettingsScreen() {
  const cloud=useCloud(),c=useProfileEditor(),actions=useDeviceActions()
  const [info,setInfo]=useState('')
  const device=cloud.state.device
  return <section className="mova-screen"><h1>Ajustes</h1><ProfileSelector/>
    <section className="mova-card"><h2>Perfil del niño / usuario del wearable</h2>
      {cloud.profile?.photo&&<img className="mova-photo" src={cloud.profile.photo} alt={`Fotografía de ${cloud.profile.name}`}/>}
      <p>{cloud.profile?.name} · {cloud.profile?.age} años</p>
      <div className="mova-row"><button disabled={!cloud.online} onClick={()=>c.open(cloud.profile)}>Editar perfil del usuario</button>
        <button className="mova-secondary" disabled={!cloud.online} onClick={()=>c.open()}>+ Perfil</button></div></section>
    {c.draft&&<section className="mova-card"><h2>Datos del usuario del wearable</h2>
      <form onSubmit={e=>{e.preventDefault();void c.save()}}>
        <label className="mova-field">Nombre (obligatorio)<input required maxLength={160} value={c.draft.name} onChange={e=>c.setDraft(p=>p?{...p,name:e.target.value}:p)}/></label>
        <label className="mova-field">Edad (1 a 120 años)<input required type="number" min={1} max={120} value={c.draft.age} onChange={e=>c.setDraft(p=>p?{...p,age:e.target.value}:p)}/></label>
        <label className="mova-field">Foto opcional (hasta 100 KB)<input type="file" accept="image/jpeg,image/png,image/webp" onChange={e=>c.photo(e.target.files?.[0])}/></label>
        <h3>Preferencias del perfil</h3>
        {(['vibration','sound','lights'] as const).map((key,i)=><label className="mova-task" key={key}>
          <input type="checkbox" checked={c.draft!.notifications[key]} onChange={e=>c.setDraft(p=>p?{...p,notifications:{...p.notifications,[key]:e.target.checked}}:p)}/>
          {['Vibración','Sonido','Luces'][i]}</label>)}
        <label className="mova-field">Intensidad de vibración: {c.draft.notifications.intensity}/10<input type="range" min={1} max={10} disabled={!c.draft.notifications.vibration}
          value={c.draft.notifications.intensity} onChange={e=>c.setDraft(p=>p?{...p,notifications:{...p.notifications,intensity:Number(e.target.value)}}:p)}/></label>
        <p><small>Las solicitudes SOS permanecen visibles y no se pueden desactivar con estas preferencias. Los efectos físicos requieren hardware compatible.</small></p>
        <div className="mova-row"><button disabled={c.busy} type="submit">{c.busy?'Guardando…':'Guardar perfil y preferencias'}</button>
          <button className="mova-secondary" type="button" onClick={c.cancel} disabled={c.busy}>Cancelar</button></div>
      </form></section>}
    {c.message&&<p role="status">{c.message}</p>}
    <section className="mova-card"><h2>Cuenta del adulto responsable</h2>
      <p>{cloud.session?.user.adultName}</p><p>{cloud.session?.user.email}</p><p>{cloud.session?.user.phone}</p>
      <small>Esta cuenta autoriza el acceso a los perfiles. Los datos del niño se editan en su tarjeta.</small></section>
    <section className="mova-card"><h2>Privacidad y seguridad</h2><p>Los perfiles y registros solo se consultan con la sesión de esta cuenta. Cada perfil tiene sus propias actividades y emociones.</p>
      <p>El dispositivo conserva datos y cambios pendientes de esta cuenta para trabajar sin conexión. Cierra sesión al usar un equipo compartido.</p></section>
    <section className="mova-card"><h2>Idioma</h2><p>Español</p><small>Actualmente es el único idioma incorporado.</small></section>
    <section className="mova-card"><h2>Dispositivo MOVA</h2>
      {device?<><p>{device.nombre}</p><p>Batería: {device.bateria==null?'Sin datos':`${device.bateria}%`}</p><small>{timestampLabel(device.bateria_at)} · {freshness(device.bateria_at)}</small>
        <p>Último contacto: {timestampLabel(device.last_seen)}</p></>:<><p>Sin dispositivo vinculado.</p><button disabled={actions.busy||!cloud.online} onClick={actions.linkSimulator}>Vincular simulador MOVA Kids</button></>}
      {actions.message&&<p role="status">{actions.message}</p>}</section>
    <details className="mova-card"><summary>Centro de ayuda</summary><p>1. Crea o selecciona un perfil en Ajustes. 2. Agrega actividades con fecha y hora. 3. Vincula el simulador al mismo perfil. 4. Comprueba los estados de guardado.</p>
      <p>Sin conexión, las tareas y autorreportes quedan pendientes. Usa «Reintentar» al recuperar la conexión. Un SOS recibido por el servidor aparece en Notificaciones; el adulto debe confirmar que lo vio.</p></details>
    <button className="mova-secondary" onClick={()=>setInfo('Los términos y la política de privacidad definitivos están pendientes de aprobación antes de publicar MOVA.')}>Términos y privacidad</button>
    <button className="mova-secondary" onClick={()=>setInfo('La valoración estará disponible cuando MOVA tenga una página publicada en la tienda de aplicaciones.')}>Valorar MOVA</button>
    {info&&<p role="status">{info}</p>}
    <p><small>Versión {packageInfo.version} · Compilación {import.meta.env.VITE_BUILD_ID||'local'} · {import.meta.env.MODE}</small></p>
    <button onClick={cloud.logout}>Cerrar sesión</button>
  </section>
}
