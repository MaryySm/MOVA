import { useCloud } from '../../controllers/useCloud'
import { useEmotionReport } from '../../controllers/useRequirements'
import { EMOTION_OPTIONS, dateLabel, dayDate, timestampLabel } from '../../models/requirements'
import { ProfileSelector } from '../shared/RequirementsUi'
export function EmotionsScreen() {
  const cloud=useCloud(),c=useEmotionReport()
  return <section className="mova-screen"><h1>Autorreporte de emociones</h1><ProfileSelector/>
    <p>Puedes elegir una o más emociones. El porcentaje indica cuánto sientes cada emoción según tu propia percepción.</p>
    <p><small>Este registro no es un diagnóstico. La nota es opcional.</small></p>
    <div className="mova-emotions">{EMOTION_OPTIONS.map(e=><button key={e.label} disabled={!!c.operation} aria-pressed={c.values.some(v=>v.label===e.label)}
      onClick={()=>c.toggle(e.label)}><span aria-hidden="true">{e.emoji}</span> {e.label}</button>)}</div>
    {c.values.map(e=><fieldset className="mova-card" key={e.label} disabled={!!c.operation}><legend>{e.label}: {e.intensity}%</legend>
      <label htmlFor={`intensity-${e.label}`}>Intensidad de {e.label}</label>
      <input id={`intensity-${e.label}`} type="range" min={0} max={100} value={e.intensity} onChange={ev=>c.intensity(e.label,Number(ev.target.value))}/>
      <div className="mova-row"><button type="button" aria-label={`Disminuir intensidad de ${e.label}`} onClick={()=>c.intensity(e.label,e.intensity-5)}>−5</button>
        <label className="mova-field">Porcentaje<input type="number" min={0} max={100} value={e.intensity} onChange={ev=>c.intensity(e.label,Number(ev.target.value))}/></label>
        <button type="button" aria-label={`Aumentar intensidad de ${e.label}`} onClick={()=>c.intensity(e.label,e.intensity+5)}>+5</button></div></fieldset>)}
    <label className="mova-field">Nota (opcional)<textarea maxLength={2000} value={c.note} disabled={!!c.operation} onChange={e=>c.setNote(e.target.value)}/></label>
    <button disabled={!cloud.ready||!c.values.length||!!c.operation} onClick={c.save}>Guardar registro</button>
    {c.operation&&<><p role="status">{c.pending?'Registro pendiente de envío.':cloud.error?'No se pudo confirmar el registro.':'Registro recibido en la base de datos.'}</p>
      {!c.pending&&<button className="mova-secondary" onClick={c.reset}>Crear otro registro</button>}</>}
    <h2>Resumen semanal</h2>
    <label className="mova-field">Semana que contiene la fecha<input type="date" value={c.week} onChange={e=>c.setWeek(e.target.value)}/></label>
    <p><small>Promedio diario de todas las intensidades registradas, redondeado al entero más cercano. El promedio semanal usa solo los días con datos.</small></p>
    <p>Promedio semanal: {c.summary.length?`${Math.round(c.summary.reduce((n,d)=>n+d.intensity,0)/c.summary.length)}%`:'Sin datos'}</p>
    <div className="mova-summary">{c.days.map(day=>{const value=c.summary.find(d=>d.date===day);return <button key={day} aria-pressed={c.selectedDay===day}
      onClick={()=>c.setSelectedDay(day)} aria-label={`${dateLabel(day)}: ${value?`${value.intensity}%, ${value.count} registros`:'Sin datos'}`}>
      <div className="mova-bar">{value&&<span style={{height:`${value.intensity}%`}}/>}</div>
      <span>{dayDate(day).toLocaleDateString('es-CL',{weekday:'short'})}</span><br/>{value?`${value.intensity}%`:'Sin datos'}</button>})}</div>
    {c.error&&<p role="alert">{c.error}</p>}
    <h2>Detalle: {dateLabel(c.selectedDay)}</h2>
    {!c.details.length&&<p>Sin datos para este día.</p>}
    {c.details.map(r=><article className="mova-card" key={r.id}><small>{timestampLabel(r.recordedAt)}</small>
      {r.emotions.map(e=><p key={e.label}>{e.label}: <strong>{e.intensity}%</strong></p>)}{r.note&&<p>Nota: {r.note}</p>}</article>)}
  </section>
}
