import { useState } from 'react'
import type { Screen } from '../../models/navigation'
import { useCloud } from '../../controllers/useCloud'
import { useDeviceActions } from '../../controllers/useDeviceActions'
import { timestampLabel, freshness } from '../../models/requirements'
import { ProfileSelector } from '../shared/RequirementsUi'
export function DeviceScreen({go}:{go:(screen:Screen)=>void}) {
  const cloud=useCloud(),actions=useDeviceActions(),device=cloud.state.device
  const [mapFailed,setMapFailed]=useState(false)
  const [mapRevision,setMapRevision]=useState(0)
  const hasLocation=device?.lat!=null&&device.lng!=null&&device.location_at!=null
  return <section className="mova-screen"><button className="mova-secondary" onClick={()=>go('home')}>Volver a Inicio</button>
    <h1>Ubicación y dispositivo</h1><ProfileSelector/>
    <p>Usuario: <strong>{cloud.profile?.name}</strong></p>
    {!device?<section className="mova-card"><p>No hay un dispositivo vinculado a este perfil.</p>
      <button disabled={actions.busy||!cloud.online} onClick={actions.linkSimulator}>Vincular simulador MOVA Kids</button>
      <small>El simulador comparte actividades, emociones y SOS. No genera GPS, batería ni pasos físicos.</small></section>:<>
      <section className="mova-card"><h2>{device.nombre}</h2><small>Identificador: {device.id}</small>
        <p>Conexión: {!device.last_seen?'Estado desconocido':freshness(device.last_seen)==='Reciente'?'En línea (último contacto reciente)':'Sin contacto reciente'}</p>
        <small>Último contacto: {timestampLabel(device.last_seen)}</small>
        <p>Batería: {device.bateria==null?'Sin datos':`${device.bateria}%`}</p><small>{timestampLabel(device.bateria_at)} · {freshness(device.bateria_at)}</small>
        <p>Pasos: {device.pasos==null?'Sin datos':device.pasos}</p><small>Período: {device.pasos_fecha||'Sin datos'} · {timestampLabel(device.pasos_at)} · {freshness(device.pasos_at)}</small></section>
      <section className="mova-card"><h2>Última ubicación disponible</h2>
        {hasLocation?<><p>Latitud: {device.lat} · Longitud: {device.lng}</p><small>{timestampLabel(device.location_at)} · {freshness(device.location_at)}</small>
          <p>La posición puede ser aproximada y depende de la señal del dispositivo.</p>
          {!mapFailed&&<iframe className="mova-map" key={`${device.id}-${mapRevision}`} title={`Mapa de la última ubicación de ${cloud.profile?.name}`}
            src={`https://www.google.com/maps?q=${device.lat},${device.lng}&z=16&output=embed`} loading="lazy" referrerPolicy="no-referrer" onError={()=>setMapFailed(true)}/>}
          {mapFailed&&<p role="alert">No se pudo cargar el mapa. Las coordenadas y su fecha siguen disponibles.</p>}
          <button onClick={()=>{setMapFailed(false);setMapRevision(v=>v+1)}}>Volver a centrar / recargar mapa</button>
          <a href={`https://www.google.com/maps?q=${device.lat},${device.lng}`} target="_blank" rel="noreferrer">Abrir mapa para ampliar o desplazar</a>
        </>:<p>No hay una ubicación reportada. {device.tipo==='simulator'?'Este simulador no tiene un sensor GPS.':'Se necesita una lectura válida enviada por el hardware vinculado.'}</p>}</section>
    </>}
    {actions.message&&<p role="status">{actions.message}</p>}
    <button className="mova-secondary" onClick={cloud.refresh}>Actualizar datos</button>
  </section>
}
