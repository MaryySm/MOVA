import type { Screen } from '../../models/navigation'
import { useCloud } from '../../controllers/useCloud'
import { dateLabel } from '../../models/requirements'
import { ActivityEditor, ProfileSelector } from '../shared/RequirementsUi'
export default function ActivityPlanScreen({go}:{go:(screen:Screen)=>void}) {
  const cloud=useCloud()
  return <section className="mova-screen"><h1>Planificar actividad</h1><ProfileSelector/>
    <p>Perfil: {cloud.profile?.name} · {dateLabel(cloud.planningDate)}</p>
    <p>La actividad se verá en Agenda y Planificación. En su fecha aparecerá en Inicio, Rutinas y el wearable vinculado al mismo perfil.</p>
    <ActivityEditor key={`${cloud.activeProfileId}-${cloud.planningDate}`} date={cloud.planningDate} onClose={()=>go('calendar')}/>
    <button className="mova-secondary" onClick={()=>go('weekly')}>Ver planificación semanal</button>
  </section>
}
