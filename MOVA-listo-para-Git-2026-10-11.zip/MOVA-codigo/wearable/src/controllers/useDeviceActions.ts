import { useState } from 'react'
import { useCloud } from './useCloud'
import { wearableRequest } from './wearableApi'

export function useDeviceActions() {
  const cloud=useCloud()
  const [busy,setBusy]=useState(false)
  const [message,setMessage]=useState('')
  const run=async(path:string,body:unknown)=>{
    if(!cloud.session||!cloud.activeProfileId||busy)return false
    setBusy(true);setMessage('Enviando…')
    try{await wearableRequest(`/api/v2/profiles/${cloud.activeProfileId}/${path}`,cloud.session.token,body)
      setMessage('Cambio guardado');cloud.refresh();return true
    }catch(e){setMessage(e instanceof Error?e.message:'No se pudo guardar');return false}
    finally{setBusy(false)}
  }
  return {busy,message,linkSimulator:()=>run('device',{id:`simulator-${cloud.activeProfileId}`,name:'MOVA Kids · Simulador',type:'simulator'}),
    acknowledge:(eventId:string)=>run('alerts/acknowledge',{eventId})}
}
