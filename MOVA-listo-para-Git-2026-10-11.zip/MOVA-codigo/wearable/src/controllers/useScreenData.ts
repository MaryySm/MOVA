import { useEffect, useRef, useState } from "react"
import { useCloud } from "./useCloud"
import { wearableRequest } from "./wearableApi"

// Lecturas y escrituras autenticadas; las pantallas muestran errores reales.
export function useScreenData<T>(path: string, initial: T) {
  const { session } = useCloud()
  const [data, setData] = useState<T>(initial)
  const [ready, setReady] = useState(false)
  const [error, setError] = useState("")
  const [revision, setRevision] = useState(0)
  const generation = useRef(0)
  const queue = useRef<Promise<unknown>>(Promise.resolve())
  const previousPath = useRef('')
  useEffect(() => {
    const current = ++generation.current
    const identity = `${session?.user.id}:${path}`
    if (previousPath.current !== identity) { setReady(false); setData(initial) }
    previousPath.current = identity
    setError("")
    if (!session) return
    void wearableRequest<T>(path, session.token).then(value => {
      if (generation.current === current) { setData(value); setReady(true) }
    }).catch(cause => { if (generation.current === current) setError(String(cause.message)) })
    return () => { generation.current++ }
  }, [path, session?.token, revision])
  const save = async (body: unknown, endpoint = path) => {
    if (!session || !ready) return false
    const current = generation.current
    const operation = queue.current.catch(() => {}).then(async () => {
      if (generation.current !== current) return false
      try {
        await wearableRequest(endpoint, session.token, body)
        const value = await wearableRequest<T>(path, session.token)
        if (generation.current === current) { setData(value); setError("") }
        return true
      } catch (cause) {
        if (generation.current === current) setError(cause instanceof Error ? cause.message : "No se pudo guardar")
        return false
      }
    })
    queue.current = operation
    return operation
  }
  return { data, ready, error, save, reload: () => setRevision(v=>v+1) }
}

export type CalendarEvent = { id: string; title: string; date: string; time: string }
export const localDate = (date: Date) => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`
