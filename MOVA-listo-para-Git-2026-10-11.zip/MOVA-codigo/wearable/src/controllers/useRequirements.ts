import { useEffect, useRef, useState } from 'react'
import { useCloud } from './useCloud'
import { useScreenData } from './useScreenData'
import { wearableRequest } from './wearableApi'
import { dayDate, localDay, DEFAULT_NOTIFICATIONS } from '../models/requirements'
import type { ChildProfile, DailyEmotion, EmotionalReport, EmotionValue, PlannedActivity } from '../models/requirements'

export function useActivityEditor(initialDate: string, activity?: PlannedActivity) {
  const cloud=useCloud()
  const [label,setLabel]=useState(activity?.label||'')
  const [date,setDate]=useState(activity?.date||initialDate)
  const [time,setTime]=useState(activity?.time||cloud.planningTime)
  const [duration,setDuration]=useState(activity?.duration||30)
  const [savedId,setSavedId]=useState<string|null>(null)
  const submit=()=>{
    if(savedId||!label.trim()||!cloud.ready) return
    setSavedId(activity?cloud.editTask(activity.id,label.trim(),time,date,duration):cloud.addTask(label.trim(),time,date,duration))
  }
  const pending=savedId?cloud.pending.some(p=>p.eventId===savedId):false
  return {label,setLabel,date,setDate,time,setTime,duration,setDuration,submit,savedId,pending,
    saved:!!savedId&&!pending&&!cloud.error,ready:cloud.ready}
}

export function useAgenda() {
  const cloud=useCloud()
  const selected=cloud.planningDate
  const [month,setMonth]=useState(()=>new Date(dayDate(selected).getFullYear(),dayDate(selected).getMonth(),1))
  const from=localDay(new Date(month.getFullYear(),month.getMonth(),1,12))
  const to=localDay(new Date(month.getFullYear(),month.getMonth()+1,0,12))
  const remote=useScreenData<PlannedActivity[]>(`/api/v2/profiles/${cloud.activeProfileId}/activities?from=${from}&to=${to}`,[])
  useEffect(()=>{ if(cloud.pending.length===0) remote.reload() },[cloud.pending.length,cloud.activeProfileId])
  const cells:(number|null)[]=Array((month.getDay()+6)%7).fill(null)
  const last=new Date(month.getFullYear(),month.getMonth()+1,0).getDate()
  for(let day=1;day<=last;day++)cells.push(day)
  while(cells.length%7)cells.push(null)
  const weeks=Array.from({length:cells.length/7},(_,i)=>cells.slice(i*7,i*7+7))
  const selectDay=(day:number)=>cloud.setPlanningDate(localDay(new Date(month.getFullYear(),month.getMonth(),day,12)))
  const changeMonth=(offset:number)=>{
    const next=new Date(month.getFullYear(),month.getMonth()+offset,1,12)
    setMonth(next);cloud.setPlanningDate(localDay(next))
  }
  const dateFor=(day:number)=>localDay(new Date(month.getFullYear(),month.getMonth(),day,12))
  return {month,selected,weeks,selectDay,changeMonth,dateFor,events:remote.data,
    scheduled:remote.data.filter(a=>a.date===selected),error:remote.error,ready:remote.ready,reload:remote.reload}
}

export function useWeeklyPlan() {
  const cloud=useCloud()
  const selected=dayDate(cloud.planningDate)
  const monday=new Date(selected);monday.setDate(selected.getDate()-(selected.getDay()+6)%7)
  const sunday=new Date(monday);sunday.setDate(monday.getDate()+6)
  const remote=useScreenData<PlannedActivity[]>(`/api/v2/profiles/${cloud.activeProfileId}/activities?from=${localDay(monday)}&to=${localDay(sunday)}`,[])
  useEffect(()=>{if(!cloud.pending.length)remote.reload()},[cloud.pending.length])
  const days=Array.from({length:7},(_,i)=>{const day=new Date(monday);day.setDate(monday.getDate()+i);return localDay(day)})
  return {days,events:remote.data,error:remote.error,ready:remote.ready,reload:remote.reload}
}

export function useEmotionReport() {
  const cloud=useCloud()
  const [values,setValues]=useState<EmotionValue[]>([])
  const [note,setNote]=useState('')
  const [selectedDay,setSelectedDay]=useState(localDay())
  const [week,setWeek]=useState(localDay())
  const [operation,setOperation]=useState<string|null>(null)
  const monday=dayDate(week);monday.setDate(monday.getDate()-(monday.getDay()+6)%7)
  const sunday=new Date(monday);sunday.setDate(monday.getDate()+6)
  const query=`from=${localDay(monday)}&to=${localDay(sunday)}`
  const history=useScreenData<EmotionalReport[]>(`/api/v2/profiles/${cloud.activeProfileId}/emotions?${query}`,[])
  const summary=useScreenData<DailyEmotion[]>(`/api/v2/profiles/${cloud.activeProfileId}/emotions/summary?${query}`,[])
  useEffect(()=>{setValues([]);setNote('');setOperation(null)},[cloud.activeProfileId])
  useEffect(()=>{if(!cloud.pending.length){history.reload();summary.reload()}},[cloud.pending.length])
  const toggle=(label:string)=>setValues(v=>v.some(e=>e.label===label)?v.filter(e=>e.label!==label):[...v,{label,intensity:50}])
  const intensity=(label:string,value:number)=>setValues(v=>v.map(e=>e.label===label?{...e,intensity:Math.min(100,Math.max(0,value))}:e))
  const save=()=>{if(operation||!values.length)return;setOperation(cloud.saveEmotions(values,note))}
  const pending=!!operation&&cloud.pending.some(p=>p.eventId===operation)
  const reset=()=>{setOperation(null);setValues([]);setNote('')}
  const days=Array.from({length:7},(_,i)=>{const day=new Date(monday);day.setDate(monday.getDate()+i);return localDay(day)})
  return {values,toggle,intensity,note,setNote,save,reset,operation,pending,week,setWeek,days,
    selectedDay,setSelectedDay,summary:summary.data,history:history.data,
    details:history.data.filter(r=>localDay(new Date(r.recordedAt))===selectedDay),error:history.error||summary.error}
}

export function useProfileEditor() {
  const cloud=useCloud()
  const [draft,setDraft]=useState<ChildProfile|null>(null)
  const [busy,setBusy]=useState(false)
  const [message,setMessage]=useState('')
  const generation=useRef(0)
  useEffect(()=>{generation.current++;setDraft(null);setMessage('')},[cloud.activeProfileId])
  const open=(profile?:ChildProfile)=>{setMessage('');setDraft(profile?{...profile,notifications:{...profile.notifications}}:
    {id:crypto.randomUUID(),name:'',age:'',photo:'',notifications:{...DEFAULT_NOTIFICATIONS}})}
  const save=async()=>{
    if(!draft||busy||!cloud.session)return
    const current=generation.current;setBusy(true);setMessage('Guardando…')
    try {await wearableRequest('/api/v2/profiles',cloud.session.token,draft)
      if(current===generation.current){setDraft(null);setMessage('Perfil guardado');cloud.refresh()}
    } catch(e){if(current===generation.current)setMessage(e instanceof Error?e.message:'No se pudo guardar')}
    finally{setBusy(false)}
  }
  const photo=(file?:File)=>{
    if(!file||!draft)return
    if(!['image/jpeg','image/png','image/webp'].includes(file.type)||file.size>100000){setMessage('Selecciona una imagen JPG, PNG o WebP de hasta 100 KB');return}
    const reader=new FileReader();reader.onload=()=>setDraft(p=>p?{...p,photo:String(reader.result)}:p);reader.readAsDataURL(file)
  }
  return {draft,setDraft,busy,message,open,save,photo,cancel:()=>setDraft(null)}
}
