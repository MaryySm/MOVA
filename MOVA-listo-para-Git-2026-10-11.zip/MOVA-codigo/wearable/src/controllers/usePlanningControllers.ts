import { useScreenData, localDate } from "./useScreenData"
import type { CalendarEvent } from "./useScreenData"
import { useState } from "react"
import { WEEK_DAYS, TODAY_PLAN, INITIAL_ROUTINE } from "../models/planning"
import type {
  WeekActivity,
  WeekPlan,
  RoutineSlots,
  SlotTask,
} from "../models/planning"
import { getHomeSummary } from "./profileController"
import { useCloud } from "./useCloud"
import { MOODS } from "../models/planning"
const slotFor = (time: string): keyof RoutineSlots => Number(time.slice(0, 2)) < 12 ? "mañana" : Number(time.slice(0, 2)) < 19 ? "tarde" : "noche"
// Aquí administro actividades, rutinas y cambios de planificación.
export function useWeeklyPlanController() {
  const [activeDay, setActiveDay] = useState("lun")

  const now = new Date()
  const monday = new Date(now.getFullYear(), now.getMonth(), now.getDate() - (now.getDay()+6)%7)
  const sunday = new Date(monday); sunday.setDate(monday.getDate()+6)
  const remote = useScreenData<CalendarEvent[]>(`/api/screens/calendar?from=${localDate(monday)}&to=${localDate(sunday)}`, [])
  const plan: WeekPlan = {}
  remote.data.forEach(event => {
    const day = WEEK_DAYS[(new Date(event.date+"T12:00:00").getDay()+6)%7]
    ;(plan[day.key] ||= []).push({ id: event.id, label: event.title, time: event.time, color: day.color })
  })

  const [showPicker, setShowPicker] = useState(false)

  const [customText, setCustomText] = useState("")

  const [customTime, setCustomTime] = useState("08:00")

  const dayInfo = WEEK_DAYS.find((d) => d.key === activeDay)!

  const dayActivities = plan[activeDay] || []

  const addActivity = (label: string, color: string) => {
    const day = new Date(monday); day.setDate(monday.getDate()+WEEK_DAYS.findIndex(d => d.key===activeDay))
    void remote.save({ id: crypto.randomUUID(), title: label, date: localDate(day), time: customTime }, "/api/screens/calendar")
    setShowPicker(false)
    setCustomText("")
  }

  const removeActivity = (id: string) => {
    void remote.save({ id }, "/api/screens/calendar/remove")
  }

  const addCustom = () => {
    if (!customText.trim()) return
    addActivity(customText.trim(), dayInfo.color)
  }

  return {
    error: remote.error, ready: remote.ready,
    activeDay,
    setActiveDay,
    plan,
    showPicker,
    setShowPicker,
    customText,
    setCustomText,
    customTime,
    setCustomTime,
    dayInfo,
    dayActivities,
    addActivity,
    removeActivity,
    addCustom,
  }
}
export function useHomeController() {
  const cloud = useCloud()
  const tasks = cloud.state.activities.map((a) => ({ ...a, color: "#A78BFA", slot: slotFor(a.time) }))
  const mood = cloud.state.emotion
  const setMood = cloud.setEmotion

  const [notifOpen, setNotifOpen] = useState(false)

  const syncedSummary = { ...getHomeSummary(), name: cloud.session?.user.name || "", adultName: cloud.session?.user.adultName || "" }

  const toggleTask = (id: string) =>
    cloud.setDone(id, !tasks.find((task) => task.id === id)?.done)

  const done = tasks.filter((t) => t.done).length

  const total = tasks.length

  const pct = total ? Math.round((done / total) * 100) : 0

  const notifs = [
    { text: "⚽ Taller de fútbol en 45 min", color: "#5ECFA8", time: "15:15" },
    { text: "💧 Recuerda hidratarte", color: "#6B9FFF", time: "12:00" },
    { text: "🌙 Hora de dormir a las 21:30", color: "#9B72F5", time: "21:00" },
  ]

  const slotLabels: Record<string, string> = {
    mañana: "🌅 Mañana",
    tarde: "☀️ Tarde",
    noche: "🌙 Noche",
  }

  const grouped = ["mañana", "tarde", "noche"]
    .map((s) => ({
      slot: s,
      label: slotLabels[s],
      items: tasks.filter((t) => t.slot === s),
    }))
    .filter((g) => g.items.length > 0)

  return {
    tasks,
    mood,
    setMood,
    notifOpen,
    setNotifOpen,
    syncedSummary,
    toggleTask,
    done,
    total,
    pct,
    notifs,
    slotLabels,
    grouped,
  }
}
export function useRoutineController() {
  const cloud = useCloud()
  const routine: RoutineSlots = { mañana: [], tarde: [], noche: [] }
  cloud.state.activities.forEach((task) => routine[slotFor(task.time)].push({ ...task, color: "#A78BFA" }))

  const [openSlot, setOpenSlot] = useState<string | null>("mañana")

  const [addingTo, setAddingTo] = useState<string | null>(null)

  const [customTask, setCustomTask] = useState("")

  const [toast, setToast] = useState("")

  const toggleDone = (slot: string, id: string) => {
    cloud.setDone(id, !cloud.state.activities.find((task) => task.id === id)?.done)
  }

  const removeTask = (slot: string, id: string) => {
    cloud.removeTask(id)
  }

  const addTask = (slot: string, label: string, color: string) => {
    cloud.addTask(label, slot === "mañana" ? "08:00" : slot === "tarde" ? "15:00" : "21:00")
    setCustomTask("")
    setAddingTo(null)
  }

  const addToWeekPlan = (task: SlotTask) => {
    setToast(`"${task.label}" ya está disponible en el wearable ✓`)
    setTimeout(() => setToast(""), 2200)
  }

  const totalTasks = Object.values(routine).flat().length

  const doneTasks = Object.values(routine)
    .flat()
    .filter((t) => t.done).length

  return {
    routine,
    openSlot,
    setOpenSlot,
    addingTo,
    setAddingTo,
    customTask,
    setCustomTask,
    toast,
    toggleDone,
    removeTask,
    addTask,
    addToWeekPlan,
    totalTasks,
    doneTasks,
  }
}
export function useCalendarController() {
  const [month, setMonth] = useState(() => new Date(new Date().getFullYear(),new Date().getMonth(),1))
  const [selectedDay, setSelectedDay] = useState(new Date().getDate())
  const last = new Date(month.getFullYear(),month.getMonth()+1,0)
  const remote = useScreenData<CalendarEvent[]>(`/api/screens/calendar?from=${localDate(month)}&to=${localDate(last)}`, [])
  const cells: (number|null)[] = Array((month.getDay()+6)%7).fill(null)
  for(let day=1;day<=last.getDate();day++) cells.push(day)
  while(cells.length%7) cells.push(null)
  const weeks = Array.from({length:cells.length/7},(_,i)=>cells.slice(i*7,i*7+7))
  const selectedDate = new Date(month.getFullYear(),month.getMonth(),selectedDay)
  const scheduled = remote.data.filter(e=>e.date===localDate(selectedDate)).map(e=>({time:e.time,name:e.title,duration:"",color:"#A882F5"}))
  const events = remote.data.map(e=>({day:Number(e.date.slice(-2)),color:"#A882F5"}))
  const changeMonth = (offset:number) => { setMonth(new Date(month.getFullYear(),month.getMonth()+offset,1)); setSelectedDay(1) }
  return { selectedDay, setSelectedDay, weeks, scheduled, events, changeMonth, error:remote.error,
    monthLabel:month.toLocaleDateString("es-CL",{month:"long",year:"numeric"}),
    dayLabel:selectedDate.toLocaleDateString("es-CL",{weekday:"long",day:"numeric",month:"long"}),
    today:month.getMonth()===new Date().getMonth()&&month.getFullYear()===new Date().getFullYear()?new Date().getDate():0 }
}

export function useEmotionsController() {
  const cloud = useCloud()
  const mood = MOODS.find((m) => m.label === cloud.state.emotion)?.id ?? null
  const setMood = (id: string | null) => cloud.setEmotion(id ? MOODS.find((m) => m.id === id)?.label || id : null)

  const [tags, setTags] = useState<string[]>([])

  const [note, setNote] = useState("")

  const toggleTag = (tag: string) =>
    setTags((p) => (p.includes(tag) ? p.filter((x) => x !== tag) : [...p, tag]))

  const remote = useScreenData<{ emotion:string; recordedAt:string; note:string|null; tags:string[]|null }[]>("/api/screens/emotions", [])
  const [saved, setSaved] = useState(false)
  const saveRecord = async () => {
    if (!cloud.state.emotion) return
    setSaved(false)
    if(await remote.save({eventId:crypto.randomUUID(),emotion:cloud.state.emotion,note,tags})) {
      setSaved(true); setTags([]); setNote("")
    }
  }
  const weekData = Array.from({length:7},(_,i)=>{
    const day=new Date(); day.setDate(day.getDate()-(day.getDay()+6)%7+i)
    return Math.min(92,remote.data.filter(e=>localDate(new Date(e.recordedAt))===localDate(day)).length*15)
  })

  const barColors = [
    "#F590B8",
    "#F5A84B",
    "#A882F5",
    "#5ECFA8",
    "#5BB8F5",
    "#F5795A",
    "#5ECFA8",
  ]

  return {
    saveRecord, saved, error:remote.error, ready:remote.ready,
    mood,
    setMood,
    tags,
    setTags,
    note,
    setNote,
    toggleTag,
    weekData,
    barColors,
  }
}
