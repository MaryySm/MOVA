import { createContext, useContext, useEffect, useRef, useState } from 'react'
import type { WearableSession } from '../models/cloud'
import type { ActivityChange, ChildProfile, EmotionValue, PanelData, PendingOperation } from '../models/requirements'
import { localDay } from '../models/requirements'
import { loginWearable, wearableRequest, WearableApiError } from './wearableApi'

const SESSION_KEY = 'mova-shared-session'
const surface = import.meta.env.MODE === 'wearable' ? 'wearable' : 'app'
const empty = (): PanelData => ({ activities: [], emotion: null, progressPercent: 0, emotionalReport: null,
  device: null, alerts: [], date: localDay() })
function readSession(): WearableSession | undefined {
  try { const s = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); return s?.token && s?.user?.id ? s : undefined }
  catch { return undefined }
}
function outbox(account: string): PendingOperation[] {
  return Object.keys(localStorage).filter(k=>k.startsWith(`mova-v2-operation-${account}-`)).flatMap(k=>{
    try { return [JSON.parse(localStorage.getItem(k)!) as PendingOperation] } catch { return [] }
  }).sort((a,b)=>a.createdAt.localeCompare(b.createdAt)||a.eventId.localeCompare(b.eventId))
}
export function useCloudController() {
  const [session,setSession] = useState<WearableSession|undefined>(readSession)
  const [profiles,setProfiles] = useState<ChildProfile[]>([])
  const [activeProfileId,setActiveProfileId] = useState('')
  const [confirmed,setConfirmed] = useState<PanelData>(empty)
  const [pending,setPending] = useState<PendingOperation[]>([])
  const [ready,setReady] = useState(false)
  const [status,setStatus] = useState('Inicia sesión')
  const [error,setError] = useState('')
  const [online,setOnline] = useState(false)
  const [planningDate,setPlanningDate] = useState(localDay())
    const [planningTime,setPlanningTime] = useState('08:00')
  const syncRef = useRef<()=>void>(()=>{})
  const generation = useRef(0)
  const saveSession = (value?:WearableSession) => {
    generation.current++
    if(value) localStorage.setItem(SESSION_KEY,JSON.stringify(value)); else localStorage.removeItem(SESSION_KEY)
    setConfirmed(empty()); setPending([]); setProfiles([]); setActiveProfileId(''); setReady(false); setOnline(false); setSession(value)
  }
  const selectProfile = (id:string) => {
    if(!session||!profiles.some(p=>p.id===id)) return
    localStorage.setItem(`mova-v2-profile-${surface}-${session.user.id}`,id)
    generation.current++; setConfirmed(empty()); setPending([]); setReady(false); setActiveProfileId(id)
  }
  useEffect(()=>{
    const listen=(e:StorageEvent)=>{ if(e.key===SESSION_KEY) saveSession(readSession()); else syncRef.current() }
    window.addEventListener('storage',listen)
    return ()=>window.removeEventListener('storage',listen)
  },[])
  useEffect(()=>{
    if(!session) return
    let stopped=false,working=false
    const identity=generation.current
    const account=session.user.id
    const alive=()=>!stopped&&generation.current===identity
    const cachedProfiles=localStorage.getItem(`mova-v2-profiles-${account}`)
    if(cachedProfiles) { try {
      const cachedList=JSON.parse(cachedProfiles) as ChildProfile[]; setProfiles(cachedList)
      if(!activeProfileId) { const saved=localStorage.getItem(`mova-v2-profile-${surface}-${account}`);
        setActiveProfileId(cachedList.find(p=>p.id===saved)?.id||cachedList[0]?.id||'') }
    } catch {} }
    if(activeProfileId) {
      try {
        const cached=JSON.parse(localStorage.getItem(`mova-v2-panel-${account}-${activeProfileId}-${localDay()}`)||'null')
        if(cached) {setConfirmed(cached);setReady(true);setStatus('Último estado guardado. Verificando conexión…')}
      } catch {}
    }
    const sync=async()=>{
      if(working||!alive()) return
      working=true
      try {
        const list=await wearableRequest<ChildProfile[]>('/api/v2/profiles',session.token)
        if(!alive()) return
        setProfiles(list); localStorage.setItem(`mova-v2-profiles-${account}`,JSON.stringify(list))
        if(!activeProfileId||!list.some(p=>p.id===activeProfileId)) {
          const saved=localStorage.getItem(`mova-v2-profile-${surface}-${account}`)
          setActiveProfileId(list.find(p=>p.id===saved)?.id||list[0]?.id||'');return
        }
        for(const operation of outbox(account)) {
          if(!alive()) return
          try {
            await wearableRequest(`/api/v2/profiles/${operation.profileId}/${operation.kind}`,session.token,operation.body)
            localStorage.removeItem(`mova-v2-operation-${account}-${operation.eventId}`)
          } catch(cause) {
            if(cause instanceof WearableApiError&&[400,404,409].includes(cause.status)) {
              localStorage.removeItem(`mova-v2-operation-${account}-${operation.eventId}`)
              setError(cause.message)
            } else throw cause
          }
        }
        const panel=await wearableRequest<PanelData>(`/api/v2/profiles/${activeProfileId}/panel?date=${localDay()}`,session.token)
        if(!alive()) return
        setConfirmed(panel); setReady(true);setOnline(true)
        localStorage.setItem(`mova-v2-panel-${account}-${activeProfileId}-${localDay()}`,JSON.stringify(panel))
        const queued=outbox(account).filter(p=>p.profileId===activeProfileId);setPending(queued)
        setStatus(queued.length?`${queued.length} cambios pendientes de envío`:'Datos guardados en la base de datos')
      } catch(cause) {
        if(!alive()) return
        setOnline(false); setPending(outbox(account).filter(p=>p.profileId===activeProfileId))
        if(cause instanceof WearableApiError&&cause.status===401) { saveSession();setError('La sesión venció. Inicia sesión nuevamente.') }
        else setStatus('Sin conexión. Se conserva el último estado; los cambios quedan pendientes.')
      } finally { working=false }
    }
    syncRef.current=()=>void sync();void sync()
    const timer=setInterval(()=>void sync(),2000)
    const onlineListener=()=>void sync()
    window.addEventListener('online',onlineListener)
    return ()=>{stopped=true;clearInterval(timer);window.removeEventListener('online',onlineListener);syncRef.current=()=>{}}
  },[session?.token,activeProfileId])
  const enqueue=(kind:PendingOperation['kind'],body:Record<string,unknown>,change?:ActivityChange)=>{
    if(!session||!activeProfileId||!ready) return null
    const eventId=crypto.randomUUID()
    const op:PendingOperation={eventId,profileId:activeProfileId,kind,createdAt:new Date().toISOString(),body:{...body,eventId},change}
    try {
      localStorage.setItem(`mova-v2-operation-${session.user.id}-${eventId}`,JSON.stringify(op))
      setPending(outbox(session.user.id).filter(p=>p.profileId===activeProfileId));setError('');setStatus('Cambio pendiente de envío');syncRef.current()
      return eventId
    } catch {setError('No se pudo guardar localmente. Habilita el almacenamiento del navegador.');return null}
  }
  const currentDay=confirmed.date===localDay()
  let activities=currentDay?confirmed.activities.map(a=>({...a})):[]
  for(const op of pending) {
    const c=op.change;if(!c) continue
    if(c.type==='add_task'&&c.date===localDay()) activities.push({id:c.taskId,label:c.label!,time:c.time!,date:c.date!,duration:c.duration!,done:false,pending:true})
    if(c.type==='set_done') activities=activities.map(a=>a.id===c.taskId?{...a,done:c.done!,pending:true}:a)
    if(c.type==='edit_task') activities=activities.map(a=>a.id===c.taskId?{...a,label:c.label!,time:c.time!,duration:c.duration!,pending:true}:a)
    if(c.type==='remove_task') activities=activities.map(a=>a.id===c.taskId?{...a,pending:true}:a)
  }
  activities.sort((a,b)=>a.time.localeCompare(b.time))
  const state={...confirmed,activities,progressPercent:currentDay?confirmed.progressPercent:0}
  const changeActivity=(change:ActivityChange)=>enqueue('activities',{change},change)
  const saveEmotions=(emotions:EmotionValue[],note='',tags:string[]=[])=>enqueue('emotions',{emotions,note,tags,recordedAt:new Date().toISOString()})
  const profile=profiles.find(p=>p.id===activeProfileId)
  return {session,state,profiles,profile,activeProfileId,selectProfile,ready,online,status,error,pending,planningDate,setPlanningDate,planningTime,setPlanningTime,
    confirmedActivities: currentDay?confirmed.activities:[],
    refresh:()=>syncRef.current(),
    login:async(email:string,password:string)=>saveSession(await loginWearable(email,password)),
    register:async(body:unknown)=>saveSession(await wearableRequest<WearableSession>('/api/auth/register',undefined,body)),
    logout:async()=>{
      const previous=session;saveSession()
      if(previous){try{await wearableRequest('/api/auth/logout',previous.token,{})}
        catch{setError('Sesión cerrada en este equipo. No se pudo confirmar su revocación en el servidor.')}}
    },
    addTask:(label:string,time:string,date=localDay(),duration=30)=>changeActivity({type:'add_task',taskId:crypto.randomUUID(),label,time,date,duration}),
    editTask:(taskId:string,label:string,time:string,date:string,duration:number)=>changeActivity({type:'edit_task',taskId,label,time,date,duration}),
    removeTask:(taskId:string)=>changeActivity({type:'remove_task',taskId}),
    setDone:(taskId:string,done:boolean)=>changeActivity({type:'set_done',taskId,done}),
    setEmotion:(label:string|null)=>label?saveEmotions([{label,intensity:50}]):null,
    saveEmotions,
    sendSOS:()=>state.device?enqueue('sos',{deviceId:state.device.id,recordedAt:new Date().toISOString()}):null,
  }
}
export const CloudContext=createContext<ReturnType<typeof useCloudController>|null>(null)
export function useCloud(){const value=useContext(CloudContext);if(!value)throw new Error('Falta el proveedor MOVA');return value}
