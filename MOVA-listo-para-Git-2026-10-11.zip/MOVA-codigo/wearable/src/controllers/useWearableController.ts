import { useEffect, useRef, useState } from 'react'
import { useCloud } from './useCloud'
import { wearableRequest } from './wearableApi'

// El simulador nunca confirma una entrega SOS ni un registro por una acción local.
export function useWearableController() {
  const cloud=useCloud()
  const [page,setPage]=useState<'home'|'activities'|'emotions'|'intensity'|'sos'>('home')
  const [draftEmotion,setDraftEmotion]=useState('')
  const [intensity,setIntensity]=useState(50)
  const [emotionId,setEmotionId]=useState<string|null>(null)
  const [sosId,setSosId]=useState<string|null>(null)
  const [holdPct,setHoldPct]=useState(0)
  const hold=useRef<ReturnType<typeof setInterval>|null>(null)
  const [,tick]=useState(0)
  const cancelHold=()=>{if(hold.current)clearInterval(hold.current);hold.current=null;setHoldPct(0)}
  useEffect(()=>{const timer=setInterval(()=>tick(v=>v+1),1000);return()=>clearInterval(timer)},[])
  useEffect(()=>{setPage('home');setDraftEmotion('');setEmotionId(null);setSosId(null);cancelHold()},[cloud.activeProfileId])
  useEffect(()=>()=>{if(hold.current)clearInterval(hold.current)},[])
  useEffect(()=>{
    const device=cloud.state.device,session=cloud.session,profileId=cloud.activeProfileId
    if(!device||device.tipo!=='simulator'||!session)return
    const heartbeat=()=>void wearableRequest(`/api/v2/profiles/${profileId}/device/heartbeat`,session.token,{deviceId:device.id}).catch(()=>{})
    heartbeat();const timer=setInterval(heartbeat,30000);return()=>clearInterval(timer)
  },[cloud.state.device?.id,cloud.session?.token,cloud.activeProfileId])
  const startHold=()=>{
    if(hold.current||!cloud.ready||!cloud.state.device)return
    const started=Date.now();setHoldPct(1)
    hold.current=setInterval(()=>{
      const pct=Math.min(100,(Date.now()-started)/2500*100);setHoldPct(pct)
      if(pct>=100){cancelHold();setSosId(cloud.sendSOS());setPage('sos')}
    },50)
  }
  const chooseMood=(label:string)=>{setDraftEmotion(label);setIntensity(50);setEmotionId(null);setPage('intensity')}
  const saveMood=()=>{if(!draftEmotion||emotionId)return;setEmotionId(cloud.saveEmotions([{label:draftEmotion,intensity}]))}
  const alert=cloud.state.alerts.find(a=>a.id===sosId)
  const sosPending=cloud.pending.some(p=>p.eventId===sosId)
  const sosStatus=alert?.acknowledged_at?'El adulto confirmó que vio tu solicitud':alert?'Solicitud recibida en el servidor':sosPending?'Pendiente de envío. Intentando conectar…':'No se pudo confirmar el envío'
  const emotionPending=cloud.pending.some(p=>p.eventId===emotionId)
  return {cloud,page,setPage,draftEmotion,intensity,setIntensity,emotionId,emotionPending,chooseMood,saveMood,
    holdPct,startHold,cancelHold,sosStatus,sosPending,
    hh:new Date().toLocaleTimeString('es-CL',{timeZone:'America/Santiago',hour:'2-digit',minute:'2-digit'}),
    dd:new Date().toLocaleDateString('es-CL',{timeZone:'America/Santiago',day:'numeric',month:'short'}),
    back:()=>{cancelHold();setPage('home');setDraftEmotion('');setEmotionId(null)}}
}
