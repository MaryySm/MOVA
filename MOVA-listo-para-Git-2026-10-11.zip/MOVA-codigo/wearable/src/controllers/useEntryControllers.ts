import { useEffect, useState } from "react"
import type { FormEvent } from "react"
import type { Screen } from "../models/navigation"
import type { SignupData } from "../models/profile"
import { useCloud } from "./useCloud"
import { WearableApiError } from "./wearableApi"
import { wearableRequest } from './wearableApi'

type SignupField = keyof SignupData

// Aquí controlo la transición automática desde la presentación al inicio de sesión.
export function useSplashController(go: (screen: Screen) => void) {
  const [opacity, setOpacity] = useState(0)

  useEffect(() => {
    const t1 = setTimeout(() => setOpacity(1), 100)
    const t2 = setTimeout(() => go("login"), 2600)
    return () => {
      clearTimeout(t1)
      clearTimeout(t2)
    }
  }, [go])

  return { opacity }
}
export function useLoginController() {
  const cloud = useCloud()
  // Mantengo los campos de acceso mientras la persona escribe.
  const [email, setEmail] = useState("")

  const [pass, setPass] = useState("")
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState("")
  const [recovery,setRecovery]=useState(!!new URLSearchParams(location.search).get('resetToken'))
  const [recoveryMessage,setRecoveryMessage]=useState('')
  const resetToken=new URLSearchParams(location.search).get('resetToken')
  const submit = async () => {
    if(busy)return
    if(!email.trim()){setError('Completa el campo Correo.');return}
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())){setError('El correo no tiene un formato válido.');return}
    if(!pass){setError('Completa el campo Contraseña.');return}
    setBusy(true); setError("")
    try { await cloud.login(email.trim(), pass); setPass("") }
    catch (cause) { setError(cause instanceof WearableApiError ? cause.message : "No se pudo conectar con MOVA.") }
    finally { setBusy(false) }
  }
  const recover=async()=>{
    if(busy)return
    setBusy(true);setError('');setRecoveryMessage('')
    try{
      const result=await wearableRequest<{message:string}>(resetToken?'/api/auth/recovery/reset':'/api/auth/recovery/request',undefined,
        resetToken?{token:resetToken,password:pass}:{email})
      setRecoveryMessage(result.message)
      if(resetToken){setPass('');history.replaceState(null,'',location.pathname);setRecovery(false)}
    }catch(e){setError(e instanceof Error?e.message:'No se pudo procesar la recuperación')}
    finally{setBusy(false)}
  }
  return { email, setEmail, pass, setPass, submit, busy, error,recovery,setRecovery,recoveryMessage,recover,resetToken }
}
export function useSignupController(go: (screen: Screen) => void) {
  // Aquí reúno, valido y envío el formulario al almacenamiento del prototipo.
  const [form, setForm] = useState<SignupData>({
    adultName: "",
    userName: "",
    age: "",
    phone: "",
    email: "",
    diagnosis: "",
    password: "",
  })
  const cloud = useCloud()
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState("")

  const [submitted, setSubmitted] = useState(false)

  const requiredFields: SignupField[] = [
    "adultName",
    "userName",
    "age",
    "phone",
    "email",
  ]

  const isValid =
    requiredFields.every((field) => form[field].trim()) &&
    /^\d{8}$/.test(form.phone) && form.password.length >= 8 && form.password.length <= 128 &&
    /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim()) && Number.isInteger(Number(form.age)) && Number(form.age)>=1 && Number(form.age)<=120
  const fieldErrors: Partial<Record<SignupField,string>> = {
    adultName: form.adultName.trim() ? undefined : 'Escribe el nombre del adulto.',
    userName: form.userName.trim() ? undefined : 'Escribe el nombre del usuario.',
    age: Number.isInteger(Number(form.age)) && Number(form.age)>=1 && Number(form.age)<=120 ? undefined : 'Ingresa una edad entre 1 y 120 años.',
    phone: /^\d{8}$/.test(form.phone) ? undefined : 'Ingresa los 8 dígitos después de +56 9.',
    email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim()) ? undefined : 'Ingresa un correo con formato válido.',
    password: form.password.length>=8 && form.password.length<=128 ? undefined : 'Usa una contraseña de 8 a 128 caracteres.',
  }

  const update = (field: keyof SignupData, value: string) =>
    setForm((current) => ({ ...current, [field]: value }))

  const submit = async (event: FormEvent) => {
    event.preventDefault()
    if(busy)return
    setSubmitted(true)
    if (!isValid) return
    setBusy(true); setError("")
    try {
      await cloud.register({ adultName: form.adultName, name: form.userName, age: form.age,
        phone: `+569${form.phone}`, email: form.email, diagnosis: form.diagnosis, password: form.password })
      go("profile")
    } catch (cause) { setError(cause instanceof WearableApiError ? cause.message : "No se pudo crear la cuenta.") }
    finally { setBusy(false) }
  }

  return {
    form,
    submitted,
    isValid,
    update,
    submit,
    busy,
    error,
    fieldErrors,
  }
}
