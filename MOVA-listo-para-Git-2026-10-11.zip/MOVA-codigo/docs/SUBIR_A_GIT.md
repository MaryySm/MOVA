# Guardar este avance en Git

El código, los SQL y la documentación están guardados. El archivo ZIP de entrega excluye `.env`, dependencias, compilaciones y claves privadas. No contiene los datos de la base Docker; sí contiene los scripts para crear y migrar su estructura.

Desde la carpeta del proyecto (la que contiene `app`, `backend` y `wearable`), con Git instalado:

```powershell
git init
git add .
git status
git commit -m "Integra app y wearable con perfiles y datos por usuario"
```

Revisar `git status` antes del commit. Si ya trabajas en un repositorio, copiar el contenido del ZIP a ese repositorio y omitir `git init`. Conservar su configuración y rama existentes.

Para un repositorio remoto nuevo, reemplazar la URL por la propia:

```powershell
git branch -M main
git remote add origin URL_DEL_REPOSITORIO
git push -u origin main
```

Si `origin` ya existe, consultar `git remote -v` y usar ese remoto. No ejecutar un push forzado.

Para ejecutar en otra máquina, crear `backend/.env` usando `backend/.env.example` y configurar credenciales propias. Revisar `REQUERIMIENTOS.md` para el alcance y los pendientes de aceptación.
