# Seguimiento del Excel RF_RNF_APP_Y_DISP.xlsx

Fuente: archivo original en Capstone; lectura sin modificar el Excel. Esta entrega prioriza la app web y el simulador existentes. Flutter comparte perfiles, actividades y registros emocionales mediante API v2, pero su interfaz todavía requiere adaptación y validación con el SDK.

## Implementación de esta entrega

- Base común PostgreSQL: perfiles reales por niño, actividades únicas con fecha/hora/duración, progreso por día, autorreportes con intensidad, dispositivos y solicitudes SOS.
- App web: registro/login, selección y edición de perfiles, inicio/rutinas/agenda/plan semanal conectados, edición y eliminación confirmada, emociones múltiples de 0 a 100 y promedios diarios sin inventar ceros, ajustes y estados de datos pendientes.
- Simulador: actividades, emoción con intensidad explícita y SOS por pulsación sostenida de 2,5 segundos. Ese tiempo es provisional y requiere validación UX. La recepción en base y la confirmación del adulto son estados distintos.
- Reintentos conservan el identificador de operación; aislamiento por cuenta/perfil y confirmaciones reales desde la base. Batería, pasos y ubicación permanecen sin datos cuando no existen mediciones válidas.
- Logout revoca el token online. Recuperación preparada con token de un uso y vencimiento: falta configurar el proveedor de correo mediante las variables PASSWORD_RESET_*.

## Pendientes de aceptación

No se declara cumplimiento completo del Excel. Faltan pruebas visuales, accesibilidad, usabilidad y rendimiento en dispositivos objetivo; integrar y probar hardware real, BLE, sensores, consumo y entrega de alertas fuera de la app; aprobación de edad, términos y políticas/retención; Google/Apple y servicios externos si se aprueban; publicación y valoración; completar Flutter (pantallas, gráficos, estados sin datos, multiselección y cola offline). No se pudo ejecutar Flutter: el SDK no está disponible en este entorno. No había un navegador conectado para verificación visual.

## Prueba funcional manual

1. Abrir la app en http://localhost:8443 y el simulador en http://localhost:8444. Iniciar sesión con la misma cuenta y elegir el mismo niño; vincular el simulador desde Dispositivo.
2. Crear una actividad para hoy con hora y duración. Verificarla en Agenda, Inicio, Rutinas y wearable. Completarla desde wearable; esperar la confirmación de base y comprobar el progreso en Inicio.
3. Guardar un autorreporte con intensidad 0 y otro con 100: promedio diario 50. Un día sin registros debe mostrar «Sin datos». Las notas deben conservarse.
4. Mantener SOS 2,5 segundos. Comprobar recepción en base; desde Inicio confirmar como adulto y verificar el nuevo estado en wearable. Cancelar antes del tiempo no debe generar solicitud.
5. Crear otro perfil, seleccionarlo en ambos dispositivos y comprobar que no aparecen las tareas/emociones/SOS del anterior.
6. Desconectar la API, guardar una tarea/emoción, comprobar el estado pendiente, reconectar y verificar una sola fila tras reintentos. No interpretar un guardado local como recepción remota.
7. Sin sensores conectados, GPS/batería/pasos deben indicar ausencia de datos. Probar errores, datos antiguos y cambio de perfil sin mezclar información.

## Verificación automatizada

Pasaron las pruebas unitarias de backend, las dos integraciones PostgreSQL en bases temporales y TypeScript/build de app web y wearable. Integraciones cubren migración repetible, concurrencia, aislamiento, idempotencia, intensidades/promedios, dispositivos con datos ausentes/antiguos, SOS y revocación/recuperación. No sustituyen la aceptación UI ni hardware.

## Inventario completo para aceptación

Cada fila conserva la referencia al Excel. El estado «Pendiente de aceptación» exige revisar el comportamiento íntegro, incluso cuando parte de la función ya está implementada arriba. Las RNF requieren evidencia de pruebas específicas; no se deduce su cumplimiento de una compilación.

| Hoja y fila | ID | Requerimiento | Estado |
| --- | --- | --- | --- |
| login!A4:C4 | RF-02.1 | Inicio de sesión con correo y contraseña | Pendiente de aceptación integral |
| login!A5:C5 | RF-02.2 | Validación de campos obligatorios | Pendiente de aceptación integral |
| login!A6:C6 | RF-02.3 | Validación del formato de correo | Pendiente de aceptación integral |
| login!A7:C7 | RF-02.4 | Resultado de la autenticación | Pendiente de aceptación integral |
| login!A8:C8 | RF-02.5 | Ocultamiento de contraseña | Pendiente de aceptación integral |
| login!A9:C9 | RF-01.1 | Acceso al registro | Pendiente de aceptación integral |
| login!A17:C17 | RNF-ACC-01 | Claridad: los campos, botones, enlaces y mensajes deberán usar textos comprensibles para el adulto responsable. | Pendiente de aceptación integral |
| login!A18:C18 | RNF-ACC-02 | Accesibilidad visual: textos y controles deberán conservar legibilidad y contraste suficiente; la información no dependerá solo del color. | Pendiente de aceptación integral |
| login!A19:C19 | RNF-ACC-03 | Accesibilidad de interacción: el orden de navegación, las etiquetas de los campos y las áreas táctiles deberán facilitar el uso con tecnologías de asistencia. | Pendiente de aceptación integral |
| login!A20:C20 | RNF-ACC-04 | Privacidad: la pantalla y sus mensajes no deberán exponer contraseñas, credenciales ni datos de otras personas. | Pendiente de aceptación integral |
| login!A21:C21 | RNF-ACC-05 | Seguridad de autenticación: las credenciales deberán transmitirse y tratarse mediante mecanismos seguros definidos para la implementación. | Pendiente de aceptación integral |
| login!A22:C22 | RNF-ACC-06 | Manejo de errores: ante credenciales inválidas, problemas de conexión o fallos del proveedor externo, el usuario recibirá un mensaje claro y una acción para continuar o reintentar. | Pendiente de aceptación integral |
| login!A23:C23 | RNF-ACC-07 | Adaptación a pantalla móvil: el formulario deberá mantenerse utilizable en los tamaños de teléfono definidos para el producto, incluso al abrir el teclado. | Pendiente de aceptación integral |
| registro!A4:C4 | RF-01.1 | Ingresar nombre del adulto | Pendiente de aceptación integral |
| registro!A5:C5 | RF-01.2 | Ingresar nombre del usuario | Pendiente de aceptación integral |
| registro!A6:C6 | RF-01.3 | Ingresar edad del usuario | Pendiente de aceptación integral |
| registro!A7:C7 | RF-01.4 | Ingresar número de teléfono | Pendiente de aceptación integral |
| registro!A8:C8 | RF-01.5 | Ingresar correo | Pendiente de aceptación integral |
| registro!A9:C9 | RF-01.6 | Ingresar condición opcional | Pendiente de aceptación integral |
| registro!A10:C10 | RF-01.7 | Validar el formulario | Pendiente de aceptación integral |
| registro!A11:C11 | RF-01.8 | Crear cuenta y perfil inicial | Pendiente de aceptación integral |
| registro!A12:C12 | RF-01.9 | Volver a la pantalla anterior | Pendiente de aceptación integral |
| registro!A17:C17 | RNF-REG-01 | Claridad del formulario. Cada campo tendrá una etiqueta visible; los campos obligatorios y opcionales se distinguirán sin depender únicamente del asterisco o del color. | Pendiente de aceptación integral |
| registro!A18:C18 | RNF-REG-02 | Validaciones comprensibles. Los errores indicarán qué dato corregir y conservarán el resto de la información ingresada. | Pendiente de aceptación integral |
| registro!A19:C19 | RNF-REG-03 | Accesibilidad móvil. Campos y botón serán legibles y utilizables con teclado abierto, ampliación de texto y tecnologías de asistencia. | Pendiente de aceptación integral |
| registro!A20:C20 | RNF-REG-04 | Privacidad de menores. Los datos del niño se asociarán únicamente a adultos autorizados y no se mostrarán a terceros sin autorización. | Pendiente de aceptación integral |
| registro!A21:C21 | RNF-REG-05 | Minimización de datos. Solo se solicitarán datos necesarios para las funciones aprobadas; el diagnóstico permanecerá opcional y deberá justificarse su finalidad antes de almacenarlo. | Pendiente de aceptación integral |
| registro!A22:C22 | RNF-REG-06 | Seguridad. Los datos del formulario se transmitirán y almacenarán mediante los controles de seguridad definidos para la implementación. | Pendiente de aceptación integral |
| registro!A23:C23 | RNF-REG-07 | Integridad. Un reintento o doble pulsación de «Crear cuenta y continuar» no generará dos cuentas ni dos perfiles iniciales. | Pendiente de aceptación integral |
| plan semanal!A4:C4 | RF-PLAN-01 | Mostrar la semana | Pendiente de aceptación integral |
| plan semanal!A5:C5 | RF-PLAN-02 | Seleccionar un día | Pendiente de aceptación integral |
| plan semanal!A6:C6 | RF-PLAN-03 | Mostrar cantidad de actividades | Pendiente de aceptación integral |
| plan semanal!A7:C7 | RF-PLAN-04 | Listar actividades del día | Pendiente de aceptación integral |
| plan semanal!A8:C8 | RF-PLAN-05 | Agregar actividad | Pendiente de aceptación integral |
| plan semanal!A9:C9 | RF-PLAN-06 | Validar nueva actividad | Pendiente de aceptación integral |
| plan semanal!A10:C10 | RF-PLAN-07 | Quitar actividad del día | Pendiente de aceptación integral |
| plan semanal!A11:C11 | RF-PLAN-08 | Actualizar la vista | Pendiente de aceptación integral |
| plan semanal!A12:C12 | RF-PLAN-09 | Guardar planificación | Pendiente de aceptación integral |
| plan semanal!A13:C13 | RF-PLAN-10 | Informar el resultado del guardado | Pendiente de aceptación integral |
| plan semanal!A18:C18 | RNF-PLAN-01 | Claridad visual: el día seleccionado, la cantidad de actividades y la acción principal deberán distinguirse fácilmente. | Pendiente de aceptación integral |
| plan semanal!A19:C19 | RNF-PLAN-02 | Accesibilidad: los días y botones deberán tener nombres comprensibles para tecnologías de asistencia y áreas táctiles utilizables. El color no será el único indicador del día seleccionado. | Pendiente de aceptación integral |
| plan semanal!A20:C20 | RNF-PLAN-03 | Consistencia: los nombres de días, horarios, contadores y mensajes tendrán el mismo formato en toda la planificación. | Pendiente de aceptación integral |
| plan semanal!A21:C21 | RNF-PLAN-04 | Integridad: un error al guardar no deberá provocar pérdida silenciosa de actividades ni mostrar cambios no confirmados como guardados. | Pendiente de aceptación integral |
| plan semanal!A22:C22 | RNF-PLAN-05 | Protección frente a errores: la eliminación deberá ser reversible o requerir confirmación, y una pulsación repetida en «Guardar» no duplicará actividades. | Pendiente de aceptación integral |
| plan semanal!A23:C23 | RNF-PLAN-06 | Uso en móvil: la lista y el botón «Guardar y continuar» deberán seguir siendo utilizables cuando existan muchas actividades o se abra el teclado. | Pendiente de aceptación integral |
| inicio!A4:C4 | RF-INI-01 | Identificar el perfil activo | Pendiente de aceptación integral |
| inicio!A5:C5 | RF-INI-02 | Mostrar la fecha | Pendiente de aceptación integral |
| inicio!A6:C6 | RF-INI-03 | Consultar notificaciones | Pendiente de aceptación integral |
| inicio!A7:C7 | RF-INI-04 | Consultar el estado emocional | Pendiente de aceptación integral |
| inicio!A8:C8 | RF-INI-05 | Abrir el detalle de emociones | Pendiente de aceptación integral |
| inicio!A9:C9 | RF-INI-06 | Consultar ubicación disponible | Pendiente de aceptación integral |
| inicio!A10:C10 | RF-INI-07 | Abrir la vista de ubicación | Pendiente de aceptación integral |
| inicio!A11:C11 | RF-INI-08 | Mostrar progreso de la rutina | Pendiente de aceptación integral |
| inicio!A12:C12 | RF-INI-09 | Agrupar actividades por momento del día | Pendiente de aceptación integral |
| inicio!A13:C13 | RF-INI-10 | Mostrar datos de cada actividad | Pendiente de aceptación integral |
| inicio!A14:C14 | RF-INI-11 | Marcar una actividad como completada | Pendiente de aceptación integral |
| inicio!A15:C15 | RF-INI-12 | Recorrer la rutina | Pendiente de aceptación integral |
| inicio!A16:C16 | RF-INI-13 | Navegar entre secciones | Pendiente de aceptación integral |
| inicio!A17:C17 | RF-INI-14 | Abrir opciones del perfil | Pendiente de aceptación integral |
| inicio!A22:C22 | RNF-INI-01 | Vigencia de datos: ubicación, emociones y estados provenientes del wearable deberán mostrar cuándo se actualizaron o indicar que la información no está disponible. | Pendiente de aceptación integral |
| inicio!A23:C23 | RNF-INI-02 | Consistencia: el nombre, la rutina, el porcentaje, las emociones y la ubicación deberán pertenecer al mismo perfil activo. | Pendiente de aceptación integral |
| inicio!A24:C24 | RNF-INI-03 | Accesibilidad: iconos, colores y tachado de actividades deberán acompañarse de etiquetas o estados comprensibles; el color por sí solo no indicará si una tarea está completada. | Pendiente de aceptación integral |
| inicio!A25:C25 | RNF-INI-04 | Legibilidad: horarios, nombres y controles deberán seguir siendo utilizables con actividades de nombres largos y con texto ampliado. | Pendiente de aceptación integral |
| inicio!A26:C26 | RNF-INI-05 | Privacidad: solo un adulto autorizado podrá consultar datos del perfil, especialmente emociones y ubicación. | Pendiente de aceptación integral |
| inicio!A27:C27 | RNF-INI-06 | Integridad del progreso: una acción repetida o un fallo de sincronización no deberá contar dos veces una actividad ni mostrar un cambio pendiente como confirmado. | Pendiente de aceptación integral |
| inicio!A28:C28 | RNF-INI-07 | Degradación clara: si no hay conexión, GPS o datos recientes, la pantalla deberá seguir mostrando la última información válida con su vigencia, sin presentarla como actual. | Pendiente de aceptación integral |
| rutinas!A4:C4 | RF-RUT-01 | Mostrar rutinas del día | Pendiente de aceptación integral |
| rutinas!A5:C5 | RF-RUT-02 | Mostrar horarios por bloque | Pendiente de aceptación integral |
| rutinas!A6:C6 | RF-RUT-03 | Expandir o contraer bloques | Pendiente de aceptación integral |
| rutinas!A7:C7 | RF-RUT-04 | Listar tareas | Pendiente de aceptación integral |
| rutinas!A8:C8 | RF-RUT-05 | Completar una tarea | Pendiente de aceptación integral |
| rutinas!A9:C9 | RF-RUT-06 | Abrir el detalle de una tarea | Pendiente de aceptación integral |
| rutinas!A10:C10 | RF-RUT-07 | Quitar una tarea | Pendiente de aceptación integral |
| rutinas!A11:C11 | RF-RUT-08 | Añadir tarea a un bloque | Pendiente de aceptación integral |
| rutinas!A12:C12 | RF-RUT-09 | Planificar actividades | Pendiente de aceptación integral |
| rutinas!A13:C13 | RF-RUT-10 | Calcular progreso diario | Pendiente de aceptación integral |
| rutinas!A14:C14 | RF-RUT-11 | Navegar entre secciones | Pendiente de aceptación integral |
| rutinas!A19:C19 | RNF-RUT-01 | Consistencia de datos: el contador de cada bloque, el total diario y la barra de progreso deberán actualizarse juntos. | Pendiente de aceptación integral |
| rutinas!A20:C20 | RNF-RUT-02 | Claridad de acciones: marcar, abrir detalle y quitar deberán tener iconos y áreas táctiles que permitan distinguir sus funciones. | Pendiente de aceptación integral |
| rutinas!A21:C21 | RNF-RUT-03 | Accesibilidad: el estado de una tarea no dependerá únicamente del color o de la casilla; los controles tendrán etiquetas comprensibles para tecnologías de asistencia. | Pendiente de aceptación integral |
| rutinas!A22:C22 | RNF-RUT-04 | Integridad: una tarea marcada o editada con sincronización pendiente no deberá presentarse como confirmada en el wearable. | Pendiente de aceptación integral |
| rutinas!A23:C23 | RNF-RUT-05 | Legibilidad: la pantalla deberá seguir siendo utilizable con nombres largos y con más tareas que las seis visibles en Mañana. | Pendiente de aceptación integral |
| rutinas!A24:C24 | RNF-RUT-06 | Protección ante errores: quitar una tarea no deberá producir una pérdida silenciosa; los cambios fallidos conservarán el último estado válido. | Pendiente de aceptación integral |
| agenda!A4:C4 | RF-AGE-01 | Mostrar el mes | Pendiente de aceptación integral |
| agenda!A5:C5 | RF-AGE-02 | Cambiar de mes | Pendiente de aceptación integral |
| agenda!A6:C6 | RF-AGE-03 | Seleccionar una fecha | Pendiente de aceptación integral |
| agenda!A7:C7 | RF-AGE-04 | Identificar fechas con actividades | Pendiente de aceptación integral |
| agenda!A8:C8 | RF-AGE-05 | Mostrar la fecha seleccionada | Pendiente de aceptación integral |
| agenda!A9:C9 | RF-AGE-06 | Listar actividades del día | Pendiente de aceptación integral |
| agenda!A10:C10 | RF-AGE-07 | Consultar una actividad | Pendiente de aceptación integral |
| agenda!A11:C11 | RF-AGE-08 | Acceder a planificación | Pendiente de aceptación integral |
| agenda!A12:C12 | RF-AGE-09 | Mostrar un día sin actividades | Pendiente de aceptación integral |
| agenda!A13:C13 | RF-AGE-10 | Navegar entre secciones | Pendiente de aceptación integral |
| agenda!A18:C18 | RNF-AGE-01 | Consistencia de fechas: el día de la semana, número, mes y actividades deberán corresponder a la misma fecha y al mismo perfil activo. | Pendiente de aceptación integral |
| agenda!A19:C19 | RNF-AGE-02 | Claridad: el día seleccionado se identificará también mediante forma o etiqueta; los puntos de colores no serán la única forma de comunicar información. | Pendiente de aceptación integral |
| agenda!A20:C20 | RNF-AGE-03 | Legibilidad: nombres y horarios seguirán siendo comprensibles con actividades largas o con varias actividades el mismo día. | Pendiente de aceptación integral |
| agenda!A21:C21 | RNF-AGE-04 | Accesibilidad: las flechas, fechas, tarjetas y navegación inferior tendrán etiquetas y áreas táctiles utilizables. | Pendiente de aceptación integral |
| agenda!A22:C22 | RNF-AGE-05 | Integridad: una actividad agregada o editada deberá reflejarse de forma coherente en Agenda, Planificación Semanal, Mis Rutinas e Inicio. | Pendiente de aceptación integral |
| agenda!A23:C23 | RNF-AGE-06 | Vigencia: si los cambios aún no se han guardado o sincronizado, la agenda deberá indicar su estado sin presentarlos como confirmados en el wearable. | Pendiente de aceptación integral |
| emociones!A4:C4 | RF-EMO-01 | Seleccionar emociones | Pendiente de aceptación integral |
| emociones!A5:C5 | RF-EMO-02 | Indicar intensidad | Pendiente de aceptación integral |
| emociones!A6:C6 | RF-EMO-03 | Registrar el estado | Pendiente de aceptación integral |
| emociones!A7:C7 | RF-EMO-04 | Consultar registros diarios | Pendiente de aceptación integral |
| emociones!A8:C8 | RF-EMO-05 | Mostrar resumen semanal | Pendiente de aceptación integral |
| emociones!A9:C9 | RF-EMO-06 | Consultar detalle del gráfico | Pendiente de aceptación integral |
| emociones!A14:C14 | RNF-EMO-01 | Comprensión: la pantalla explicará que el porcentaje indica cuánto siente el usuario cada emoción según su propia percepción. | Pendiente de aceptación integral |
| emociones!A15:C15 | RNF-EMO-02 | Interacción accesible: la intensidad podrá ajustarse mediante la barra y mediante controles alternativos, como botones para aumentar o disminuir el valor. | Pendiente de aceptación integral |
| emociones!A16:C16 | RNF-EMO-03 | Lectura accesible: cada barra mostrará el nombre de la emoción y su porcentaje en texto; el color o la altura no serán la única forma de interpretar el dato. | Pendiente de aceptación integral |
| emociones!A17:C17 | RNF-EMO-04 | Consistencia de escala: todas las emociones utilizarán la misma escala de 0 a 100 % y el mismo criterio visual en el registro diario y los resúmenes. | Pendiente de aceptación integral |
| emociones!A18:C18 | RNF-EMO-05 | Exactitud del cálculo: los promedios se calcularán con los registros del perfil y período seleccionados, siguiendo la fórmula documentada y una regla de redondeo única. | Pendiente de aceptación integral |
| emociones!A19:C19 | RNF-EMO-06 | Tratamiento de datos faltantes: un día sin registros se identificará como «Sin datos» y no se incorporará al promedio como 0 %. | Pendiente de aceptación integral |
| emociones!A20:C20 | RNF-EMO-07 | Trazabilidad del resumen: el usuario podrá reconocer qué días y registros se incluyeron en cada promedio semanal. | Pendiente de aceptación integral |
| emociones!A21:C21 | RNF-EMO-08 | Privacidad: solo los adultos autorizados y el propio usuario, según los permisos definidos para MOVA, podrán consultar sus registros emocionales y notas. | Pendiente de aceptación integral |
| emociones!A22:C22 | RNF-EMO-09 | Minimización: las notas libres serán opcionales y el sistema no solicitará información clínica para registrar una emoción. | Pendiente de aceptación integral |
| emociones!A23:C23 | RNF-EMO-10 | Integridad: un fallo al guardar o sincronizar no deberá duplicar registros ni mostrar uno pendiente como confirmado. | Pendiente de aceptación integral |
| emociones!A24:C24 | RNF-EMO-11 | Lenguaje responsable: los gráficos se presentarán como un autorreporte de emociones; no emitirán diagnósticos ni afirmarán conocer el estado emocional real del niño. | Pendiente de aceptación integral |
| emociones!A25:C25 | RNF-EMO-12 | Uso móvil: las barras, etiquetas y gráfico semanal seguirán siendo utilizables con texto ampliado y en los tamaños de pantalla definidos para la app. | Pendiente de aceptación integral |
| gps!A4:C4 | RF-UBI-01 | Identificar el perfil y dispositivo | Pendiente de aceptación integral |
| gps!A5:C5 | RF-UBI-02 | Mostrar última ubicación disponible | Pendiente de aceptación integral |
| gps!A6:C6 | RF-UBI-03 | Indicar vigencia de la ubicación | Pendiente de aceptación integral |
| gps!A7:C7 | RF-UBI-04 | Consultar detalle del mapa | Pendiente de aceptación integral |
| gps!A8:C8 | RF-UBI-05 | Mostrar estado de conexión | Pendiente de aceptación integral |
| gps!A9:C9 | RF-UBI-06 | Mostrar batería disponible | Pendiente de aceptación integral |
| gps!A10:C10 | RF-UBI-07 | Mostrar pasos disponibles | Pendiente de aceptación integral |
| gps!A11:C11 | RF-UBI-08 | Volver a la pantalla anterior | Pendiente de aceptación integral |
| gps!A12:C12 | RF-UBI-09 | Gestionar ausencia de datos | Pendiente de aceptación integral |
| gps!A17:C17 | RNF-UBI-01 | Vigencia: ningún dato antiguo se presentará como actual; ubicación, batería y pasos mostrarán su propia hora de actualización. | Pendiente de aceptación integral |
| gps!A18:C18 | RNF-UBI-02 | Precisión comprensible: la interfaz indicará que la posición puede ser aproximada y depender de la señal y del dispositivo. | Pendiente de aceptación integral |
| gps!A19:C19 | RNF-UBI-03 | Privacidad: la ubicación del niño solo será visible para adultos autorizados del perfil. | Pendiente de aceptación integral |
| gps!A20:C20 | RNF-UBI-04 | Minimización: el sistema conservará únicamente los datos de ubicación y actividad necesarios para la función aprobada, según una política de conservación que el equipo deberá definir. | Pendiente de aceptación integral |
| gps!A21:C21 | RNF-UBI-05 | Accesibilidad: la ubicación y el estado del dispositivo deberán poder comprenderse mediante texto, sin depender solo del marcador, el color o el mapa. | Pendiente de aceptación integral |
| gps!A22:C22 | RNF-UBI-06 | Tolerancia a fallos: si falla la carga del mapa, la pantalla seguirá mostrando el último dato disponible con su fecha y un mensaje de error. | Pendiente de aceptación integral |
| gps!A23:C23 | RNF-UBI-07 | Consistencia: todos los indicadores deberán pertenecer al mismo perfil y dispositivo seleccionado. | Pendiente de aceptación integral |
| gps!A24:C24 | RNF-UBI-08 | Consumo energético condicionado: la frecuencia de obtención y envío de ubicación deberá definirse después de probar la autonomía del wearable. | Pendiente de aceptación integral |
| gps!A25:C25 | RNF-UBI-09 | Seguridad de datos: la transmisión y consulta de ubicación requerirán controles de acceso y protección técnica acordes con la arquitectura final. | Pendiente de aceptación integral |
| config!A4:C4 | RF-AJU-01 | Mostrar perfil activo | Pendiente de aceptación integral |
| config!A5:C5 | RF-AJU-02 | Consultar y editar perfil | Pendiente de aceptación integral |
| config!A6:C6 | RF-AJU-03 | Agregar perfil | Pendiente de aceptación integral |
| config!A7:C7 | RF-AJU-04 | Consultar perfil de usuario | Pendiente de aceptación integral |
| config!A8:C8 | RF-AJU-05 | Configurar notificaciones | Pendiente de aceptación integral |
| config!A9:C9 | RF-AJU-06 | Consultar privacidad y seguridad | Pendiente de aceptación integral |
| config!A10:C10 | RF-AJU-07 | Consultar o cambiar idioma | Pendiente de aceptación integral |
| config!A11:C11 | RF-AJU-08 | Consultar dispositivo MOVA | Pendiente de aceptación integral |
| config!A12:C12 | RF-AJU-09 | Gestionar conexión del dispositivo | Pendiente de aceptación integral |
| config!A13:C13 | RF-AJU-10 | Consultar redes sociales conectadas | Pendiente de aceptación integral |
| config!A14:C14 | RF-AJU-11 | Abrir centro de ayuda | Pendiente de aceptación integral |
| config!A15:C15 | RF-AJU-12 | Acceder a valoración | Pendiente de aceptación integral |
| config!A16:C16 | RF-AJU-13 | Consultar términos y privacidad | Pendiente de aceptación integral |
| config!A17:C17 | RF-AJU-14 | Cerrar sesión | Pendiente de aceptación integral |
| config!A18:C18 | RF-AJU-15 | Mostrar versión | Pendiente de aceptación integral |
| config!A19:C19 | RF-AJU-16 | Navegar entre secciones | Pendiente de aceptación integral |
| config!A24:C24 | RNF-AJU-01 | Claridad de perfiles: el adulto deberá poder distinguir qué datos son de su cuenta y cuáles pertenecen al perfil del niño. | Pendiente de aceptación integral |
| config!A25:C25 | RNF-AJU-02 | Consistencia: los cambios de perfil, idioma o preferencias deberán reflejarse en las pantallas correspondientes sin mezclar datos de distintos perfiles. | Pendiente de aceptación integral |
| config!A26:C26 | RNF-AJU-03 | Accesibilidad: todas las filas, iconos y botones tendrán etiquetas comprensibles y áreas táctiles utilizables; su función no dependerá solo del icono. | Pendiente de aceptación integral |
| config!A27:C27 | RNF-AJU-04 | Privacidad: los datos del menor y la configuración del dispositivo solo serán visibles para adultos autorizados. | Pendiente de aceptación integral |
| config!A28:C28 | RNF-AJU-05 | Vigencia del dispositivo: batería y conexión mostrarán cuándo se obtuvo el dato; un valor antiguo no se presentará como actual. | Pendiente de aceptación integral |
| config!A29:C29 | RNF-AJU-06 | Seguridad de sesión: después de cerrar sesión, el acceso a información protegida requerirá autenticación nuevamente. | Pendiente de aceptación integral |
| config!A30:C30 | RNF-AJU-07 | Confirmación de cambios: la app comunicará si una configuración se guardó, está pendiente o falló, y conservará el último valor válido ante un error. | Pendiente de aceptación integral |
| config!A31:C31 | RNF-AJU-08 | Legibilidad móvil: la pantalla permitirá desplazarse sin que la barra inferior tape opciones como «Cerrar sesión». | Pendiente de aceptación integral |
| config!A32:C32 | RNF-AJU-09 | Identificación de versión: la versión visible corresponderá a la compilación instalada y no quedará fijada como texto decorativo en la app real. | Pendiente de aceptación integral |
| dispositivo!A4:C4 | RF-WEA-01 | Principal | Pendiente de aceptación integral |
| dispositivo!A5:C5 | RF-WEA-02 | Principal | Pendiente de aceptación integral |
| dispositivo!A6:C6 | RF-WEA-03 | Principal | Pendiente de aceptación integral |
| dispositivo!A7:C7 | RF-WEA-04 | Principal | Pendiente de aceptación integral |
| dispositivo!A8:C8 | RF-WEA-05 | Principal | Pendiente de aceptación integral |
| dispositivo!A9:C9 | RF-WEA-06 | Principal | Pendiente de aceptación integral |
| dispositivo!A10:C10 | RF-WEA-07 | SOS | Pendiente de aceptación integral |
| dispositivo!A11:C11 | RF-WEA-08 | Actividades | Pendiente de aceptación integral |
| dispositivo!A12:C12 | RF-WEA-09 | Actividades | Pendiente de aceptación integral |
| dispositivo!A13:C13 | RF-WEA-10 | Actividades | Pendiente de aceptación integral |
| dispositivo!A14:C14 | RF-WEA-11 | Emociones | Pendiente de aceptación integral |
| dispositivo!A15:C15 | RF-WEA-12 | Emociones | Pendiente de aceptación integral |
| dispositivo!A16:C16 | RF-WEA-13 | Emociones | Pendiente de aceptación integral |
| dispositivo!A17:C17 | RF-WEA-14 | Emociones | Pendiente de aceptación integral |
| dispositivo!A22:C22 | RNF-WEA-01 | Baja complejidad: cada pantalla tendrá una acción principal clara y evitará pasos innecesarios para completar tareas, expresar emociones o solicitar ayuda. | Pendiente de aceptación integral |
| dispositivo!A23:C23 | RNF-WEA-02 | Legibilidad: textos, horarios, porcentaje e íconos deberán poder distinguirse en el tamaño físico de pantalla elegido. | Pendiente de aceptación integral |
| dispositivo!A24:C24 | RNF-WEA-03 | Accesibilidad: cada emoción tendrá texto además del emoji; los estados de actividades y SOS no dependerán únicamente del color. | Pendiente de aceptación integral |
| dispositivo!A25:C25 | RNF-WEA-04 | Facilidad táctil: botones, casillas y opciones de emoción tendrán tamaño y separación suficientes para evitar pulsaciones equivocadas. | Pendiente de aceptación integral |
| dispositivo!A26:C26 | RNF-WEA-05 | Prevención de SOS accidental: el gesto de activación deberá reducir activaciones involuntarias sin dificultar el uso por el niño. | Pendiente de aceptación integral |
| dispositivo!A27:C27 | RNF-WEA-06 | Integridad de SOS: una solicitud fallida nunca se presentará como entregada; los reintentos no generarán alertas duplicadas por una sola activación. | Pendiente de aceptación integral |
| dispositivo!A28:C28 | RNF-WEA-07 | Funcionamiento sin conexión: el wearable conservará la última rutina válida y podrá mostrar actividades y registros pendientes cuando pierda conectividad. | Pendiente de aceptación integral |
| dispositivo!A29:C29 | RNF-WEA-08 | Consistencia de sincronización: actividades y emociones deberán corresponder al perfil vinculado; los cambios pendientes se distinguirán de los confirmados en la app. | Pendiente de aceptación integral |
| dispositivo!A30:C30 | RNF-WEA-09 | Privacidad: la pantalla mostrará solo los datos necesarios para que el niño use sus rutinas; los registros del perfil no serán accesibles desde otro dispositivo sin autorización. | Pendiente de aceptación integral |
| dispositivo!A31:C31 | RNF-WEA-10 | Autonomía condicionada: no se establecerá una duración de batería hasta probar el hardware con el uso previsto de pantalla, conectividad y SOS. | Pendiente de aceptación integral |
| dispositivo!A32:C32 | RNF-WEA-11 | Lenguaje comprensible: mensajes como «Pendiente», «Enviado» y «No se pudo enviar» deberán explicarse con palabras adecuadas para el usuario y el adulto. | Pendiente de aceptación integral |
| dispositivo!A33:C33 | RNF-WEA-12 | Fecha y hora confiables: los registros y recordatorios usarán una hora consistente; si el reloj pierde sincronización, deberá evitar mostrar como actuales datos con hora incierta. | Pendiente de aceptación integral |
