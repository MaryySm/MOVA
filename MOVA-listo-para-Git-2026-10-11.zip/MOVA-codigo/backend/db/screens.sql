-- Rutinas de pantalla. Todas reciben la cuenta autenticada desde la API.
-- PostgreSQL usa funciones para devolver filas/JSON; se invocan con SELECT.
BEGIN;
CREATE SCHEMA IF NOT EXISTS mova_api;
CREATE TABLE IF NOT EXISTS mova_interno.configuracion (
  user_id UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  datos JSONB NOT NULL DEFAULT '{}' CHECK (jsonb_typeof(datos) = 'object')
);
CREATE TABLE IF NOT EXISTS mova_interno.eventos (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  titulo TEXT NOT NULL CHECK (length(trim(titulo)) BETWEEN 1 AND 200),
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  UNIQUE(user_id,id)
);
CREATE INDEX IF NOT EXISTS eventos_cuenta_fecha ON mova_interno.eventos(user_id,fecha,hora);
CREATE TABLE IF NOT EXISTS mova_interno.notas_emocion (
  user_id UUID NOT NULL,
  event_id UUID NOT NULL,
  nota TEXT NOT NULL DEFAULT '' CHECK (length(nota) <= 2000),
  etiquetas JSONB NOT NULL DEFAULT '[]' CHECK (jsonb_typeof(etiquetas) = 'array'),
  PRIMARY KEY(user_id,event_id),
  FOREIGN KEY(user_id,event_id) REFERENCES mova_interno.registros(user_id,event_id) ON DELETE CASCADE
);

CREATE OR REPLACE FUNCTION mova_api.sp_registro(adulto TEXT,nombre TEXT,edad SMALLINT,
  telefono TEXT,correo TEXT,diagnostico TEXT,hash TEXT,sal TEXT)
RETURNS SETOF users LANGUAGE SQL AS $$
  INSERT INTO users(adult_name,user_name,age,phone,email,diagnosis,password_hash,password_salt)
  VALUES(trim(adulto),trim(nombre),edad,trim(telefono),lower(trim(correo)),diagnostico,hash,sal)
  RETURNING *;
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_login(correo TEXT) RETURNS SETOF users LANGUAGE SQL STABLE AS $$
  SELECT * FROM users WHERE email=lower(trim(correo));
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_perfil(cuenta UUID)
RETURNS TABLE(id UUID,adult_name TEXT,user_name TEXT,age SMALLINT,phone TEXT,email TEXT,diagnosis TEXT)
LANGUAGE SQL STABLE AS $$
  SELECT id,adult_name,user_name,age,phone,email,diagnosis FROM users WHERE id=cuenta;
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_historial(cuenta UUID,cantidad INTEGER DEFAULT 50)
RETURNS TABLE(id BIGINT,"eventId" UUID,"deviceId" TEXT,activities JSONB,emotion TEXT,
  "progressPercent" SMALLINT,"recordedAt" TIMESTAMPTZ,"receivedAt" TIMESTAMPTZ)
LANGUAGE SQL STABLE AS $$
  SELECT id,event_id,device_id,activities,emotion,progress_percent,recorded_at,received_at
  FROM mova_interno.registros WHERE user_id=cuenta ORDER BY id DESC LIMIT greatest(1,least(cantidad,200));
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_rutina(cuenta UUID) RETURNS JSONB LANGUAGE SQL STABLE AS $$
  SELECT coalesce((SELECT jsonb_build_object('activities',activities,'emotion',emotion,
    'progressPercent',progress_percent,'recordedAt',recorded_at)
    FROM mova_interno.registros WHERE user_id=cuenta ORDER BY id DESC LIMIT 1),
    '{"activities":[],"emotion":null,"progressPercent":0}'::jsonb);
$$;

-- Único punto de escritura: bloqueo por cuenta, idempotencia y progreso calculado.
CREATE OR REPLACE FUNCTION mova_api.sp_guardar_registro(cuenta UUID,evento UUID,dispositivo TEXT,
  lista JSONB,emocion TEXT,fecha TIMESTAMPTZ) RETURNS BOOLEAN LANGUAGE plpgsql AS $$
DECLARE anterior mova_interno.registros%ROWTYPE; porcentaje SMALLINT; normalizada JSONB; animo TEXT;
BEGIN
  PERFORM id FROM users WHERE id=cuenta FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Cuenta no disponible' USING ERRCODE='P0002'; END IF;
  IF EXISTS(SELECT 1 FROM mova_interno.registros WHERE user_id=cuenta AND event_id=evento) THEN RETURN FALSE; END IF;
  IF lista IS NULL OR jsonb_typeof(lista) <> 'array' THEN
    RAISE EXCEPTION 'Lista de tareas inválida' USING ERRCODE='22023'; END IF;
  IF jsonb_array_length(lista)>100 OR EXISTS(SELECT 1 FROM jsonb_array_elements(lista) a
    WHERE jsonb_typeof(a)<>'object' OR coalesce(length(trim(a->>'id')),0) NOT BETWEEN 1 AND 160
    OR coalesce(length(trim(a->>'label')),0) NOT BETWEEN 1 AND 200
    OR (a->>'time') IS NULL OR (a->>'time') !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'
    OR jsonb_typeof(a->'done') IS DISTINCT FROM 'boolean')
    OR (SELECT count(*)<>count(DISTINCT a->>'id') FROM jsonb_array_elements(lista) a)
    OR dispositivo IS NULL OR length(trim(dispositivo)) NOT BETWEEN 1 AND 160
    OR fecha IS NULL OR fecha > now()+interval '5 minutes'
    OR (emocion IS NOT NULL AND length(trim(emocion)) NOT BETWEEN 1 AND 80) THEN
    RAISE EXCEPTION 'Registro inválido' USING ERRCODE='22023'; END IF;
  SELECT * INTO anterior FROM mova_interno.registros WHERE user_id=cuenta ORDER BY id DESC LIMIT 1;
  normalizada := mova_interno.nombres_tareas(lista); animo := mova_interno.nombre_emocion(emocion);
  SELECT coalesce(round(100.0*count(*) FILTER(WHERE (a->>'done')::boolean)/nullif(count(*),0)),0)
    INTO porcentaje FROM jsonb_array_elements(normalizada) a;
  INSERT INTO mova_interno.registros(user_id,event_id,device_id,activities,emotion,progress_percent,recorded_at)
    VALUES(cuenta,evento,dispositivo,normalizada,animo,porcentaje,fecha);
  RETURN TRUE;
END $$;

CREATE OR REPLACE FUNCTION mova_api.sp_accion_rutina(cuenta UUID,accion JSONB,legacy BOOLEAN DEFAULT FALSE)
RETURNS BOOLEAN LANGUAGE plpgsql AS $$
DECLARE estado JSONB; lista JSONB; animo TEXT; tipo TEXT; tarea TEXT;
BEGIN
  PERFORM id FROM users WHERE id=cuenta FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Cuenta no disponible' USING ERRCODE='P0002'; END IF;
  IF EXISTS(SELECT 1 FROM mova_interno.registros WHERE user_id=cuenta AND event_id=(accion->>'actionId')::uuid) THEN RETURN FALSE; END IF;
  estado:=mova_api.sp_rutina(cuenta); lista:=estado->'activities'; animo:=estado->>'emotion';
  tipo:=accion->>'type'; tarea:=accion->>'taskId';
  IF legacy THEN
    IF NOT EXISTS(SELECT 1 FROM mova_interno.registros WHERE user_id=cuenta) THEN lista:=accion->'activities';
    ELSE SELECT coalesce(jsonb_agg(a || coalesce((SELECT jsonb_build_object('done',b->'done')
      FROM jsonb_array_elements(accion->'activities') b WHERE b->>'id'=a->>'id'),'{}'::jsonb)),'[]')
      INTO lista FROM jsonb_array_elements(lista) a; END IF;
    animo:=coalesce(accion->>'emotion',animo);
  ELSIF tipo='add_task' THEN
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(lista) a WHERE a->>'id'=tarea) THEN
      lista:=lista || jsonb_build_array(jsonb_build_object('id',tarea,'label',accion->>'label','time',accion->>'time','done',false)); END IF;
  ELSIF tipo IN ('set_done','remove_task') THEN
    IF NOT EXISTS(SELECT 1 FROM jsonb_array_elements(lista) a WHERE a->>'id'=tarea) THEN
      RAISE EXCEPTION 'Tarea no encontrada' USING ERRCODE='22023'; END IF;
    SELECT coalesce(jsonb_agg(CASE WHEN a->>'id'=tarea AND tipo='set_done'
      THEN a || jsonb_build_object('done',accion->'done') ELSE a END),'[]') INTO lista
      FROM jsonb_array_elements(lista) a WHERE tipo<>'remove_task' OR a->>'id'<>tarea;
  ELSIF tipo='set_emotion' THEN animo:=accion->>'emotion';
  ELSE RAISE EXCEPTION 'Acción inválida' USING ERRCODE='22023'; END IF;
  RETURN mova_api.sp_guardar_registro(cuenta,(accion->>'actionId')::uuid,'mova-connected',lista,animo,now());
END $$;

CREATE OR REPLACE FUNCTION mova_api.sp_configuracion(cuenta UUID) RETURNS JSONB LANGUAGE SQL STABLE AS $$
  SELECT coalesce((SELECT datos FROM mova_interno.configuracion WHERE user_id=cuenta),'{}');
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_guardar_configuracion(cuenta UUID,valor JSONB) RETURNS JSONB LANGUAGE SQL AS $$
  INSERT INTO mova_interno.configuracion VALUES(cuenta,valor)
  ON CONFLICT(user_id) DO UPDATE SET datos=mova_interno.configuracion.datos || excluded.datos RETURNING datos;
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_calendario(cuenta UUID,desde DATE,hasta DATE) RETURNS JSONB LANGUAGE SQL STABLE AS $$
  SELECT coalesce(jsonb_agg(jsonb_build_object('id',id,'title',titulo,'date',fecha,'time',to_char(hora,'HH24:MI')) ORDER BY fecha,hora,id),'[]')
  FROM mova_interno.eventos WHERE user_id=cuenta AND fecha BETWEEN desde AND hasta;
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_guardar_evento(cuenta UUID,eventо UUID,nombre TEXT,dia DATE,hora_evento TIME)
RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE resultado UUID;
BEGIN
  INSERT INTO mova_interno.eventos(id,user_id,titulo,fecha,hora) VALUES(eventо,cuenta,nombre,dia,hora_evento)
  ON CONFLICT(id) DO UPDATE SET titulo=excluded.titulo,fecha=excluded.fecha,hora=excluded.hora
    WHERE mova_interno.eventos.user_id=cuenta RETURNING id INTO resultado;
  IF resultado IS NULL THEN RAISE EXCEPTION 'Evento no disponible' USING ERRCODE='22023'; END IF;
  RETURN resultado;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_eliminar_evento(cuenta UUID,evento UUID) RETURNS VOID LANGUAGE SQL AS $$
  DELETE FROM mova_interno.eventos WHERE user_id=cuenta AND id=evento;
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_emociones(cuenta UUID) RETURNS JSONB LANGUAGE SQL STABLE AS $$
  SELECT coalesce(jsonb_agg(to_jsonb(e) ORDER BY e.id DESC),'[]') FROM (
    SELECT r.id,r.event_id AS "eventId",r.emotion,r.recorded_at AS "recordedAt",n.nota AS note,n.etiquetas AS tags
    FROM mova_interno.registros r LEFT JOIN mova_interno.notas_emocion n USING(user_id,event_id)
    WHERE r.user_id=cuenta AND r.emotion IS NOT NULL ORDER BY r.id DESC LIMIT 200) e;
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_guardar_emocion(cuenta UUID,evento UUID,animo TEXT,nota TEXT,etiquetas JSONB)
RETURNS BOOLEAN LANGUAGE plpgsql AS $$
DECLARE guardado BOOLEAN;
BEGIN
  guardado:=mova_api.sp_accion_rutina(cuenta,jsonb_build_object('actionId',evento,'type','set_emotion','emotion',animo));
  IF guardado THEN INSERT INTO mova_interno.notas_emocion VALUES(cuenta,evento,nota,etiquetas); END IF;
  RETURN guardado;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_guardar_sync(cuenta UUID,dispositivo TEXT,datos JSONB)
RETURNS TABLE(id BIGINT,synced_at TIMESTAMPTZ) LANGUAGE SQL AS $$
  INSERT INTO wearable_syncs(user_id,device_id,payload) VALUES(cuenta,dispositivo,datos) RETURNING id,synced_at;
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_dispositivo(cuenta UUID,cantidad INTEGER DEFAULT 50)
RETURNS TABLE(id BIGINT,"deviceId" TEXT,payload JSONB,"syncedAt" TIMESTAMPTZ) LANGUAGE SQL STABLE AS $$
  SELECT id,device_id,payload,synced_at FROM wearable_syncs WHERE user_id=cuenta
  ORDER BY synced_at DESC,id DESC LIMIT greatest(1,least(cantidad,200));
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_inicio(cuenta UUID) RETURNS JSONB LANGUAGE SQL STABLE AS $$
  SELECT jsonb_build_object('routine',mova_api.sp_rutina(cuenta),'settings',mova_api.sp_configuracion(cuenta),
    'events',mova_api.sp_calendario(cuenta,(now() AT TIME ZONE 'America/Santiago')::date,
      (now() AT TIME ZONE 'America/Santiago')::date),'device',(SELECT to_jsonb(d) FROM mova_api.sp_dispositivo(cuenta,1) d));
$$;
COMMIT;
