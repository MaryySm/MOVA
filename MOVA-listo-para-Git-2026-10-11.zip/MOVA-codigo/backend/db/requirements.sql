-- RF/RNF: perfiles separados y una fuente de actividades para app y wearable.
BEGIN;
CREATE TABLE IF NOT EXISTS mova_interno.perfiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  nombre TEXT NOT NULL CHECK(length(trim(nombre)) BETWEEN 1 AND 160),
  edad SMALLINT NOT NULL CHECK(edad BETWEEN 1 AND 120),
  foto TEXT NOT NULL DEFAULT '' CHECK(length(foto)<=150000),
  preferencias JSONB NOT NULL DEFAULT '{"vibration":true,"sound":true,"lights":true,"intensity":6}'
    CHECK(jsonb_typeof(preferencias)='object'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(user_id,id)
);
INSERT INTO mova_interno.perfiles(id,user_id,nombre,edad)
  SELECT id,id,user_name,age FROM users ON CONFLICT(id) DO NOTHING;
CREATE TABLE IF NOT EXISTS mova_interno.actividades (
  id TEXT NOT NULL CHECK(length(id) BETWEEN 1 AND 160),
  user_id UUID NOT NULL,
  profile_id UUID NOT NULL,
  nombre TEXT NOT NULL CHECK(length(trim(nombre)) BETWEEN 1 AND 200),
  fecha DATE NOT NULL,
  hora TIME NOT NULL,
  duracion SMALLINT NOT NULL DEFAULT 30 CHECK(duracion BETWEEN 1 AND 1440),
  completada BOOLEAN NOT NULL DEFAULT FALSE,
  eliminada BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(profile_id,id),
  FOREIGN KEY(user_id,profile_id) REFERENCES mova_interno.perfiles(user_id,id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS actividades_perfil_fecha ON mova_interno.actividades(profile_id,fecha,hora);
CREATE TABLE IF NOT EXISTS mova_interno.progreso_diario (
  user_id UUID NOT NULL, profile_id UUID NOT NULL, fecha DATE NOT NULL,
  porcentaje SMALLINT NOT NULL CHECK(porcentaje BETWEEN 0 AND 100),
  PRIMARY KEY(profile_id,fecha),
  FOREIGN KEY(user_id,profile_id) REFERENCES mova_interno.perfiles(user_id,id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS mova_interno.operaciones (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  id UUID NOT NULL,
  payload JSONB NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(user_id,id)
);
CREATE TABLE IF NOT EXISTS mova_interno.autorreportes (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  profile_id UUID NOT NULL,
  emociones JSONB NOT NULL CHECK(jsonb_typeof(emociones)='array'),
  nota TEXT NOT NULL DEFAULT '' CHECK(length(nota)<=2000),
  etiquetas JSONB NOT NULL DEFAULT '[]' CHECK(jsonb_typeof(etiquetas)='array'),
  recorded_at TIMESTAMPTZ NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  FOREIGN KEY(user_id,profile_id) REFERENCES mova_interno.perfiles(user_id,id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS autorreportes_perfil_fecha ON mova_interno.autorreportes(profile_id,recorded_at DESC);
CREATE TABLE IF NOT EXISTS mova_interno.dispositivos (
  id TEXT PRIMARY KEY CHECK(length(trim(id)) BETWEEN 1 AND 160),
  user_id UUID NOT NULL,
  profile_id UUID NOT NULL,
  nombre TEXT NOT NULL CHECK(length(trim(nombre)) BETWEEN 1 AND 160),
  tipo TEXT NOT NULL CHECK(tipo IN ('simulator','hardware')),
  last_seen TIMESTAMPTZ,
  bateria SMALLINT CHECK(bateria BETWEEN 0 AND 100),
  bateria_at TIMESTAMPTZ,
  pasos INTEGER CHECK(pasos>=0),
  pasos_fecha DATE,
  pasos_at TIMESTAMPTZ,
  lat DOUBLE PRECISION CHECK(lat BETWEEN -90 AND 90),
  lng DOUBLE PRECISION CHECK(lng BETWEEN -180 AND 180),
  location_at TIMESTAMPTZ,
  FOREIGN KEY(user_id,profile_id) REFERENCES mova_interno.perfiles(user_id,id) ON DELETE CASCADE,
  UNIQUE(profile_id)
);
CREATE TABLE IF NOT EXISTS mova_interno.solicitudes_sos (
  id UUID PRIMARY KEY,
  user_id UUID NOT NULL,
  profile_id UUID NOT NULL,
  device_id TEXT NOT NULL REFERENCES mova_interno.dispositivos(id),
  recorded_at TIMESTAMPTZ NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  acknowledged_at TIMESTAMPTZ,
  FOREIGN KEY(user_id,profile_id) REFERENCES mova_interno.perfiles(user_id,id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS mova_interno.migraciones (
  nombre TEXT PRIMARY KEY, applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS mova_interno.sesiones_revocadas (
  token_hash TEXT PRIMARY KEY, expires_at TIMESTAMPTZ NOT NULL
);
CREATE TABLE IF NOT EXISTS mova_interno.recuperaciones (
  token_hash TEXT PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ
);
CREATE OR REPLACE FUNCTION mova_api.sp_cerrar_sesion(hash TEXT,vencimiento TIMESTAMPTZ) RETURNS VOID LANGUAGE SQL AS $$
  INSERT INTO mova_interno.sesiones_revocadas VALUES(hash,vencimiento) ON CONFLICT(token_hash) DO NOTHING;
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_sesion_valida(cuenta UUID,hash TEXT) RETURNS BOOLEAN LANGUAGE SQL STABLE AS $$
  SELECT EXISTS(SELECT 1 FROM users WHERE id=cuenta) AND NOT EXISTS(SELECT 1 FROM mova_interno.sesiones_revocadas WHERE token_hash=hash);
$$;
ALTER TABLE users ADD COLUMN IF NOT EXISTS session_version INTEGER NOT NULL DEFAULT 0;
CREATE OR REPLACE FUNCTION mova_api.sp_restaurar_acceso(hash_token TEXT,hash_password TEXT,sal TEXT) RETURNS BOOLEAN LANGUAGE plpgsql AS $$
DECLARE cuenta UUID;
BEGIN
  SELECT user_id INTO cuenta FROM mova_interno.recuperaciones WHERE token_hash=hash_token;
  IF NOT FOUND THEN RETURN FALSE; END IF;
  PERFORM id FROM users WHERE id=cuenta FOR UPDATE;
  PERFORM token_hash FROM mova_interno.recuperaciones WHERE token_hash=hash_token AND used_at IS NULL AND expires_at>now() FOR UPDATE;
  IF NOT FOUND THEN RETURN FALSE; END IF;
  UPDATE users SET password_hash=hash_password,password_salt=sal,session_version=session_version+1 WHERE id=cuenta;
  UPDATE mova_interno.recuperaciones SET used_at=now() WHERE user_id=cuenta AND used_at IS NULL;
  RETURN TRUE;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_solicitar_recuperacion(correo TEXT,hash_token TEXT) RETURNS BOOLEAN LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO mova_interno.recuperaciones(token_hash,user_id,expires_at)
    SELECT hash_token,id,now()+interval '30 minutes' FROM users WHERE email=lower(trim(correo));
  RETURN FOUND;
END $$;
DO $$
BEGIN
  IF NOT EXISTS(SELECT 1 FROM mova_interno.migraciones WHERE nombre='requirements_v1') THEN
    -- Los datos antiguos no tenían fecha de planificación: se conserva el último estado para hoy.
    INSERT INTO mova_interno.actividades(id,user_id,profile_id,nombre,fecha,hora,completada)
    SELECT a->>'id',r.user_id,r.user_id,a->>'label',
      (now() AT TIME ZONE 'America/Santiago')::date,(a->>'time')::time,(a->>'done')::boolean
    FROM (SELECT DISTINCT ON(user_id) user_id,activities FROM mova_interno.registros ORDER BY user_id,id DESC) r
    CROSS JOIN LATERAL jsonb_array_elements(r.activities) a ON CONFLICT DO NOTHING;
    INSERT INTO mova_interno.actividades(id,user_id,profile_id,nombre,fecha,hora)
    SELECT 'agenda-'||id,user_id,user_id,titulo,fecha,hora FROM mova_interno.eventos ON CONFLICT DO NOTHING;
    -- No se inventa una intensidad para emociones anteriores: se conserva el historial antiguo aparte.
    INSERT INTO mova_interno.migraciones(nombre) VALUES('requirements_v1');
  END IF;
END $$;

CREATE OR REPLACE FUNCTION mova_api.sp_validar_perfil(cuenta UUID,perfil UUID) RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  PERFORM id FROM mova_interno.perfiles WHERE id=perfil AND user_id=cuenta;
  IF NOT FOUND THEN RAISE EXCEPTION 'Perfil no disponible' USING ERRCODE='P0002'; END IF;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_perfiles(cuenta UUID) RETURNS JSONB LANGUAGE SQL STABLE AS $$
  SELECT coalesce(jsonb_agg(jsonb_build_object('id',id,'name',nombre,'age',edad::text,
    'photo',foto,'notifications',preferencias) ORDER BY created_at,id),'[]') FROM mova_interno.perfiles WHERE user_id=cuenta;
$$;
CREATE OR REPLACE FUNCTION mova_api.sp_guardar_perfil(cuenta UUID,perfil UUID,nombre TEXT,edad SMALLINT,foto TEXT,preferencias JSONB)
RETURNS JSONB LANGUAGE plpgsql AS $$
BEGIN
  IF EXISTS(SELECT 1 FROM mova_interno.perfiles WHERE id=perfil AND user_id<>cuenta) THEN
    RAISE EXCEPTION 'Perfil no disponible' USING ERRCODE='P0002'; END IF;
  IF preferencias IS NULL OR jsonb_typeof(preferencias)<>'object'
    OR jsonb_typeof(preferencias->'vibration') IS DISTINCT FROM 'boolean'
    OR jsonb_typeof(preferencias->'sound') IS DISTINCT FROM 'boolean'
    OR jsonb_typeof(preferencias->'lights') IS DISTINCT FROM 'boolean'
    OR jsonb_typeof(preferencias->'intensity') IS DISTINCT FROM 'number'
    OR (preferencias->>'intensity') !~ '^(10|[1-9])$' THEN
    RAISE EXCEPTION 'Preferencias inválidas' USING ERRCODE='22023'; END IF;
  INSERT INTO mova_interno.perfiles(id,user_id,nombre,edad,foto,preferencias)
    VALUES(perfil,cuenta,trim(nombre),edad,foto,preferencias)
    ON CONFLICT(id) DO UPDATE SET nombre=excluded.nombre,edad=excluded.edad,foto=excluded.foto,preferencias=excluded.preferencias
    WHERE mova_interno.perfiles.user_id=cuenta;
  IF NOT FOUND THEN RAISE EXCEPTION 'Perfil no disponible' USING ERRCODE='P0002'; END IF;
  RETURN mova_api.sp_perfiles(cuenta);
END $$;
-- Ledger atómico: un ID repetido no puede usarse para un cambio diferente.
CREATE OR REPLACE FUNCTION mova_api.sp_operacion(cuenta UUID,evento UUID,datos JSONB) RETURNS BOOLEAN LANGUAGE plpgsql AS $$
DECLARE anterior JSONB;
BEGIN
  PERFORM id FROM users WHERE id=cuenta FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Cuenta no disponible' USING ERRCODE='P0002'; END IF;
  SELECT payload INTO anterior FROM mova_interno.operaciones WHERE user_id=cuenta AND id=evento;
  IF FOUND THEN
    IF anterior IS DISTINCT FROM datos THEN RAISE EXCEPTION 'Identificador ya utilizado' USING ERRCODE='22023'; END IF;
    RETURN FALSE;
  END IF;
  INSERT INTO mova_interno.operaciones VALUES(cuenta,evento,datos,now());
  RETURN TRUE;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_actividades(cuenta UUID,perfil UUID,desde DATE,hasta DATE) RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE resultado JSONB;
BEGIN
  PERFORM mova_api.sp_validar_perfil(cuenta,perfil);
  SELECT coalesce(jsonb_agg(jsonb_build_object('id',id,'label',nombre,'date',fecha,
    'time',to_char(hora,'HH24:MI'),'duration',duracion,'done',completada,'updatedAt',updated_at)
    ORDER BY fecha,hora,id),'[]') INTO resultado FROM mova_interno.actividades
    WHERE user_id=cuenta AND profile_id=perfil AND NOT eliminada AND fecha BETWEEN desde AND hasta;
  RETURN resultado;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_cambiar_actividad(cuenta UUID,perfil UUID,evento UUID,cambio JSONB)
RETURNS BOOLEAN LANGUAGE plpgsql AS $$
DECLARE tipo TEXT:=cambio->>'type'; actividad_id TEXT:=cambio->>'taskId'; dia DATE; dia_anterior DATE; porcentaje SMALLINT; anterior SMALLINT;
BEGIN
  PERFORM mova_api.sp_validar_perfil(cuenta,perfil);
  IF NOT mova_api.sp_operacion(cuenta,evento,jsonb_build_object('profileId',perfil,'kind','activity','change',cambio)) THEN RETURN FALSE; END IF;
  SELECT fecha INTO dia_anterior FROM mova_interno.actividades WHERE profile_id=perfil AND id=actividad_id;
  IF tipo IN ('add_task','edit_task') THEN
    dia:=(cambio->>'date')::date;
    IF dia IS NULL OR cambio->>'time' IS NULL OR (cambio->>'time') !~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'
      OR cambio->>'label' IS NULL OR actividad_id IS NULL THEN RAISE EXCEPTION 'Actividad inválida' USING ERRCODE='22023'; END IF;
    IF tipo='add_task' THEN
      IF (SELECT count(*) FROM mova_interno.actividades WHERE profile_id=perfil AND fecha=dia AND NOT eliminada)>=100 THEN
        RAISE EXCEPTION 'Máximo 100 actividades por día' USING ERRCODE='22023'; END IF;
      INSERT INTO mova_interno.actividades(id,user_id,profile_id,nombre,fecha,hora,duracion)
        VALUES(actividad_id,cuenta,perfil,trim(cambio->>'label'),dia,(cambio->>'time')::time,(cambio->>'duration')::smallint);
    ELSE
      IF dia IS DISTINCT FROM dia_anterior AND (SELECT count(*) FROM mova_interno.actividades WHERE profile_id=perfil AND fecha=dia AND NOT eliminada)>=100 THEN
        RAISE EXCEPTION 'Máximo 100 actividades por día' USING ERRCODE='22023'; END IF;
      UPDATE mova_interno.actividades SET nombre=trim(cambio->>'label'),fecha=dia,hora=(cambio->>'time')::time,
        duracion=(cambio->>'duration')::smallint,updated_at=now()
        WHERE profile_id=perfil AND id=actividad_id AND NOT eliminada;
      IF NOT FOUND THEN RAISE EXCEPTION 'Actividad no disponible' USING ERRCODE='P0002'; END IF;
    END IF;
  ELSIF tipo='set_done' THEN
    IF jsonb_typeof(cambio->'done') IS DISTINCT FROM 'boolean' THEN RAISE EXCEPTION 'Estado inválido' USING ERRCODE='22023'; END IF;
    UPDATE mova_interno.actividades SET completada=(cambio->>'done')::boolean,updated_at=now()
      WHERE profile_id=perfil AND id=actividad_id AND NOT eliminada;
    IF NOT FOUND THEN RAISE EXCEPTION 'Actividad no disponible' USING ERRCODE='P0002'; END IF;
  ELSIF tipo='remove_task' THEN
    UPDATE mova_interno.actividades SET eliminada=TRUE,updated_at=now() WHERE profile_id=perfil AND id=actividad_id AND NOT eliminada;
    IF NOT FOUND THEN RAISE EXCEPTION 'Actividad no disponible' USING ERRCODE='P0002'; END IF;
  ELSE RAISE EXCEPTION 'Cambio inválido' USING ERRCODE='22023'; END IF;
  FOR dia IN SELECT DISTINCT d FROM unnest(ARRAY[dia,dia_anterior]) d WHERE d IS NOT NULL LOOP
    SELECT coalesce(round(100.0*count(*) FILTER(WHERE completada)/nullif(count(*),0)),0) INTO porcentaje
      FROM mova_interno.actividades WHERE profile_id=perfil AND fecha=dia AND NOT eliminada;
    SELECT p.porcentaje INTO anterior FROM mova_interno.progreso_diario p WHERE profile_id=perfil AND fecha=dia;
    INSERT INTO mova_interno.progreso_diario VALUES(cuenta,perfil,dia,porcentaje)
      ON CONFLICT(profile_id,fecha) DO UPDATE SET porcentaje=excluded.porcentaje;
  END LOOP;
  RETURN TRUE;
END $$;

CREATE OR REPLACE FUNCTION mova_api.sp_autorreporte(cuenta UUID,perfil UUID,evento UUID,seleccion JSONB,
  nota TEXT,etiquetas JSONB,fecha TIMESTAMPTZ) RETURNS BOOLEAN LANGUAGE plpgsql AS $$
BEGIN
  PERFORM mova_api.sp_validar_perfil(cuenta,perfil);
  IF seleccion IS NULL OR jsonb_typeof(seleccion)<>'array' THEN RAISE EXCEPTION 'Selecciona emociones' USING ERRCODE='22023'; END IF;
  IF jsonb_array_length(seleccion) NOT BETWEEN 1 AND 6 OR EXISTS(SELECT 1 FROM jsonb_array_elements(seleccion) e
    WHERE jsonb_typeof(e)<>'object' OR e->>'label' IS NULL
      OR e->>'label' NOT IN ('Feliz','Contento','Neutral','Cansado','Triste','Enojado')
      OR jsonb_typeof(e->'intensity') IS DISTINCT FROM 'number'
      OR (e->>'intensity') !~ '^(100|[0-9]{1,2})$')
    OR (SELECT count(*)<>count(DISTINCT e->>'label') FROM jsonb_array_elements(seleccion) e)
    OR fecha IS NULL OR fecha>now()+interval '5 minutes' THEN
    RAISE EXCEPTION 'Emociones o fecha inválidas' USING ERRCODE='22023'; END IF;
  IF NOT mova_api.sp_operacion(cuenta,evento,jsonb_build_object('profileId',perfil,'kind','emotion',
    'emotions',seleccion,'note',nota,'tags',etiquetas,'recordedAt',fecha)) THEN RETURN FALSE; END IF;
  INSERT INTO mova_interno.autorreportes(id,user_id,profile_id,emociones,nota,etiquetas,recorded_at)
    VALUES(evento,cuenta,perfil,seleccion,nota,etiquetas,fecha);
  RETURN TRUE;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_historial_emocional(cuenta UUID,perfil UUID,desde DATE,hasta DATE)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE resultado JSONB;
BEGIN
  PERFORM mova_api.sp_validar_perfil(cuenta,perfil);
  SELECT coalesce(jsonb_agg(jsonb_build_object('id',id,'emotions',emociones,'note',nota,'tags',etiquetas,
    'recordedAt',recorded_at,'receivedAt',received_at) ORDER BY recorded_at DESC,id),'[]') INTO resultado
    FROM mova_interno.autorreportes WHERE user_id=cuenta AND profile_id=perfil
    AND (recorded_at AT TIME ZONE 'America/Santiago')::date BETWEEN desde AND hasta;
  RETURN resultado;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_resumen_emocional(cuenta UUID,perfil UUID,desde DATE,hasta DATE)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE resultado JSONB;
BEGIN
  PERFORM mova_api.sp_validar_perfil(cuenta,perfil);
  SELECT coalesce(jsonb_agg(to_jsonb(d) ORDER BY d.date),'[]') INTO resultado FROM (
    SELECT (r.recorded_at AT TIME ZONE 'America/Santiago')::date AS date,
      round(avg((e->>'intensity')::numeric))::int AS intensity,
      count(DISTINCT r.id)::int AS count
    FROM mova_interno.autorreportes r CROSS JOIN LATERAL jsonb_array_elements(r.emociones) e
    WHERE user_id=cuenta AND profile_id=perfil AND (r.recorded_at AT TIME ZONE 'America/Santiago')::date BETWEEN desde AND hasta
    GROUP BY (r.recorded_at AT TIME ZONE 'America/Santiago')::date) d;
  RETURN resultado;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_vincular_dispositivo(cuenta UUID,perfil UUID,dispositivo TEXT,nombre TEXT,tipo TEXT)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  PERFORM mova_api.sp_validar_perfil(cuenta,perfil);
  PERFORM id FROM users WHERE id=cuenta FOR UPDATE;
  IF EXISTS(SELECT 1 FROM mova_interno.dispositivos WHERE id=dispositivo AND (user_id<>cuenta OR profile_id<>perfil)) THEN
    RAISE EXCEPTION 'Dispositivo ya vinculado a otro perfil' USING ERRCODE='22023'; END IF;
  INSERT INTO mova_interno.dispositivos(id,user_id,profile_id,nombre,tipo) VALUES(dispositivo,cuenta,perfil,trim(nombre),tipo)
    ON CONFLICT(id) DO UPDATE SET nombre=excluded.nombre WHERE mova_interno.dispositivos.user_id=cuenta AND mova_interno.dispositivos.profile_id=perfil;
  IF NOT FOUND THEN RAISE EXCEPTION 'Dispositivo no disponible' USING ERRCODE='P0002'; END IF;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_estado_dispositivo(cuenta UUID,perfil UUID) RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE resultado JSONB;
BEGIN
  PERFORM mova_api.sp_validar_perfil(cuenta,perfil);
  SELECT to_jsonb(d) INTO resultado FROM mova_interno.dispositivos d WHERE user_id=cuenta AND profile_id=perfil;
  RETURN resultado;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_heartbeat(cuenta UUID,perfil UUID,dispositivo TEXT) RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  UPDATE mova_interno.dispositivos SET last_seen=now() WHERE user_id=cuenta AND profile_id=perfil AND id=dispositivo;
  IF NOT FOUND THEN RAISE EXCEPTION 'Vincula el dispositivo a este perfil' USING ERRCODE='P0002'; END IF;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_telemetria(cuenta UUID,perfil UUID,dispositivo TEXT,datos JSONB,fecha TIMESTAMPTZ)
RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  IF fecha IS NULL OR fecha>now()+interval '5 minutes' THEN RAISE EXCEPTION 'Hora inválida' USING ERRCODE='22023'; END IF;
  UPDATE mova_interno.dispositivos SET last_seen=now(),
    bateria=CASE WHEN datos ? 'battery' AND (bateria_at IS NULL OR fecha>=bateria_at) THEN (datos->>'battery')::smallint ELSE bateria END,
    bateria_at=CASE WHEN datos ? 'battery' AND (bateria_at IS NULL OR fecha>=bateria_at) THEN fecha ELSE bateria_at END,
    pasos=CASE WHEN datos ? 'steps' AND (pasos_at IS NULL OR fecha>=pasos_at) THEN (datos->>'steps')::integer ELSE pasos END,
    pasos_fecha=CASE WHEN datos ? 'steps' AND (pasos_at IS NULL OR fecha>=pasos_at) THEN (datos->>'stepsDate')::date ELSE pasos_fecha END,
    pasos_at=CASE WHEN datos ? 'steps' AND (pasos_at IS NULL OR fecha>=pasos_at) THEN fecha ELSE pasos_at END,
    lat=CASE WHEN datos ? 'latitude' AND (location_at IS NULL OR fecha>=location_at) THEN (datos->>'latitude')::double precision ELSE lat END,
    lng=CASE WHEN datos ? 'latitude' AND (location_at IS NULL OR fecha>=location_at) THEN (datos->>'longitude')::double precision ELSE lng END,
    location_at=CASE WHEN datos ? 'latitude' AND (location_at IS NULL OR fecha>=location_at) THEN fecha ELSE location_at END
    WHERE user_id=cuenta AND profile_id=perfil AND id=dispositivo AND tipo='hardware';
  IF NOT FOUND THEN RAISE EXCEPTION 'Hardware no vinculado' USING ERRCODE='P0002'; END IF;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_sos(cuenta UUID,perfil UUID,evento UUID,dispositivo TEXT,fecha TIMESTAMPTZ)
RETURNS BOOLEAN LANGUAGE plpgsql AS $$
BEGIN
  PERFORM mova_api.sp_validar_perfil(cuenta,perfil);
  IF NOT EXISTS(SELECT 1 FROM mova_interno.dispositivos WHERE id=dispositivo AND user_id=cuenta AND profile_id=perfil)
    OR fecha IS NULL OR fecha>now()+interval '5 minutes' THEN
    RAISE EXCEPTION 'Dispositivo o fecha inválidos' USING ERRCODE='22023'; END IF;
  IF NOT mova_api.sp_operacion(cuenta,evento,jsonb_build_object('profileId',perfil,'kind','sos','deviceId',dispositivo,'recordedAt',fecha)) THEN RETURN FALSE; END IF;
  INSERT INTO mova_interno.solicitudes_sos(id,user_id,profile_id,device_id,recorded_at) VALUES(evento,cuenta,perfil,dispositivo,fecha);
  RETURN TRUE;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_alertas(cuenta UUID,perfil UUID) RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE resultado JSONB;
BEGIN
  PERFORM mova_api.sp_validar_perfil(cuenta,perfil);
  SELECT coalesce(jsonb_agg(to_jsonb(s) ORDER BY s.received_at DESC),'[]') INTO resultado
    FROM (SELECT * FROM mova_interno.solicitudes_sos WHERE user_id=cuenta AND profile_id=perfil ORDER BY received_at DESC LIMIT 100) s;
  RETURN resultado;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_confirmar_sos(cuenta UUID,perfil UUID,evento UUID) RETURNS VOID LANGUAGE plpgsql AS $$
BEGIN
  UPDATE mova_interno.solicitudes_sos SET acknowledged_at=coalesce(acknowledged_at,now()) WHERE id=evento AND user_id=cuenta AND profile_id=perfil;
  IF NOT FOUND THEN RAISE EXCEPTION 'Solicitud no disponible' USING ERRCODE='P0002'; END IF;
END $$;
CREATE OR REPLACE FUNCTION mova_api.sp_panel(cuenta UUID,perfil UUID,dia DATE) RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE lista JSONB; animo JSONB;
BEGIN
  lista:=mova_api.sp_actividades(cuenta,perfil,dia,dia);
  SELECT jsonb_build_object('emotions',emociones,'recordedAt',recorded_at) INTO animo
    FROM mova_interno.autorreportes WHERE user_id=cuenta AND profile_id=perfil ORDER BY recorded_at DESC,id DESC LIMIT 1;
  RETURN jsonb_build_object('activities',lista,'emotion',animo->'emotions'->0->>'label','emotionalReport',animo,
    'progressPercent',(SELECT coalesce(round(100.0*count(*) FILTER(WHERE (a->>'done')::boolean)/nullif(count(*),0)),0)
      FROM jsonb_array_elements(lista) a),'device',mova_api.sp_estado_dispositivo(cuenta,perfil),
    'alerts',mova_api.sp_alertas(cuenta,perfil),'date',dia,'serverTime',now());
END $$;
-- Registro crea cuenta y perfil en una sola transacción.
CREATE OR REPLACE FUNCTION mova_api.sp_registro(adulto TEXT,nombre TEXT,edad SMALLINT,
  telefono TEXT,correo TEXT,diagnostico TEXT,hash TEXT,sal TEXT)
RETURNS SETOF users LANGUAGE plpgsql AS $$
DECLARE nuevo users%ROWTYPE;
BEGIN
  INSERT INTO users(adult_name,user_name,age,phone,email,diagnosis,password_hash,password_salt)
    VALUES(trim(adulto),trim(nombre),edad,trim(telefono),lower(trim(correo)),diagnostico,hash,sal) RETURNING * INTO nuevo;
  INSERT INTO mova_interno.perfiles(id,user_id,nombre,edad) VALUES(nuevo.id,nuevo.id,nuevo.user_name,nuevo.age);
  RETURN NEXT nuevo;
END $$;
COMMIT;
