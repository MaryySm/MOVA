# Contrato compartido v2 (app y wearable)

Las vistas públicas `tareas`, `emociones` y `progreso` muestran `user_id` (cuenta del adulto), `profile_id` (niño), `adulto`, `email` y `usuario` (nombre actual). Consultarlas desde pgAdmin permite distinguir cada dato sin duplicar nombres en las tablas fuente. Las escrituras se realizan mediante los SP autenticados; las vistas son de consulta. Ejemplo: `SELECT * FROM public.emociones WHERE profile_id = 'UUID_DEL_NIÑO' ORDER BY fecha DESC;`.

Las antiguas tablas visibles sin identificadores se conservan en `mova_interno.*_legacy_sin_propietario` cuando existen. No es posible recuperar su dueño con certeza a partir del nombre de una tarea o de un porcentaje. El historial original con dueño sigue disponible en `public.registros_wearable`. Las tablas técnicas de migración no son datos personales.

La implementación nueva usa requirements.sql y /api/v2/profiles/:profileId. Inicio, agenda, rutinas y plan semanal consultan mova_interno.actividades; no mantienen listas independientes. Los perfiles son entidades separadas con propietario, y cada operación verifica acceso.

| Operación | Función almacenada |
| --- | --- |
| Perfiles | sp_perfiles / sp_guardar_perfil |
| Panel y actividades | sp_panel / sp_actividades / sp_cambiar_actividad |
| Emociones | sp_autorreporte / sp_historial_emocional / sp_resumen_emocional |
| Dispositivo | sp_vincular_dispositivo / sp_estado_dispositivo / sp_heartbeat / sp_telemetria |
| SOS | sp_sos / sp_alertas / sp_confirmar_sos |
| Sesión y recuperación | sp_cerrar_sesion / sp_sesion_valida / sp_solicitar_recuperacion / sp_restaurar_acceso |

Son funciones PostgreSQL llamadas con SELECT. La lógica común se organiza por operación de negocio para reutilizarla entre pantallas y dispositivos. sp_operacion evita duplicados por UUID y rechaza cambiar el contenido de un mismo reintento. La migración preserva tareas/eventos existentes una vez; los registros emocionales antiguos no reciben intensidades inventadas. El código legado v1 se conserva para compatibilidad, pero no representa el contrato nuevo. Sus perfiles de preferencias no se convierten automáticamente en perfiles reales: revisar esos datos antes de migrarlos manualmente.

Ver ../../docs/REQUERIMIENTOS.md para alcance, pruebas y pendientes.

## Referencia heredada v1

# Lógica almacenada por pantalla

PostgreSQL utiliza funciones `mova_api.sp_*` invocadas con `SELECT`, que devuelven filas o JSON a la API. Los procedimientos con `CALL` no ofrecen el mismo contrato de retorno; aquí los SP son funciones almacenadas.

| Pantalla / operación | Endpoint | SP |
| --- | --- | --- |
| Registro | POST `/api/auth/register` | `sp_registro` |
| Login | POST `/api/auth/login` | `sp_login` |
| Perfil de cuenta | GET `/api/auth/me` | `sp_perfil` |
| Inicio | GET `/api/screens/home` | `sp_inicio` |
| Rutina | GET `/api/screens/routine` | `sp_rutina` |
| Agregar/completar/quitar tarea; emoción | POST `/api/activities/actions` | `sp_accion_rutina` |
| Calendario y plan semanal | GET `/api/screens/calendar?from=2026-10-01&to=2026-10-31` | `sp_calendario` |
| Crear/editar evento | POST `/api/screens/calendar` | `sp_guardar_evento` |
| Eliminar evento | POST `/api/screens/calendar/remove` | `sp_eliminar_evento` |
| Historial emocional | GET `/api/screens/emotions` | `sp_emociones` |
| Guardar emoción, nota y etiquetas | POST `/api/screens/emotions` | `sp_guardar_emocion` |
| Configuración | GET / POST `/api/screens/settings` | `sp_configuracion` / `sp_guardar_configuracion` |
| Sincronizar BLE | POST `/api/sync` | `sp_guardar_sync` |
| Consultar dispositivo | GET `/api/sync` | `sp_dispositivo` |
| Guardar estado del wearable | POST `/api/wearable/records` | `sp_guardar_registro` |
| Historial del wearable | GET `/api/wearable/records` | `sp_historial` |
| Cola de versiones anteriores | POST `/api/sync/legacy` | `sp_accion_rutina`, modo legacy |

## Relaciones

`users.id` identifica la cuenta. La API obtiene el identificador del token, nunca del cuerpo HTTP. Todas las nuevas rutas requieren `Authorization: Bearer <token>`.

Inicio, Rutina y el wearable comparten `mova_interno.registros`. `sp_guardar_registro` normaliza nombres, calcula progreso desde las tareas y conserva el historial. `sp_accion_rutina` bloquea la cuenta mientras combina cada acción con el estado anterior. Las acciones simultáneas se conservan y los UUID evitan repetir cambios recibidos.

Emociones utiliza ese mismo estado. Las notas y etiquetas se relacionan con `(user_id,event_id)` en `mova_interno.notas_emocion`. Guardar una emoción conserva las tareas y actualiza la emoción visible en Inicio y el wearable.

Planificación semanal y Calendario comparten `mova_interno.eventos`: crear una actividad en una fecha permite verla en Calendario. Un evento de agenda no cambia automáticamente una tarea del wearable; esas tareas se administran desde Rutina o Plan de actividades.

Configuración guarda perfiles y preferencias en `mova_interno.configuracion`. Los perfiles adicionales son datos de presentación de la cuenta; no separan historiales de niños. Las actividades/emociones pertenecen a `users.id`. Web usa `profiles` y `activeId`; Flutter usa `flutterProfiles` y `flutterActiveId`; ambos comparten `language`. Las escrituras combinan claves superiores para conservar otras preferencias. Editar estos perfiles no modifica el correo ni la contraseña de login.

Las tablas públicas simples `tareas`, `emociones` y `progreso` conservan el formato anterior. Son resúmenes globales de historial; las pantallas consultan las rutinas filtradas por cuenta.

La API conserva validación HTTP, hash de contraseñas, comparación segura y firma de sesiones. La contraseña original nunca llega a los SP. `sp_login` devuelve el hash únicamente al servidor para comprobar la contraseña.

## Ejemplos de cuerpos HTTP

POST `/api/screens/calendar`:

```json
{"id":"a2113d1a-0e31-46ee-82b0-f2326f422512","title":"Ir al colegio","date":"2026-10-12","time":"08:00"}
```

POST `/api/screens/emotions`:

```json
{"eventId":"a2113d1a-0e31-46ee-82b0-f2326f422513","emotion":"Feliz","note":"Jugué con mis amigos","tags":["Calmado"]}
```

En pgAdmin, reemplaza el UUID por una cuenta real:

```sql
SELECT mova_api.sp_inicio('00000000-0000-0000-0000-000000000001'::uuid);
SELECT mova_api.sp_rutina('00000000-0000-0000-0000-000000000001'::uuid);
SELECT routine_name FROM information_schema.routines
WHERE routine_schema = 'mova_api' ORDER BY routine_name;
```

## Instalación y pruebas

La API instala `screens.sql` después del esquema base y `wearable.sql`. Se puede aplicar de nuevo sin eliminar los datos existentes. `init.sql` también lo incluye para bases nuevas.

Desde `backend`:

```powershell
docker compose up --build -d api
docker compose exec -T api npm test
docker compose exec -T api node src/wearable-integration.mjs
docker compose exec -T app npx tsc --noEmit
docker compose exec -T app npm run build
```

La integración crea una base temporal y la elimina al terminar. Comprueba migración, reintentos, concurrencia, separación de cuentas, relaciones entre pantallas y endpoints HTTP. Requiere permiso local para crear bases. No agrega registros de prueba a MOVA.

Flutter requiere su SDK para `flutter analyze` y `flutter test`; no está incluido en los contenedores Node. Calendario consulta una fecha elegida y permite agregar actividades para esa fecha. Rutina recupera actividades compartidas del servidor sin tareas de ejemplo. Las nuevas escrituras de calendario/configuración requieren conexión. La cola existente de tareas del wearable conserva su funcionamiento sin conexión.
