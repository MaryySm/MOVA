﻿BEGIN;

-- Los detalles de sincronización quedan fuera de las tres tablas visibles.
CREATE SCHEMA IF NOT EXISTS mova_interno;
CREATE TABLE IF NOT EXISTS mova_interno.registros (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  event_id UUID NOT NULL,
  device_id TEXT NOT NULL,
  activities JSONB NOT NULL CHECK (jsonb_typeof(activities) = 'array'),
  emotion TEXT,
  progress_percent SMALLINT NOT NULL CHECK (progress_percent BETWEEN 0 AND 100),
  recorded_at TIMESTAMPTZ NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (user_id,event_id)
);
CREATE INDEX IF NOT EXISTS registros_user_date_idx
  ON mova_interno.registros(user_id,recorded_at DESC,id DESC);

CREATE OR REPLACE FUNCTION mova_interno.nombre_tarea(nombre TEXT) RETURNS TEXT
LANGUAGE SQL IMMUTABLE AS $$
  SELECT CASE lower(trim(nombre))
    WHEN 'levantarme' THEN 'Levantarse'
    WHEN 'bañarme' THEN 'Bañarse'
    WHEN 'dientes' THEN 'Lavarse los dientes'
    WHEN 'desayuno' THEN 'Desayunar'
    WHEN 'al colegio' THEN 'Ir al colegio'
    WHEN 'fútbol' THEN 'Jugar fútbol'
    ELSE trim(nombre) END;
$$;
CREATE OR REPLACE FUNCTION mova_interno.nombre_emocion(nombre TEXT) RETURNS TEXT
LANGUAGE SQL IMMUTABLE AS $$
  SELECT CASE lower(trim(nombre))
    WHEN '¡genial!' THEN 'Feliz'
    WHEN 'bien' THEN 'Contento'
    WHEN 'normal' THEN 'Neutral'
    ELSE trim(nombre) END;
$$;

CREATE OR REPLACE FUNCTION mova_interno.nombres_tareas(lista JSONB) RETURNS JSONB
LANGUAGE SQL IMMUTABLE AS $$
  SELECT COALESCE(jsonb_agg(a.value || jsonb_build_object('label',
    mova_interno.nombre_tarea(a.value->>'label')) ORDER BY a.ordinality), '[]'::jsonb)
  FROM jsonb_array_elements(lista) WITH ORDINALITY a;
$$;

DO $$
DECLARE migrar BOOLEAN := FALSE;
BEGIN
  IF EXISTS (SELECT 1 FROM information_schema.columns
    WHERE table_schema=current_schema() AND table_name='progreso' AND column_name='event_id') THEN
    INSERT INTO mova_interno.registros(user_id,event_id,device_id,activities,emotion,progress_percent,recorded_at,received_at)
    SELECT p.user_id,p.event_id,p.device_id,
      COALESCE((SELECT jsonb_agg(jsonb_build_object('id',t.activity_id,
        'label',mova_interno.nombre_tarea(t.label),'time',to_char(t.scheduled_time,'HH24:MI'),
        'done',t.completed) ORDER BY t.position)
        FROM tareas t WHERE t.user_id=p.user_id AND t.event_id=p.event_id),'[]'::jsonb),
      mova_interno.nombre_emocion(e.emotion),p.progress_percent,p.recorded_at,p.received_at
    FROM progreso p LEFT JOIN emociones e USING(user_id,event_id)
    ON CONFLICT(user_id,event_id) DO NOTHING;
    DROP TABLE tareas;
    DROP TABLE emociones;
    DROP TABLE progreso;
    migrar := TRUE;
  END IF;

  IF to_regclass('wearable_records') IS NOT NULL THEN
    INSERT INTO mova_interno.registros(user_id,event_id,device_id,activities,emotion,progress_percent,recorded_at,received_at)
    SELECT user_id,event_id,device_id,mova_interno.nombres_tareas(activities),
      mova_interno.nombre_emocion(emotion),progress_percent,recorded_at,received_at
    FROM wearable_records ON CONFLICT(user_id,event_id) DO NOTHING;
    DROP TABLE wearable_records;
    migrar := TRUE;
  END IF;

END $$;

COMMIT;
