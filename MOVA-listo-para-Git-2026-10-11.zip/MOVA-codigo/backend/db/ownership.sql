BEGIN;
-- Conserva las antiguas listas sin propietario; nunca atribuye esos datos a una persona.
DO $$
DECLARE tabla TEXT;
BEGIN
  FOREACH tabla IN ARRAY ARRAY['tareas','emociones','progreso'] LOOP
    IF EXISTS(SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace
      WHERE n.nspname='public' AND c.relname=tabla AND c.relkind='r') THEN
      EXECUTE format('ALTER TABLE public.%I SET SCHEMA mova_interno',tabla);
      EXECUTE format('ALTER TABLE mova_interno.%I RENAME TO %I',tabla,tabla||'_legacy_sin_propietario');
    END IF;
  END LOOP;
END $$;
-- Vistas de consulta: IDs estables, nombres actuales y fecha. Las escrituras van por SP.
CREATE OR REPLACE VIEW public.tareas AS
SELECT a.user_id,a.profile_id,u.adult_name AS adulto,u.email,p.nombre AS usuario,
  a.id AS actividad_id,a.nombre AS tarea,a.fecha,a.hora,a.duracion,a.completada,a.eliminada
FROM mova_interno.actividades a JOIN users u ON u.id=a.user_id
JOIN mova_interno.perfiles p ON p.id=a.profile_id AND p.user_id=a.user_id;
CREATE OR REPLACE VIEW public.emociones AS
SELECT r.user_id,r.profile_id,u.adult_name AS adulto,u.email,p.nombre AS usuario,
  r.id AS registro_id,e.value->>'label' AS emocion,(e.value->>'intensity')::integer AS intensidad,
  r.nota,r.recorded_at AS fecha
FROM mova_interno.autorreportes r JOIN users u ON u.id=r.user_id
JOIN mova_interno.perfiles p ON p.id=r.profile_id AND p.user_id=r.user_id
CROSS JOIN LATERAL jsonb_array_elements(r.emociones) e;
CREATE OR REPLACE VIEW public.progreso AS
SELECT r.user_id,r.profile_id,u.adult_name AS adulto,u.email,p.nombre AS usuario,r.fecha,r.porcentaje
FROM mova_interno.progreso_diario r JOIN users u ON u.id=r.user_id
JOIN mova_interno.perfiles p ON p.id=r.profile_id AND p.user_id=r.user_id;
CREATE OR REPLACE VIEW public.registros_wearable AS
SELECT r.id,r.user_id,u.adult_name AS adulto,u.user_name AS usuario,u.email,
  r.device_id,r.activities,r.emotion,r.progress_percent,r.recorded_at,r.received_at
FROM mova_interno.registros r JOIN users u ON u.id=r.user_id;
COMMIT;
