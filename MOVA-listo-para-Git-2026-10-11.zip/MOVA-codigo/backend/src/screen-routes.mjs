import crypto from 'node:crypto';

const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const date = /^\d{4}-\d{2}-\d{2}$/;
export function installScreenRoutes(app, pool, requireAuth) {
  const run = (handler) => async (req, res) => {
    try { await handler(req, res); }
    catch (error) {
      if (['22023', '22007', '22008', '23514', '22P02'].includes(error.code))
        return res.status(400).json({ error: 'Revisa los datos enviados.' });
      if (['23503','P0002'].includes(error.code)) return res.status(401).json({ error: 'Cuenta no disponible.' });
      console.error('Error de pantalla:', error);
      res.status(503).json({ error: 'No se pudo acceder a la base de datos.' });
    }
  };
  for (const [path, routine] of [['home','sp_inicio'],['routine','sp_rutina'],
    ['emotions','sp_emociones'],['settings','sp_configuracion']]) {
    app.get(`/api/screens/${path}`, requireAuth, run(async (req,res) => {
      const result = await pool.query(`SELECT mova_api.${routine}($1) AS data`, [req.auth.sub]);
      res.json(result.rows[0].data);
    }));
  }
  app.post('/api/screens/settings', requireAuth, run(async (req,res) => {
    const value = req.body;
    if (!value || typeof value !== 'object' || Array.isArray(value))
      return res.status(400).json({ error: 'Configuración inválida.' });
    const result = await pool.query('SELECT mova_api.sp_guardar_configuracion($1,$2::jsonb) AS data',
      [req.auth.sub,JSON.stringify(value)]);
    res.json(result.rows[0].data);
  }));
  app.post('/api/screens/calendar/remove', requireAuth, run(async (req,res) => {
    if (!uuid.test(req.body?.id ?? '')) return res.status(400).json({ error: 'Evento inválido.' });
    await pool.query('SELECT mova_api.sp_eliminar_evento($1,$2)', [req.auth.sub,req.body.id]);
    res.json({ removed: true });
  }));
  app.get('/api/screens/calendar', requireAuth, run(async (req,res) => {
    const { from, to } = req.query;
    if (!date.test(from ?? '') || !date.test(to ?? '') || from > to)
      return res.status(400).json({ error: 'Indica from y to con formato AAAA-MM-DD.' });
    const result = await pool.query('SELECT mova_api.sp_calendario($1,$2::date,$3::date) AS data', [req.auth.sub,from,to]);
    res.json(result.rows[0].data);
  }));
  app.post('/api/screens/calendar', requireAuth, run(async (req,res) => {
    const { id = crypto.randomUUID(), title, date: day, time } = req.body ?? {};
    if (!uuid.test(id) || typeof title !== 'string' || !title.trim() || title.length>200 ||
      !date.test(day ?? '') || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time ?? ''))
      return res.status(400).json({ error: 'Evento inválido.' });
    const result = await pool.query('SELECT mova_api.sp_guardar_evento($1,$2,$3,$4::date,$5::time) AS id',
      [req.auth.sub,id,title.trim(),day,time]);
    res.status(201).json(result.rows[0]);
  }));
  app.post('/api/screens/emotions', requireAuth, run(async (req,res) => {
    const { eventId, emotion, note = '', tags = [] } = req.body ?? {};
    if (!uuid.test(eventId ?? '') || typeof emotion !== 'string' || !emotion.trim() || emotion.length>80 ||
      typeof note !== 'string' || note.length>2000 || !Array.isArray(tags) || tags.length>20 ||
      tags.some(tag => typeof tag !== 'string' || tag.length>80))
      return res.status(400).json({ error: 'Registro emocional inválido.' });
    const result = await pool.query('SELECT mova_api.sp_guardar_emocion($1,$2,$3,$4,$5::jsonb) AS saved',
      [req.auth.sub,eventId,emotion.trim(),note,JSON.stringify(tags)]);
    res.status(result.rows[0].saved ? 201 : 200).json({ saved: true,eventId });
  }));
}
