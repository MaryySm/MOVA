import crypto from 'node:crypto';
import { promisify } from 'node:util';
const scrypt=promisify(crypto.scrypt);
const hash=value=>crypto.createHash('sha256').update(value).digest('hex');

export function installRecoveryRoutes(app,pool,limitAuthAttempts,requireAuth) {
  app.post('/api/auth/logout',requireAuth,async(req,res)=>{
    try{await pool.query('SELECT mova_api.sp_cerrar_sesion($1,$2::timestamptz)',[req.tokenHash,new Date(req.auth.exp*1000).toISOString()]);res.json({loggedOut:true})}
    catch{res.status(503).json({error:'No se pudo cerrar la sesión en el servidor. Reintenta.'})}
  });
  app.post('/api/auth/recovery/request',limitAuthAttempts,async(req,res)=>{
    const email=typeof req.body?.email==='string'?req.body.email.trim().toLowerCase():'';
    if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254)return res.status(400).json({error:'Ingresa un correo válido.'});
    const relay=process.env.PASSWORD_RESET_WEBHOOK,secret=process.env.PASSWORD_RESET_WEBHOOK_SECRET,site=process.env.PASSWORD_RESET_APP_URL;
    if(!relay||!secret||!site)return res.status(503).json({error:'La recuperación por correo todavía no está configurada. El administrador debe habilitar el servicio de correo.'});
    const token=crypto.randomBytes(32).toString('base64url'),tokenHash=hash(token);
    try {
      const url=new URL(site);url.searchParams.set('resetToken',token);
      const result=await pool.query('SELECT mova_api.sp_solicitar_recuperacion($1,$2) AS created',[email,tokenHash]);
      if(result.rows[0].created){
        const delivery=await fetch(relay,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${secret}`},
          body:JSON.stringify({to:email,template:'mova-password-reset',resetUrl:url.toString(),expiresInMinutes:30}),signal:AbortSignal.timeout(10000)});
        if(!delivery.ok)throw new Error('No se pudo entregar al servicio de correo');
      }
      res.json({message:'Solicitud procesada. Si el correo corresponde a una cuenta, recibirás un enlace de recuperación.'});
    }catch{
      await pool.query('DELETE FROM mova_interno.recuperaciones WHERE token_hash=$1',[tokenHash]).catch(()=>{});
      res.status(503).json({error:'No se pudo procesar la recuperación. Puedes reintentar.'});
    }
  });
  app.post('/api/auth/recovery/reset',limitAuthAttempts,async(req,res)=>{
    const {token,password}=req.body??{};
    if(typeof token!=='string'||!/^[A-Za-z0-9_-]{43}$/.test(token)||typeof password!=='string'||password.length<8||password.length>128)
      return res.status(400).json({error:'Usa un enlace válido y una contraseña de 8 a 128 caracteres.'});
    try{
      const salt=crypto.randomBytes(16),passwordHash=await scrypt(password,salt,64);
      const result=await pool.query('SELECT mova_api.sp_restaurar_acceso($1,$2,$3) AS saved',[hash(token),passwordHash.toString('hex'),salt.toString('hex')]);
      if(!result.rows[0].saved)return res.status(400).json({error:'El enlace venció o ya se utilizó. Solicita uno nuevo.'});
      res.json({saved:true,message:'Contraseña actualizada. Inicia sesión con tu nueva contraseña.'});
    }catch{res.status(503).json({error:'No se pudo actualizar la contraseña. Reintenta.'})}
  });
}
