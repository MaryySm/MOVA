const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export function validDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(`${value}T12:00:00Z`);
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0,10) === value;
}
export function validEmotions(value) {
  return Array.isArray(value) && value.length >= 1 && value.length <= 6 &&
    new Set(value.map(e=>e?.label)).size === value.length && value.every(e => e &&
      ['Feliz','Contento','Neutral','Cansado','Triste','Enojado'].includes(e.label) &&
      Number.isInteger(e.intensity) && e.intensity>=0 && e.intensity<=100);
}
export function validActivity(change) {
  if (!change || typeof change.taskId !== 'string' || !change.taskId.trim() || change.taskId.length>160) return false;
  if (change.type==='remove_task') return true;
  if (change.type==='set_done') return typeof change.done==='boolean';
  return ['add_task','edit_task'].includes(change.type) && typeof change.label==='string' &&
    change.label.trim().length>0 && change.label.length<=200 && validDate(change.date) &&
    typeof change.time==='string' && /^([01]\d|2[0-3]):[0-5]\d$/.test(change.time) &&
    Number.isInteger(change.duration) && change.duration>=1 && change.duration<=1440;
}

export function installRequirementsRoutes(app,pool,requireAuth) {
  const wrap = fn => async (req,res) => {
    try { await fn(req,res); }
    catch(error) {
      if (error.code==='P0002') return res.status(404).json({error:'El perfil o dato solicitado no está disponible.'});
      if (['22023','22007','22008','22P02','23514','23502'].includes(error.code)) return res.status(400).json({error:'Revisa los datos enviados.'});
      if (error.code==='23505') return res.status(409).json({error:'Este identificador ya existe. Actualiza la pantalla.'});
      console.error('Error de requerimientos:',error);
      res.status(503).json({error:'No se pudo guardar o consultar. Puedes reintentar.'});
    }
  };
  const query = async (sql,values) => (await pool.query(sql,values)).rows[0]?.data;
  app.get('/api/v2/profiles',requireAuth,wrap(async(req,res)=>{
    res.json(await query('SELECT mova_api.sp_perfiles($1) AS data',[req.auth.sub]));
  }));
  app.post('/api/v2/profiles',requireAuth,wrap(async(req,res)=>{
    const {id,name,age,photo='',notifications={vibration:true,sound:true,lights:true,intensity:6}}=req.body??{};
    if (!uuid.test(id??'') || typeof name!=='string' || !name.trim() || name.length>160 ||
      !Number.isInteger(Number(age)) || Number(age)<1 || Number(age)>120 || typeof photo!=='string' || photo.length>150000 ||
      (photo && !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(photo)))
      return res.status(400).json({error:'Revisa el nombre, edad y fotografía (máximo 150 KB).'});
    res.json(await query('SELECT mova_api.sp_guardar_perfil($1,$2,$3,$4::smallint,$5,$6::jsonb) AS data',
      [req.auth.sub,id,name.trim(),Number(age),photo,JSON.stringify(notifications)]));
  }));
  // Un mismo perfil y una misma fecha gobiernan todas las pantallas.
  app.use('/api/v2/profiles/:profileId',requireAuth,(req,res,next)=>{
    if(!uuid.test(req.params.profileId)) return res.status(400).json({error:'Perfil inválido.'});
    next();
  });
  const root='/api/v2/profiles/:profileId';
  app.get(`${root}/panel`,requireAuth,wrap(async(req,res)=>{
    if (!validDate(req.query.date)) return res.status(400).json({error:'Fecha inválida.'});
    res.json(await query('SELECT mova_api.sp_panel($1,$2,$3::date) AS data',[req.auth.sub,req.params.profileId,req.query.date]));
  }));
  for (const [path,sp] of [['activities','sp_actividades'],['emotions','sp_historial_emocional'],['emotions/summary','sp_resumen_emocional']]) {
    app.get(`${root}/${path}`,requireAuth,wrap(async(req,res)=>{
      const {from,to}=req.query;
      if(!validDate(from)||!validDate(to)||from>to||new Date(to)-new Date(from)>366*86400000)
        return res.status(400).json({error:'Selecciona un período válido de hasta un año.'});
      res.json(await query(`SELECT mova_api.${sp}($1,$2,$3::date,$4::date) AS data`,[req.auth.sub,req.params.profileId,from,to]));
    }));
  }
  app.post(`${root}/activities`,requireAuth,wrap(async(req,res)=>{
    const {eventId,change}=req.body??{};
    if(!uuid.test(eventId??'')||!validActivity(change)) return res.status(400).json({error:'Revisa la actividad, fecha, hora y duración.'});
    const saved=await query('SELECT mova_api.sp_cambiar_actividad($1,$2,$3,$4::jsonb) AS data',
      [req.auth.sub,req.params.profileId,eventId,JSON.stringify(change)]);
    res.status(saved?201:200).json({saved:true,eventId});
  }));
  app.post(`${root}/emotions`,requireAuth,wrap(async(req,res)=>{
    const {eventId,emotions,note='',tags=[],recordedAt}=req.body??{};
    if(!uuid.test(eventId??'')||!validEmotions(emotions)||typeof note!=='string'||note.length>2000||
      !Array.isArray(tags)||tags.length>20||tags.some(t=>typeof t!=='string'||t.length>80)||
      typeof recordedAt!=='string'||!Number.isFinite(Date.parse(recordedAt))||Date.parse(recordedAt)>Date.now()+300000)
      return res.status(400).json({error:'Selecciona emociones, intensidades y una fecha válida.'});
    const saved=await query('SELECT mova_api.sp_autorreporte($1,$2,$3,$4::jsonb,$5,$6::jsonb,$7::timestamptz) AS data',
      [req.auth.sub,req.params.profileId,eventId,JSON.stringify(emotions),note,JSON.stringify(tags),recordedAt]);
    res.status(saved?201:200).json({saved:true,eventId});
  }));
  app.get(`${root}/device`,requireAuth,wrap(async(req,res)=>{
    res.json(await query('SELECT mova_api.sp_estado_dispositivo($1,$2) AS data',[req.auth.sub,req.params.profileId]));
  }));
  app.post(`${root}/device`,requireAuth,wrap(async(req,res)=>{
    const {id,name,type}=req.body??{};
    if(typeof id!=='string'||!id.trim()||id.length>160||typeof name!=='string'||!name.trim()||name.length>160||!['simulator','hardware'].includes(type))
      return res.status(400).json({error:'Dispositivo inválido.'});
    await pool.query('SELECT mova_api.sp_vincular_dispositivo($1,$2,$3,$4,$5)',[req.auth.sub,req.params.profileId,id,name,type]);
    res.json({linked:true});
  }));
  app.post(`${root}/device/heartbeat`,requireAuth,wrap(async(req,res)=>{
    if(typeof req.body?.deviceId!=='string') return res.status(400).json({error:'Dispositivo requerido.'});
    await pool.query('SELECT mova_api.sp_heartbeat($1,$2,$3)',[req.auth.sub,req.params.profileId,req.body.deviceId]);
    res.json({received:true});
  }));
  app.post(`${root}/device/telemetry`,requireAuth,wrap(async(req,res)=>{
    const {deviceId,recordedAt,measurements:m}=req.body??{};
    if(typeof deviceId!=='string'||typeof recordedAt!=='string'||!Number.isFinite(Date.parse(recordedAt))||
      !m||typeof m!=='object'||Array.isArray(m)||!['battery','steps','latitude'].some(key=>key in m)||
      ('battery' in m&&(!Number.isInteger(m.battery)||m.battery<0||m.battery>100))||
      ('steps' in m&&(!Number.isInteger(m.steps)||m.steps<0||m.steps>2147483647||!validDate(m.stepsDate)))||
      (('latitude' in m||'longitude' in m)&&(!Number.isFinite(m.latitude)||m.latitude<-90||m.latitude>90||!Number.isFinite(m.longitude)||m.longitude<-180||m.longitude>180)))
      return res.status(400).json({error:'Lecturas de sensores inválidas.'});
    await pool.query('SELECT mova_api.sp_telemetria($1,$2,$3,$4::jsonb,$5::timestamptz)',
      [req.auth.sub,req.params.profileId,deviceId,JSON.stringify(m),recordedAt]);
    res.json({received:true});
  }));
  app.get(`${root}/alerts`,requireAuth,wrap(async(req,res)=>{
    res.json(await query('SELECT mova_api.sp_alertas($1,$2) AS data',[req.auth.sub,req.params.profileId]));
  }));
  app.post(`${root}/sos`,requireAuth,wrap(async(req,res)=>{
    const {eventId,deviceId,recordedAt}=req.body??{};
    if(!uuid.test(eventId??'')||typeof deviceId!=='string'||typeof recordedAt!=='string'||!Number.isFinite(Date.parse(recordedAt)))
      return res.status(400).json({error:'Solicitud inválida.'});
    await pool.query('SELECT mova_api.sp_sos($1,$2,$3,$4,$5::timestamptz)',[req.auth.sub,req.params.profileId,eventId,deviceId,recordedAt]);
    res.status(201).json({status:'received',eventId});
  }));
  app.post(`${root}/alerts/acknowledge`,requireAuth,wrap(async(req,res)=>{
    if(!uuid.test(req.body?.eventId??'')) return res.status(400).json({error:'Solicitud inválida.'});
    await pool.query('SELECT mova_api.sp_confirmar_sos($1,$2,$3)',[req.auth.sub,req.params.profileId,req.body.eventId]);
    res.json({acknowledged:true});
  }));
}
