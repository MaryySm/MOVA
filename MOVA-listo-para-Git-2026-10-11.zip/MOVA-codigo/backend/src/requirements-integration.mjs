import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { readFileSync } from 'node:fs';
import express from 'express';
import pg from 'pg';
import { installRequirementsRoutes } from './requirements-routes.mjs';

const admin=new pg.Pool({connectionString:process.env.DATABASE_URL});
const database=`mova_rf_${crypto.randomBytes(8).toString('hex')}`;
const url=new URL(process.env.DATABASE_URL);url.pathname=`/${database}`;
let pool,server,created=false;
try {
  await admin.query(`CREATE DATABASE ${database}`);created=true;
  pool=new pg.Pool({connectionString:url.toString()});
  const read=name=>readFileSync(new URL(`../db/${name}`,import.meta.url),'utf8').replace(/^\uFEFF/,'');
  await pool.query(read('init.sql').split('\\ir')[0]);
  await pool.query(read('wearable.sql'));await pool.query(read('screens.sql'));
  const a=crypto.randomUUID(),b=crypto.randomUUID();
  await pool.query("INSERT INTO users(id,adult_name,user_name,age,phone,email,password_hash,password_salt) VALUES($1,'Adult A','Child A',10,'+56912345678','a@test.cl','hash','salt'),($2,'Adult B','Child B',11,'+56912345678','b@test.cl','hash','salt')",[a,b]);
  const now=new Date().toISOString();
  await pool.query('SELECT mova_api.sp_guardar_registro($1,$2,$3,$4::jsonb,$5,$6::timestamptz)',
    [a,crypto.randomUUID(),'old-device','[{"id":"old-task","label":"Leer","time":"18:00","done":true}]','Feliz',now]);
  await pool.query(read('requirements.sql'));await pool.query(read('requirements.sql'));
  await pool.query(read('ownership.sql'));await pool.query(read('ownership.sql'));
  await pool.query(read('wearable.sql'));
  assert.equal((await pool.query('SELECT count(*)::int AS n FROM mova_interno.actividades WHERE profile_id=$1',[a])).rows[0].n,1);
  assert.equal((await pool.query('SELECT count(*)::int AS n FROM mova_interno.autorreportes')).rows[0].n,0);
  const auth=(req,res,next)=>{
    const id={'Bearer a':a,'Bearer b':b}[req.get('authorization')];
    if(!id)return res.status(401).json({error:'Sesión requerida'});req.auth={sub:id};next();
  };
  const app=express();app.use(express.json());installRequirementsRoutes(app,pool,auth);
  server=await new Promise(resolve=>{const s=app.listen(0,'127.0.0.1',()=>resolve(s))});
  async function request(path,body,account='a') {
    const response=await fetch(`http://127.0.0.1:${server.address().port}/api/v2/${path}`,{
      method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${account}`},
      ...(body===undefined?{}:{body:JSON.stringify(body)})});
    return {status:response.status,data:await response.json()};
  }
  const day=(await pool.query("SELECT (now() AT TIME ZONE 'America/Santiago')::date::text AS day")).rows[0].day;
  const root=id=>`profiles/${id}`;
  const panel=async(id=a,account='a')=>request(`${root(id)}/panel?date=${day}`,undefined,account);
  assert.equal((await request('profiles',undefined,'invalid')).status,401);
  assert.equal((await request('profiles')).data[0].name,'Child A');
  assert.equal((await panel(b)).status,404);
  const child=crypto.randomUUID();
  const profile={id:child,name:'Second child',age:'8',notifications:{vibration:true,sound:false,lights:true,intensity:6}};
  assert.equal((await request('profiles',profile)).status,200);
  assert.equal((await panel(child)).data.activities.length,0);
  assert.equal((await request('profiles',{...profile,id:b})).status,404);
  const change={type:'add_task',taskId:'new-task',label:'Colegio',date:day,time:'08:00',duration:45};
  const operation={eventId:crypto.randomUUID(),change};
  assert.equal((await request(`${root(child)}/activities`,operation)).status,201);
  assert.equal((await request(`${root(child)}/activities`,operation)).status,200);
  assert.equal((await request(`${root(child)}/activities`,{...operation,change:{...change,label:'Collision'}})).status,400);
  assert.equal((await panel(child)).data.activities.length,1);
  assert.equal((await panel()).data.activities[0].id,'old-task');
  const mark={eventId:crypto.randomUUID(),change:{type:'set_done',taskId:'new-task',done:true}};
  await request(`${root(child)}/activities`,mark);
  assert.equal((await panel(child)).data.progressPercent,100);
  assert.equal((await request(`${root(child)}/activities`,mark,'b')).status,404);
  const activityList=(await request(`${root(child)}/activities?from=${day}&to=${day}`)).data;
  assert.equal(activityList[0].duration,45);assert.equal(activityList[0].done,true);
  await Promise.all(['first','second'].map(taskId=>request(`${root(child)}/activities`,{eventId:crypto.randomUUID(),change:{...change,taskId}})));
  assert.equal((await panel(child)).data.activities.length,3);
  const invalidId=crypto.randomUUID();
  assert.equal((await request(`${root(child)}/activities`,{eventId:invalidId,change:{...change,date:'2026-02-30'}})).status,400);
  assert.equal((await pool.query('SELECT count(*)::int AS n FROM mova_interno.operaciones WHERE id=$1',[invalidId])).rows[0].n,0);
  const emotions={eventId:crypto.randomUUID(),emotions:[{label:'Feliz',intensity:100},{label:'Triste',intensity:0}],note:'Optional note',recordedAt:now};
  assert.equal((await request(`${root(child)}/emotions`,emotions)).status,201);
  assert.equal((await request(`${root(child)}/emotions`,emotions)).status,200);
  const summary=(await request(`${root(child)}/emotions/summary?from=${day}&to=${day}`)).data;
  assert.deepEqual(summary,[{date:day,intensity:50,count:1}]);
  assert.deepEqual((await request(`${root(a)}/emotions/summary?from=${day}&to=${day}`)).data,[]);
  assert.equal((await request(`${root(child)}/emotions`,{...emotions,eventId:crypto.randomUUID(),emotions:[{label:'Feliz',intensity:101}]})).status,400);
  const history=(await request(`${root(child)}/emotions?from=${day}&to=${day}`)).data;
  assert.equal(history.length,1);assert.equal(history[0].note,'Optional note');
  assert.equal((await request(`${root(child)}/emotions?from=${day}&to=${day}`,undefined,'b')).status,404);
  assert.equal((await panel(child)).data.device,null);
  const device={id:`sim-${child}`,name:'Simulator',type:'simulator'};
  assert.equal((await request(`${root(child)}/device`,device)).status,200);
  assert.equal((await request(`${root(b)}/device`,device,'b')).status,400);
  await request(`${root(child)}/device/heartbeat`,{deviceId:device.id});
  const deviceState=(await panel(child)).data.device;
  assert.equal(deviceState.bateria,null);assert.equal(deviceState.lat,null);assert.ok(deviceState.last_seen);
  const sos={eventId:crypto.randomUUID(),deviceId:device.id,recordedAt:now};
  assert.equal((await request(`${root(child)}/sos`,sos)).status,201);
  assert.equal((await request(`${root(child)}/sos`,sos)).status,201);
  assert.equal((await panel(child)).data.alerts.length,1);
  assert.equal((await panel(child)).data.alerts[0].acknowledged_at,null);
  assert.equal((await request(`${root(child)}/alerts/acknowledge`,{eventId:sos.eventId},'b')).status,404);
  await request(`${root(child)}/alerts/acknowledge`,{eventId:sos.eventId});
  assert.ok((await panel(child)).data.alerts[0].acknowledged_at);
  await request(`${root(child)}/activities`,{eventId:crypto.randomUUID(),change:{type:'remove_task',taskId:'new-task'}});
  assert.equal((await panel(child)).data.activities.length,2);
  assert.equal((await pool.query('SELECT eliminada FROM mova_interno.actividades WHERE profile_id=$1 AND id=$2',[child,'new-task'])).rows[0].eliminada,true);
  await pool.query('SELECT * FROM mova_api.sp_registro($1,$2,$3::smallint,$4,$5,$6,$7,$8)',['New adult','New child',9,'+56912345678','new@test.cl','','hash','salt']);
  assert.equal((await pool.query("SELECT count(*)::int AS n FROM mova_interno.perfiles p JOIN users u ON u.id=p.user_id WHERE u.email='new@test.cl'")).rows[0].n,1);
  const hardware={id:`hw-${a}`,name:'Test hardware',type:'hardware'};
  await request(`${root(a)}/device`,hardware);
  assert.equal((await request(`${root(a)}/device/telemetry`,{deviceId:hardware.id,recordedAt:now,
    measurements:{battery:76,latitude:-33.44,longitude:-70.66,steps:1200,stepsDate:day}})).status,200);
  const measured=(await panel()).data.device;
  assert.equal(measured.bateria,76);assert.equal(measured.lat,-33.44);assert.equal(measured.pasos,1200);assert.ok(measured.location_at);
  await request(`${root(a)}/device/telemetry`,{deviceId:hardware.id,recordedAt:new Date(Date.now()-3600000).toISOString(),measurements:{battery:5}});
  assert.equal((await panel()).data.device.bateria,76);
  assert.equal((await request(`${root(a)}/device/telemetry`,{deviceId:hardware.id,recordedAt:now,measurements:{latitude:200,longitude:0}})).status,400);
  assert.equal((await request(`${root(child)}/device/telemetry`,{deviceId:device.id,recordedAt:now,measurements:{battery:80}})).status,404);
  assert.equal((await pool.query('SELECT mova_api.sp_sesion_valida($1,$2) AS valid',[a,'token-hash'])).rows[0].valid,true);
  await pool.query('SELECT mova_api.sp_cerrar_sesion($1,$2::timestamptz)',['token-hash',new Date(Date.now()+3600000).toISOString()]);
  assert.equal((await pool.query('SELECT mova_api.sp_sesion_valida($1,$2) AS valid',[a,'token-hash'])).rows[0].valid,false);
  await pool.query('SELECT mova_api.sp_solicitar_recuperacion($1,$2)',['a@test.cl','reset-hash']);
  assert.equal((await pool.query('SELECT mova_api.sp_restaurar_acceso($1,$2,$3) AS saved',['reset-hash','new-hash','new-salt'])).rows[0].saved,true);
  assert.equal((await pool.query('SELECT mova_api.sp_restaurar_acceso($1,$2,$3) AS saved',['reset-hash','other-hash','salt'])).rows[0].saved,false);
  assert.equal((await pool.query('SELECT session_version FROM users WHERE id=$1',[a])).rows[0].session_version,1);
  for (const table of ['tareas','emociones','progreso']) {
    assert.equal((await pool.query('SELECT count(*)::int n FROM public.'+table+' WHERE user_id IS NULL OR profile_id IS NULL OR usuario IS NULL')).rows[0].n,0);
    const result=await pool.query('SELECT user_id,profile_id,usuario FROM public.'+table);
    for(const row of result.rows){const owner=await pool.query('SELECT user_id,nombre FROM mova_interno.perfiles WHERE id=$1',[row.profile_id]);assert.equal(row.user_id,owner.rows[0].user_id);assert.equal(row.usuario,owner.rows[0].nombre);}
  }
  console.log('Vistas por cuenta/perfil correctas e instalación repetible.');
  console.log('RF/RNF correctos: migración, perfiles separados, actividades compartidas, fechas, duración, progreso, reintentos, concurrencia, intensidades/resumen sin datos, dispositivo sin valores falsos y SOS con confirmación real.');
} finally {
  if(server)await new Promise(resolve=>server.close(resolve));if(pool)await pool.end();
  if(created)await admin.query(`DROP DATABASE ${database}`);await admin.end();
}
