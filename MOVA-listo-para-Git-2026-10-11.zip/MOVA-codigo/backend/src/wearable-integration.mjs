import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import crypto from 'node:crypto';
import express from 'express';
import pg from 'pg';
import { wearableSchema, installWearableRoutes } from './wearable-records.mjs';
import { installScreenRoutes } from './screen-routes.mjs';

// Las pruebas no agregan datos a MOVA: usan una base temporal aislada.
const admin = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const database = `mova_test_${crypto.randomBytes(8).toString('hex')}`;
const url = new URL(process.env.DATABASE_URL);
url.pathname = `/${database}`;
let pool, server, created = false;
try {
  await admin.query(`CREATE DATABASE ${database}`);
  created = true;
  pool = new pg.Pool({ connectionString: url.toString() });
  const userA = crypto.randomUUID(), userB = crypto.randomUUID();
  await pool.query(readFileSync(new URL('../db/init.sql', import.meta.url),'utf8').split('\\ir')[0]);
  await pool.query("INSERT INTO users(id,adult_name,user_name,age,phone,email,password_hash,password_salt) VALUES($1,'A','A',10,'12345678','a@test.cl','hash','salt'),($2,'B','B',11,'12345678','b@test.cl','hash','salt')", [userA,userB]);
  const record = { eventId: crypto.randomUUID(), deviceId: 'integration-test',
    activities: [{ id: 'a1', label: 'Levantarme', time: '06:30', done: true },
      { id: 'a2', label: 'Bañarme', time: '06:45', done: false }],
    emotion: '¡Genial!', recordedAt: new Date().toISOString(), progressPercent: 99 };
  await pool.query(`CREATE TABLE progreso(id BIGSERIAL PRIMARY KEY,user_id UUID,event_id UUID,
    device_id TEXT,progress_percent SMALLINT,total_tasks SMALLINT,completed_tasks SMALLINT,
    recorded_at TIMESTAMPTZ,received_at TIMESTAMPTZ,UNIQUE(user_id,event_id));
    CREATE TABLE tareas(user_id UUID,event_id UUID,activity_id TEXT,label TEXT,
      scheduled_time TIME,completed BOOLEAN,position SMALLINT);
    CREATE TABLE emociones(user_id UUID,event_id UUID,emotion TEXT)`);
  await pool.query('INSERT INTO progreso(user_id,event_id,device_id,progress_percent,total_tasks,completed_tasks,recorded_at,received_at) VALUES($1,$2,$3,50,2,1,$4,NOW())', [userA, record.eventId, record.deviceId, record.recordedAt]);
  for (const [i, task] of record.activities.entries()) await pool.query('INSERT INTO tareas VALUES($1,$2,$3,$4,$5,$6,$7)', [userA, record.eventId, task.id, task.label, task.time, task.done, i]);
  await pool.query('INSERT INTO emociones VALUES($1,$2,$3)', [userA, record.eventId, record.emotion]);
  await pool.query(wearableSchema);
  await pool.query(wearableSchema);
  await pool.query(readFileSync(new URL('../db/screens.sql', import.meta.url),'utf8'));
  assert.equal((await pool.query('SELECT user_id FROM mova_interno.registros')).rows[0].user_id,userA);
  const app = express();
  app.use(express.json());
  installWearableRoutes(app, pool, (req, res, next) => {
    const user = { 'Bearer test-a': userA, 'Bearer test-b': userB }[req.get('authorization')];
    if (!user) return res.status(401).json({ error: 'Sesión requerida' });
    req.auth = { sub: user }; next();
  });
  installScreenRoutes(app, pool, (req,res,next) => {
    const user = { 'Bearer test-a':userA, 'Bearer test-b':userB }[req.get('authorization')];
    if (!user) return res.status(401).json({ error:'Sesión requerida' });
    req.auth = { sub:user }; next();
  });
  server = await new Promise((resolve) => { const s = app.listen(0, '127.0.0.1', () => resolve(s)); });
  async function request(body, token = 'test-a', limit = '') {
    const r = await fetch(`http://127.0.0.1:${server.address().port}/api/wearable/records${limit}`, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    return { status: r.status, data: await r.json() };
  }
  const count = async (table) => (await pool.query(`SELECT COUNT(*)::int AS n FROM ${table}`)).rows[0].n;
  assert.equal((await request(record, null)).status, 401);
  assert.equal((await request(record)).status, 200);
  const same = { ...record, eventId: crypto.randomUUID(), recordedAt: new Date().toISOString() };
  assert.equal((await request(same)).status, 201);
  assert.equal((await request(same)).status, 200);
  const latest = (await request(undefined, 'test-a', '?limit=1')).data[0];
  assert.equal(latest.emotion, 'Feliz'); assert.equal(latest.progressPercent, 50);
  assert.equal(latest.activities[0].label, 'Levantarse'); assert.equal(latest.activities[0].done, true);
  assert.deepEqual((await request(undefined, 'test-b')).data, []);
  const sad = { ...same, eventId: crypto.randomUUID(), emotion: 'Triste', recordedAt: new Date().toISOString() };
  assert.equal((await request(sad)).status, 201);
  const done = { ...sad, eventId: crypto.randomUUID(), activities: record.activities.map((a) => ({ ...a, done: true })), recordedAt: new Date().toISOString() };
  assert.equal((await request(done)).status, 201);
  const empty = { ...done, eventId: crypto.randomUUID(), activities: [], emotion: null, recordedAt: new Date().toISOString() };
  assert.equal((await request(empty)).status, 201);
  assert.equal((await request(undefined, 'test-a', '?limit=1')).data[0].progressPercent, 0);
  assert.equal((await request({ ...record, emotion: {} })).status, 400);
  // Una tarea pendiente no aparece; al marcarla se guarda solo su nombre.
  const pending = { ...record, eventId: crypto.randomUUID(), emotion: null,
    activities: [{ id: 'reading', label: 'Leer un cuento', time: '18:00', done: false }],
    recordedAt: new Date().toISOString() };
  assert.equal((await request(pending, 'test-b')).status, 201);
  const marked = { ...pending, eventId: crypto.randomUUID(),
    activities: [{ ...pending.activities[0], done: true }], recordedAt: new Date().toISOString() };
  assert.equal((await request(marked, 'test-b')).status, 201);
  assert.equal((await request(marked, 'test-b')).status, 200);
  const saved=(await pool.query('SELECT activities FROM mova_interno.registros WHERE user_id=$1 AND event_id=$2',[userB,marked.eventId])).rows[0];
  assert.equal(saved.activities[0].label,'Leer un cuento');assert.equal(saved.activities[0].done,true);
  // Las pantallas consultan el mismo estado y las escrituras concurrentes se conservan.
  const call = async (sql, values) => (await pool.query(sql, values)).rows[0];
  const action = (type, change) => ({ actionId: crypto.randomUUID(), type, ...change });
  await Promise.all(['first','second'].map(id => call('SELECT mova_api.sp_accion_rutina($1,$2::jsonb)',
    [userA,JSON.stringify(action('add_task',{taskId:id,label:id,time:'08:00'}))])));
  const routine = (await call('SELECT mova_api.sp_rutina($1) AS data',[userA])).data;
  assert.deepEqual(routine.activities.map(a=>a.id).sort(),['first','second']);
  const completed = action('set_done',{taskId:'first',done:true});
  await call('SELECT mova_api.sp_accion_rutina($1,$2::jsonb)',[userA,JSON.stringify(completed)]);
  assert.equal((await call('SELECT mova_api.sp_accion_rutina($1,$2::jsonb) AS saved',[userA,JSON.stringify(completed)])).saved,false);
  assert.equal((await call('SELECT mova_api.sp_inicio($1) AS data',[userA])).data.routine.progressPercent,50);
  const emotionalId = crypto.randomUUID();
  await call('SELECT mova_api.sp_guardar_emocion($1,$2,$3,$4,$5::jsonb)',[userA,emotionalId,'Feliz','Hoy jugué','["Calmado"]']);
  const history = (await call('SELECT mova_api.sp_emociones($1) AS data',[userA])).data;
  assert.equal(history[0].note,'Hoy jugué'); assert.deepEqual(history[0].tags,['Calmado']);
  assert.equal((await call('SELECT mova_api.sp_rutina($1) AS data',[userA])).data.emotion,'Feliz');
  await call('SELECT mova_api.sp_guardar_configuracion($1,$2::jsonb)',[userA,'{"language":"Español"}']);
  await call('SELECT mova_api.sp_guardar_configuracion($1,$2::jsonb)',[userA,'{"activeId":"main"}']);
  assert.deepEqual((await call('SELECT mova_api.sp_configuracion($1) AS data',[userA])).data,{language:'Español',activeId:'main'});
  assert.deepEqual((await call('SELECT mova_api.sp_configuracion($1) AS data',[userB])).data,{});
  const event = crypto.randomUUID();
  await call('SELECT mova_api.sp_guardar_evento($1,$2,$3,$4::date,$5::time)',[userA,event,'Colegio','2026-10-12','08:00']);
  assert.equal((await call('SELECT mova_api.sp_calendario($1,$2::date,$3::date) AS data',[userA,'2026-10-01','2026-10-31'])).data.length,1);
  assert.deepEqual((await call('SELECT mova_api.sp_calendario($1,$2::date,$3::date) AS data',[userB,'2026-10-01','2026-10-31'])).data,[]);
  await assert.rejects(call('SELECT mova_api.sp_guardar_evento($1,$2,$3,$4::date,$5::time)',[userB,event,'Otra cuenta','2026-10-12','08:00']),{code:'22023'});
  await call('SELECT mova_api.sp_eliminar_evento($1,$2)',[userB,event]);
  assert.equal((await call('SELECT mova_api.sp_calendario($1,$2::date,$3::date) AS data',[userA,'2026-10-01','2026-10-31'])).data.length,1);
  await call('SELECT * FROM mova_api.sp_guardar_sync($1,$2,$3::jsonb)',[userA,'watch','{"bpm":80}']);
  assert.equal((await call('SELECT * FROM mova_api.sp_dispositivo($1,1)',[userA])).payload.bpm,80);
  async function screen(path,body,token='test-a') {
    const response = await fetch(`http://127.0.0.1:${server.address().port}/api/screens/${path}`, {
      method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${token}`},
      ...(body===undefined?{}:{body:JSON.stringify(body)}) });
    return { status:response.status,data:await response.json() };
  }
  assert.equal((await screen('home')).data.routine.emotion,'Feliz');
  assert.equal((await screen('routine')).data.progressPercent,50);
  assert.equal((await screen('home',undefined,'invalid')).status,401);
  assert.equal((await screen('emotions')).data[0].note,'Hoy jugué');
  assert.equal((await screen('settings',{language:'English'})).status,200);
  assert.equal((await screen('settings')).data.language,'English');
  const apiEvent=crypto.randomUUID();
  assert.equal((await screen('calendar',{id:apiEvent,title:'API event',date:'2026-10-15',time:'09:00'})).status,201);
  assert.equal((await screen('calendar?from=2026-10-01&to=2026-10-31')).data.length,2);
  assert.deepEqual((await screen('calendar?from=2026-10-01&to=2026-10-31',undefined,'test-b')).data,[]);
  assert.equal((await screen('calendar',{title:'Invalid',date:'2026-02-30',time:'09:00'})).status,400);
  assert.equal((await screen('calendar/remove',{id:apiEvent})).status,200);
  const apiEmotion={eventId:crypto.randomUUID(),emotion:'Contento',note:'Desde API',tags:['Bien']};
  assert.equal((await screen('emotions',apiEmotion)).status,201);
  assert.equal((await screen('emotions',apiEmotion)).status,200);
  assert.equal((await screen('emotions',{...apiEmotion,tags:[123]})).status,400);
  assert.equal((await screen('emotions')).data[0].note,'Desde API');
  console.log('SP correctos: concurrencia, rutina/inicio, emociones con notas, configuración, calendario y dispositivo.');
  console.log('Pruebas correctas: propietario en registros, nombres claros, migración, aislamiento por cuenta y cambios sin duplicados.');
} finally {
  if (server) await new Promise((resolve) => server.close(resolve));
  if (pool) await pool.end();
  if (created) await admin.query(`DROP DATABASE ${database}`);
  await admin.end();
}
