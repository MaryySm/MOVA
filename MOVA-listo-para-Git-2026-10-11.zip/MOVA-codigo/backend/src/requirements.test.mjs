import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validActivity, validDate, validEmotions } from './requirements-routes.mjs';
test('valida fechas reales y duración de actividades',()=>{
  assert.equal(validDate('2026-02-30'),false);
  assert.equal(validDate('2024-02-29'),true);
  const activity={type:'add_task',taskId:'a',label:'Leer',date:'2026-10-11',time:'18:00',duration:30};
  assert.equal(validActivity(activity),true);
  for(const change of [{duration:0},{duration:1441},{time:'24:00'},{label:' '},{date:'invalid'}])
    assert.equal(validActivity({...activity,...change}),false);
});
test('autorreporte admite varias emociones y cero real, sin duplicados ni intensidades inventadas',()=>{
  assert.equal(validEmotions([{label:'Feliz',intensity:0},{label:'Triste',intensity:100}]),true);
  for(const values of [[],[{label:'Feliz'}],[{label:'Feliz',intensity:101}],[{label:'Feliz',intensity:50.5}],
    [{label:'Feliz',intensity:50},{label:'Feliz',intensity:20}],[{label:'unknown',intensity:50}]])assert.equal(validEmotions(values),false);
});
