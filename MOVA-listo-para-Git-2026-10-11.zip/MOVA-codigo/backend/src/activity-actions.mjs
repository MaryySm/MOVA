import { validateRecord } from './wearable-records.mjs';

export function validateAction(body) {
  if (!body || typeof body !== 'object' || typeof body.actionId !== 'string' ||
      !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(body.actionId))
    throw new Error('Identificador de cambio inválido.');
  if (!['add_task','set_done','remove_task','set_emotion'].includes(body.type)) throw new Error('Cambio inválido.');
  if (body.type !== 'set_emotion' && (typeof body.taskId !== 'string' || !body.taskId.trim() || body.taskId.length > 160)) throw new Error('Tarea requerida.');
  if (body.type === 'add_task' && (typeof body.label !== 'string' || !body.label.trim() || body.label.length > 200 || typeof body.time !== 'string' || !/^([01]\d|2[0-3]):[0-5]\d$/.test(body.time))) throw new Error('Escribe el nombre y una hora válida.');
  if (body.type === 'set_done' && typeof body.done !== 'boolean') throw new Error('Estado inválido.');
  if (body.type === 'set_emotion' && body.emotion !== null && (typeof body.emotion !== 'string' || !body.emotion.trim() || body.emotion.length > 80)) throw new Error('Emoción inválida.');
  return body;
}
export function applyAction(state, action) {
  let activities = state.activities.map((a) => ({ ...a }));
  let emotion = state.emotion;
  if (action.type === 'add_task' && !activities.some((a) => a.id === action.taskId)) {
    if (activities.length >= 100) throw new Error('Puedes guardar hasta 100 actividades.');
    activities.push({ id: action.taskId, label: action.label.trim(), time: action.time, done: false });
  }
  if (action.type === 'remove_task') activities = activities.filter((a) => a.id !== action.taskId);
  if (action.type === 'set_done') activities = activities.map((a) => a.id === action.taskId ? { ...a, done: action.done } : a);
  if (action.type === 'set_emotion') emotion = action.emotion;
  return { activities, emotion };
}
export function installActivityRoutes(app, pool, requireAuth) {
  const handle = async (req, res, legacy = false) => {
    let action;
    try { action = legacy ? { ...validateRecord(req.body), actionId: req.body.eventId } : validateAction(req.body); }
    catch (error) { return res.status(400).json({ error: error.message }); }
    try {
      const result = await pool.query('SELECT mova_api.sp_accion_rutina($1,$2::jsonb,$3) AS saved',
        [req.auth.sub, JSON.stringify(action), legacy]);
      res.status(result.rows[0].saved ? 201 : 200).json({ saved: true, actionId: action.actionId });
    } catch (error) {
      if (error.code === '22023') return res.status(400).json({ error: error.message });
      if (error.code === 'P0002') return res.status(401).json({ error: 'La cuenta ya no est? disponible.' });
      console.error('No se pudo guardar el cambio:', error);
      res.status(503).json({ error: 'No se pudo guardar. Se reintentará al recuperar la conexión.' });
    }
  };
  app.post('/api/activities/actions', requireAuth, (req, res) => handle(req, res));
  app.post('/api/sync/legacy', requireAuth, (req, res) => handle(req, res, true));
}
