import 'dart:convert';
import 'package:http/http.dart' as http;

class RequirementsApi {
  RequirementsApi(this.base, this.token);
  final String base;
  final String token;

  Future<dynamic> request(String path, [Map<String, dynamic>? body]) async {
    final uri = Uri.parse('$base$path');
    final headers = {'Authorization': 'Bearer $token', 'Content-Type': 'application/json'};
    final response = await (body == null
        ? http.get(uri, headers: headers)
        : http.post(uri, headers: headers, body: jsonEncode(body)))
        .timeout(const Duration(seconds: 15));
    final value = jsonDecode(response.body);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception(value is Map ? value['error'] : 'No se pudo acceder a MOVA');
    }
    return value;
  }

  String profilePath(String profileId, String operation) => '/api/v2/profiles/$profileId/$operation';
  Future<List<dynamic>> profiles() async => await request('/api/v2/profiles') as List<dynamic>;
  Future<Map<String, dynamic>> panel(String profileId, String date) async =>
      await request('${profilePath(profileId, 'panel')}?date=$date') as Map<String, dynamic>;
  Future<List<dynamic>> activities(String profileId, String from, String to) async =>
      await request('${profilePath(profileId, 'activities')}?from=$from&to=$to') as List<dynamic>;
  Future<dynamic> change(String profileId, String eventId, Map<String, dynamic> change) =>
      request(profilePath(profileId, 'activities'), {'eventId': eventId, 'change': change});
}
